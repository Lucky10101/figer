import torch
import torch.nn as nn

def l2_distance(x1, x2):
    """
    计算 batch mean L2 距离
    
    Args:
        x1: 张量，shape [B, C, H, W]
        x2: 张量，shape [B, C, H, W]
    
    Returns:
        batch mean L2 distance
    """
    return torch.norm(x1 - x2, p=2, dim=(1, 2, 3)).mean()

def foreground_ratio(x):
    """
    计算白色像素比例（前景比例）
    
    Args:
        x: 张量，shape [B, C, H, W]，范围 [0, 1]
    
    Returns:
        batch mean foreground ratio
    """
    return x.mean(dim=(1, 2, 3)).mean()

def binary_difference_ratio(x_adv_binary, x_original_binary):
    """
    计算二值图不同像素比例
    
    Args:
        x_adv_binary: 扰动后的二值图，shape [B, C, H, W]，值为 0 或 1
        x_original_binary: 原始二值图，shape [B, C, H, W]，值为 0 或 1
    
    Returns:
        batch mean difference ratio
    """
    diff = torch.abs(x_adv_binary - x_original_binary)
    return diff.mean(dim=(1, 2, 3)).mean()

def classification_keep_rate(logits, labels):
    """
    计算预测仍为原类别的比例
    
    Args:
        logits: 模型输出，shape [B, num_classes]
        labels: 原始标签，shape [B]
    
    Returns:
        keep rate (0-1)
    """
    preds = logits.argmax(dim=1)
    correct = (preds == labels).float().mean()
    return correct.item()