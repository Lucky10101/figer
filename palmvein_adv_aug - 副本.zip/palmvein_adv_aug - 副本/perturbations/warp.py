import torch
import torch.nn.functional as F

def warp_image(x, flow):
    """
    使用位移场 warp 图像
    
    Args:
        x: 输入图像，shape [B, 1, H, W]
        flow: 位移场，shape [B, 2, H, W]
              channel 0: dx（水平位移，单位像素）
              channel 1: dy（垂直位移，单位像素）
    
    Returns:
        x_warped: warp 后的图像，shape [B, 1, H, W]
    """
    batch_size, _, height, width = x.size()
    
    # 生成 normalized grid [-1, 1]
    grid_x = torch.linspace(-1, 1, width, device=x.device)
    grid_y = torch.linspace(-1, 1, height, device=x.device)
    grid_y, grid_x = torch.meshgrid(grid_y, grid_x)
    
    # 将网格扩展到 batch 维度
    grid = torch.stack([grid_x, grid_y], dim=0)  # [2, H, W]
    grid = grid.unsqueeze(0).repeat(batch_size, 1, 1, 1)  # [B, 2, H, W]
    
    # 将位移场归一化到 [-1, 1] 范围
    # 位移场的单位是像素，需要乘以 2/(W-1) 和 2/(H-1) 来映射到 [-1, 1]
    # 当 align_corners=True 时，这是正确的归一化方式
    flow_normalized = flow.clone()
    flow_normalized[:, 0] = flow[:, 0] * 2 / (width - 1)   # dx
    flow_normalized[:, 1] = flow[:, 1] * 2 / (height - 1)  # dy
    
    # 将位移加到网格上
    grid_warped = grid + flow_normalized
    
    # 将 grid 转换为 grid_sample 期望的格式 [B, H, W, 2]
    grid_warped = grid_warped.permute(0, 2, 3, 1)  # [B, H, W, 2]
    
    # 使用 grid_sample 进行 warp
    x_warped = F.grid_sample(
        x,
        grid_warped,
        mode='bilinear',
        padding_mode='border',
        align_corners=True
    )
    
    return x_warped