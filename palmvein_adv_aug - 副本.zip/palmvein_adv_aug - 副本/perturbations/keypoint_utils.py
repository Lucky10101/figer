import numpy as np
import torch
from skimage import morphology
import random

def extract_skeleton_keypoints(binary_img, max_points=80, min_distance=5):
    """
    从二值图像提取骨架关键点
    
    Args:
        binary_img: numpy array, H×W, 值为 0 或 1
        max_points: 最大关键点数量
        min_distance: 采样点之间的最小距离
    
    Returns:
        keypoints: numpy array, shape [N, 2]，格式为 (x, y)
    """
    # 确保输入是二值图像
    binary_img = (binary_img > 0).astype(np.uint8)
    
    # 提取骨架
    skeleton = morphology.skeletonize(binary_img)
    skeleton = skeleton.astype(np.uint8)
    
    # 获取骨架像素坐标
    y_coords, x_coords = np.where(skeleton > 0)
    
    if len(y_coords) == 0:
        # 如果没有骨架，返回前景边界点
        foreground_boundary = extract_boundary_points(binary_img, max_points)
        return foreground_boundary
    
    skeleton_points = set(zip(x_coords, y_coords))
    
    # 识别端点：8邻域骨架邻居数 == 1
    endpoints = []
    for x, y in skeleton_points:
        neighbors = get_skeleton_neighbors(skeleton, x, y)
        if len(neighbors) == 1:
            endpoints.append((x, y))
    
    # 识别分叉点：8邻域骨架邻居数 >= 3
    branchpoints = []
    for x, y in skeleton_points:
        if (x, y) in endpoints:
            continue
        neighbors = get_skeleton_neighbors(skeleton, x, y)
        if len(neighbors) >= 3:
            branchpoints.append((x, y))
    
    # 均匀采样普通骨架点
    all_points = list(skeleton_points)
    normal_points = sample_points_with_min_distance(
        all_points, min_distance, max_points - len(endpoints) - len(branchpoints)
    )
    
    # 合并关键点
    keypoints = []
    keypoints.extend(endpoints)
    keypoints.extend(branchpoints)
    keypoints.extend(normal_points)
    
    # 如果关键点数量不足，添加前景边界点
    if len(keypoints) < max_points // 2:
        boundary_points = extract_boundary_points(binary_img, max_points - len(keypoints))
        keypoints.extend(boundary_points)
    
    # 限制最大数量
    if len(keypoints) > max_points:
        # 优先保留端点和分叉点
        priority_points = endpoints + branchpoints
        other_points = [p for p in keypoints if p not in priority_points]
        other_points = sample_points_with_min_distance(other_points, min_distance, max_points - len(priority_points))
        keypoints = priority_points + other_points
    
    # 确保不重复
    keypoints = list(set(keypoints))
    
    # 转换为 numpy array
    keypoints = np.array(keypoints, dtype=np.float32)
    
    return keypoints

def get_skeleton_neighbors(skeleton, x, y):
    """
    获取骨架像素的8邻域中的骨架邻居
    
    Args:
        skeleton: 骨架图像
        x, y: 像素坐标
    
    Returns:
        邻居坐标列表
    """
    h, w = skeleton.shape
    neighbors = []
    
    # 8邻域偏移
    offsets = [
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1),          (0, 1),
        (1, -1),  (1, 0), (1, 1)
    ]
    
    for dx, dy in offsets:
        nx, ny = x + dx, y + dy
        if 0 <= nx < w and 0 <= ny < h:
            if skeleton[ny, nx] > 0:
                neighbors.append((nx, ny))
    
    return neighbors

def sample_points_with_min_distance(points, min_distance, num_points):
    """
    在保持最小距离的前提下采样点
    
    Args:
        points: 所有候选点列表 [(x, y), ...]
        min_distance: 最小距离
        num_points: 需要采样的点数
    
    Returns:
        采样后的点列表
    """
    if num_points <= 0 or len(points) == 0:
        return []
    
    # 计算距离矩阵（近似）
    points = list(set(points))  # 去重
    
    if len(points) <= num_points:
        return points
    
    selected = []
    remaining = points.copy()
    
    # 优先选择端点（如果有）
    endpoints = [p for p in points if is_endpoint_or_branch(skeleton_from_points(points), p[0], p[1])]
    if endpoints:
        selected.append(endpoints[0])
        remaining.remove(endpoints[0])
    
    # 贪心选择
    while len(selected) < num_points and remaining:
        # 找到离已有选点最远的点
        best_point = None
        best_min_dist = -1
        
        for candidate in remaining:
            min_dist = min(np.sqrt((candidate[0] - s[0])**2 + (candidate[1] - s[1])**2) for s in selected) if selected else float('inf')
            if min_dist > best_min_dist:
                best_min_dist = min_dist
                best_point = candidate
        
        if best_point is None:
            break
        
        if best_min_dist >= min_distance or len(selected) < num_points // 2:
            selected.append(best_point)
        
        remaining.remove(best_point)
    
    return selected

def is_endpoint_or_branch(skeleton, x, y):
    """检查是否是端点或分叉点"""
    if skeleton[y, x] == 0:
        return False
    neighbors = get_skeleton_neighbors(skeleton, x, y)
    return len(neighbors) == 1 or len(neighbors) >= 3

def skeleton_from_points(points):
    """从点集合创建一个简单的骨架图像（用于检测端点）"""
    if not points:
        return np.zeros((100, 100), dtype=np.uint8)
    
    max_x = max(int(p[0]) for p in points) + 1
    max_y = max(int(p[1]) for p in points) + 1
    skeleton = np.zeros((max_y, max_x), dtype=np.uint8)
    
    for x, y in points:
        skeleton[int(y), int(x)] = 1
    
    return skeleton

def extract_boundary_points(binary_img, num_points):
    """
    提取前景边界点
    
    Args:
        binary_img: 二值图像
        num_points: 需要提取的点数
    
    Returns:
        边界点列表
    """
    from scipy import ndimage
    
    # 找到前景边界
    boundary = ndimage.binary_dilation(binary_img) ^ binary_img
    y_coords, x_coords = np.where(boundary > 0)
    
    if len(x_coords) == 0:
        # 如果没有边界，使用前景中心点
        y_center, x_center = ndimage.center_of_mass(binary_img)
        return [(float(x_center), float(y_center))]
    
    # 随机采样
    indices = np.random.choice(len(x_coords), min(num_points, len(x_coords)), replace=False)
    boundary_points = [(float(x_coords[i]), float(y_coords[i])) for i in indices]
    
    return boundary_points