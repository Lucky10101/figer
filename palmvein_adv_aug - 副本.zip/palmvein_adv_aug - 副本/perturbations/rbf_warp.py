import torch
import torch.nn.functional as F
import numpy as np

def generate_keypoint_displacements(keypoints, max_disp, mode='random', seed=None):
    """
    对每个关键点生成小位移
    
    Args:
        keypoints: numpy array, shape [N, 2]，格式为 (x, y)
        max_disp: 最大位移（像素）
        mode: 位移模式，可选 'random', 'radial', 'horizontal', 'vertical', 'coherent_random'
        seed: 随机种子
    
    Returns:
        displacements: numpy array, shape [N, 2]，格式为 (dx, dy)
    """
    if seed is not None:
        np.random.seed(seed)
    
    num_points = len(keypoints)
    displacements = np.zeros((num_points, 2), dtype=np.float32)
    
    if mode == 'random':
        # 随机位移
        displacements[:, 0] = np.random.uniform(-max_disp, max_disp, num_points)
        displacements[:, 1] = np.random.uniform(-max_disp, max_disp, num_points)
    
    elif mode == 'radial':
        # 径向位移（从中心向外/向内）
        center_x = np.mean(keypoints[:, 0])
        center_y = np.mean(keypoints[:, 1])
        
        dx = keypoints[:, 0] - center_x
        dy = keypoints[:, 1] - center_y
        distances = np.sqrt(dx**2 + dy**2) + 1e-6
        
        # 归一化方向
        dx_norm = dx / distances
        dy_norm = dy / distances
        
        # 随机径向位移
        magnitudes = np.random.uniform(0, max_disp, num_points)
        signs = np.random.choice([-1, 1], num_points)
        magnitudes = magnitudes * signs
        
        displacements[:, 0] = dx_norm * magnitudes
        displacements[:, 1] = dy_norm * magnitudes
    
    elif mode == 'horizontal':
        # 水平位移
        displacements[:, 0] = np.random.uniform(-max_disp, max_disp, num_points)
        displacements[:, 1] = np.random.uniform(-max_disp * 0.3, max_disp * 0.3, num_points)
    
    elif mode == 'vertical':
        # 垂直位移
        displacements[:, 0] = np.random.uniform(-max_disp * 0.3, max_disp * 0.3, num_points)
        displacements[:, 1] = np.random.uniform(-max_disp, max_disp, num_points)
    
    elif mode == 'coherent_random':
        # 相干随机位移：所有关键点共享一个主方向，再叠加小随机扰动
        # 避免关键点位移互相抵消
        global_dx = np.random.uniform(-max_disp, max_disp)
        global_dy = np.random.uniform(-max_disp, max_disp)
        
        # 全局主方向
        displacements[:, 0] = global_dx
        displacements[:, 1] = global_dy
        
        # 叠加小随机扰动
        displacements[:, 0] += np.random.uniform(-0.5, 0.5, num_points)
        displacements[:, 1] += np.random.uniform(-0.5, 0.5, num_points)
    
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    return displacements

def rbf_interpolate_flow(keypoints, displacements, H, W, sigma, device, 
                         target_avg_disp=2.0, min_flow_abs_mean=0.5, max_disp=5.0):
    """
    根据关键点位移插值得到 dense flow
    
    Args:
        keypoints: numpy array, shape [N, 2]，格式为 (x, y)
        displacements: numpy array, shape [N, 2]，格式为 (dx, dy)
        H, W: 输出 flow 的尺寸
        sigma: RBF 高斯核标准差
        device: 设备
        target_avg_disp: 目标平均位移幅度
        min_flow_abs_mean: 最小平均位移幅度阈值
        max_disp: 最大位移限制
    
    Returns:
        flow: torch tensor, shape [1, 2, H, W]，单位为像素
    """
    num_keypoints = len(keypoints)
    
    if num_keypoints == 0:
        # 如果没有关键点，返回零流
        return torch.zeros(1, 2, H, W, device=device)
    
    # 转换为 torch tensor
    keypoints_tensor = torch.from_numpy(keypoints).float().to(device)  # [N, 2]
    displacements_tensor = torch.from_numpy(displacements).float().to(device)  # [N, 2]
    
    # 创建像素坐标网格
    y_coords = torch.arange(H, device=device).float()
    x_coords = torch.arange(W, device=device).float()
    yy, xx = torch.meshgrid(y_coords, x_coords)
    
    # 扩展维度以便广播
    pixel_coords = torch.stack([xx, yy], dim=2).reshape(-1, 2)  # [H*W, 2]
    
    # 计算每个像素到每个关键点的距离
    distances = torch.norm(pixel_coords.unsqueeze(1) - keypoints_tensor.unsqueeze(0), dim=2)  # [H*W, N]
    
    # 计算 RBF 权重
    weights = torch.exp(-distances.pow(2) / (2 * sigma ** 2))  # [H*W, N]
    
    # 归一化权重
    weights_sum = weights.sum(dim=1, keepdim=True) + 1e-8  # [H*W, 1]
    weights_normalized = weights / weights_sum  # [H*W, N]
    
    # 计算加权位移
    weighted_displacements = weights_normalized.unsqueeze(2) * displacements_tensor.unsqueeze(0)  # [H*W, N, 2]
    flow_flat = weighted_displacements.sum(dim=1)  # [H*W, 2]
    
    # 重塑为 [1, 2, H, W]
    flow = flow_flat.reshape(1, 2, H, W)
    
    # 应用高斯平滑
    flow = gaussian_smooth_flow(flow, kernel_size=5, sigma=sigma/3)
    
    # 计算 flow 统计
    flow_magnitude = torch.sqrt(flow[:, 0]**2 + flow[:, 1]**2)
    flow_abs_mean = flow_magnitude.mean().item()
    flow_abs_max = flow_magnitude.max().item()
    
    # 如果 flow_abs_mean 太小，则按比例放大
    if flow_abs_mean < min_flow_abs_mean:
        scale = target_avg_disp / (flow_abs_mean + 1e-6)
        flow = flow * scale
        flow_abs_mean = flow_abs_mean * scale
    
    # Clamp 到最大位移限制
    flow = torch.clamp(flow, -max_disp, max_disp)
    
    return flow

def gaussian_smooth_flow(flow, kernel_size=5, sigma=1.0):
    """
    对 flow 进行高斯平滑
    
    Args:
        flow: torch tensor, shape [1, 2, H, W]
        kernel_size: 高斯核大小
        sigma: 高斯核标准差
    
    Returns:
        平滑后的 flow
    """
    # 创建高斯核
    x = torch.arange(kernel_size, device=flow.device).float() - kernel_size // 2
    gauss = torch.exp(-x.pow(2) / (2 * sigma ** 2))
    gauss = gauss / gauss.sum()
    
    # 创建 2D 高斯核
    kernel_2d = gauss.unsqueeze(0) * gauss.unsqueeze(1)  # [K, K]
    kernel_2d = kernel_2d / kernel_2d.sum()
    
    # 扩展为 [1, 1, K, K]
    kernel = kernel_2d.unsqueeze(0).unsqueeze(0)
    
    # 对 flow 的每个通道分别卷积
    flow_smooth_x = F.conv2d(flow[:, 0:1], kernel, padding=kernel_size // 2)
    flow_smooth_y = F.conv2d(flow[:, 1:2], kernel, padding=kernel_size // 2)
    
    flow_smooth = torch.cat([flow_smooth_x, flow_smooth_y], dim=1)
    
    return flow_smooth