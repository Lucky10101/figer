import torch
import torch.nn.functional as F
import numpy as np
from .keypoint_utils import extract_skeleton_keypoints
from .rbf_warp import generate_keypoint_displacements, rbf_interpolate_flow
from .topology_filter import compute_topology_metrics, check_constraints, postprocess_binary
from .warp import warp_image
import random

def generate_mhoa_lite_aug(
    model,
    images,
    labels,
    max_keypoints=80,
    max_disp=3.0,
    rbf_sigma=18.0,
    binary_threshold=0.5,
    postprocess=True,
    num_trials=10,
    topology_cfg=None,
    device=None,
    disp_mode='random',
    target_avg_disp=2.0,
    min_flow_abs_mean=0.5
):
    """
    生成 MHOA-lite 结构保持形变增强

    Args:
        model: 预训练分类器
        images: 原始二值图像，shape [B, 1, H, W]，范围 [0, 1]
        labels: 原始标签，shape [B]
        max_keypoints: 最大关键点数量
        max_disp: 最大位移（像素）
        rbf_sigma: RBF 高斯核标准差
        binary_threshold: 二值化阈值
        postprocess: 是否进行后处理
        num_trials: 最大尝试次数
        topology_cfg: 拓扑约束配置
        device: 设备
        disp_mode: 位移模式
        target_avg_disp: 目标平均位移幅度
        min_flow_abs_mean: 最小平均位移幅度阈值

    Returns:
        aug_images: 增强后的二值图像
        flows: 位移场列表
        metrics_list: 每张图的指标字典列表
    """
    if device is None:
        device = images.device

    if topology_cfg is None:
        topology_cfg = {}

    batch_size, _, H, W = images.shape

    aug_images_list = []
    flows_list = []
    metrics_list = []

    for i in range(batch_size):
        img_tensor = images[i:i+1]  # [1, 1, H, W]
        label = labels[i]

        # 转换为 numpy
        img_np = img_tensor.squeeze().cpu().numpy()  # [H, W]
        img_binary = (img_np > binary_threshold).astype(np.float32)

        # 计算原始拓扑指标
        orig_metrics = compute_topology_metrics(img_binary)

        # 所有 trial 的记录
        all_trials = []

        # 最佳候选
        best_candidate = None
        best_candidate_score = float('-inf')

        for trial in range(num_trials):
            try:
                # 提取骨架关键点
                keypoints = extract_skeleton_keypoints(
                    img_binary,
                    max_points=max_keypoints,
                    min_distance=5
                )

                if len(keypoints) == 0:
                    all_trials.append({
                        'trial': trial,
                        'keep_correct': False,
                        'changed_pixel_ratio': 0,
                        'fg_diff': 0,
                        'component_diff': 0,
                        'endpoint_diff': 0,
                        'branchpoint_diff': 0,
                        'largest_component_ratio': 0,
                        'flow_abs_mean': 0,
                        'flow_abs_max': 0,
                        'continuous_l1': 0,
                        'continuous_l2': 0,
                        'reject_reason': 'no_keypoints'
                    })
                    continue

                # 生成关键点位移
                displacements = generate_keypoint_displacements(
                    keypoints,
                    max_disp=max_disp,
                    mode=disp_mode,
                    seed=None
                )

                # RBF 插值得到 dense flow
                flow = rbf_interpolate_flow(
                    keypoints,
                    displacements,
                    H, W,
                    sigma=rbf_sigma,
                    device=device,
                    target_avg_disp=target_avg_disp,
                    min_flow_abs_mean=min_flow_abs_mean,
                    max_disp=max_disp
                )

                # 计算 flow 统计
                flow_magnitude = torch.sqrt(flow[:, 0]**2 + flow[:, 1]**2)
                flow_abs_mean = flow_magnitude.mean().item()
                flow_abs_max = flow_magnitude.max().item()

                # Warp 图像
                warped = warp_image(img_tensor, flow)

                # 计算连续图像的差异
                continuous_diff = warped - img_tensor
                continuous_l1 = torch.abs(continuous_diff).mean().item()
                continuous_l2 = torch.sqrt((continuous_diff**2).mean()).item()

                # 二值化
                aug_binary = (warped > binary_threshold).float()
                aug_np = aug_binary.squeeze().cpu().numpy()

                # 计算二值变化比例
                changed_pixel_ratio = np.abs(aug_np - img_binary).mean()

                # 检查 flow 是否太小
                if flow_abs_mean < min_flow_abs_mean:
                    all_trials.append({
                        'trial': trial,
                        'keep_correct': False,
                        'changed_pixel_ratio': changed_pixel_ratio,
                        'fg_diff': abs(aug_np.mean() - img_binary.mean()),
                        'component_diff': 0,
                        'endpoint_diff': 0,
                        'branchpoint_diff': 0,
                        'largest_component_ratio': 0,
                        'flow_abs_mean': flow_abs_mean,
                        'flow_abs_max': flow_abs_max,
                        'continuous_l1': continuous_l1,
                        'continuous_l2': continuous_l2,
                        'reject_reason': f'flow_too_small:{flow_abs_mean:.4f}<{min_flow_abs_mean}'
                    })
                    continue

                # 检查二值变化是否为零
                if changed_pixel_ratio == 0:
                    if continuous_l1 > 0.001:
                        trial_reject_reason = 'threshold_erased_change'
                    else:
                        trial_reject_reason = 'no_binary_change'

                    all_trials.append({
                        'trial': trial,
                        'keep_correct': False,
                        'changed_pixel_ratio': 0,
                        'fg_diff': 0,
                        'component_diff': 0,
                        'endpoint_diff': 0,
                        'branchpoint_diff': 0,
                        'largest_component_ratio': 0,
                        'flow_abs_mean': flow_abs_mean,
                        'flow_abs_max': flow_abs_max,
                        'continuous_l1': continuous_l1,
                        'continuous_l2': continuous_l2,
                        'reject_reason': trial_reject_reason
                    })
                    continue

                # 后处理
                if postprocess:
                    aug_np_processed = postprocess_binary(aug_np, closing_size=3, min_object_size=5)
                else:
                    aug_np_processed = aug_np

                # 计算增强图像的拓扑指标
                aug_metrics = compute_topology_metrics(aug_np_processed)
                aug_metrics['changed_pixel_ratio'] = changed_pixel_ratio

                # 检查分类器是否保持（原始图像和增强图像都必须预测正确）
                model.eval()
                with torch.no_grad():
                    # 检查原始图像预测
                    orig_tensor = torch.from_numpy(img_binary).unsqueeze(0).unsqueeze(0).float().to(device)
                    orig_logits = model(orig_tensor)
                    orig_pred = orig_logits.argmax(dim=1).item()

                    # 检查增强图像预测
                    aug_tensor = torch.from_numpy(aug_np_processed).unsqueeze(0).unsqueeze(0).float().to(device)
                    aug_logits = model(aug_tensor)
                    aug_pred = aug_logits.argmax(dim=1).item()

                # keep_correct = 原始图像预测正确 AND 增强图像预测正确
                classifier_keep = (orig_pred == label.item()) and (aug_pred == label.item())

                # 计算差异
                fg_diff = abs(aug_metrics['foreground_ratio'] - orig_metrics['foreground_ratio'])
                component_diff = abs(aug_metrics['num_components'] - orig_metrics['num_components'])
                endpoint_diff = abs(aug_metrics['num_endpoints'] - orig_metrics['num_endpoints'])
                branchpoint_diff = abs(aug_metrics['num_branchpoints'] - orig_metrics['num_branchpoints'])

                # 检查拓扑约束
                current_cfg = {**topology_cfg, 'changed_pixel_ratio': changed_pixel_ratio}
                trial_accepted, reject_reasons, hard_reject, soft_reasons = check_constraints(
                    orig_metrics, aug_metrics, classifier_keep, current_cfg
                )

                # 记录 trial
                trial_record = {
                    'trial': trial,
                    'keep_correct': classifier_keep,
                    'changed_pixel_ratio': changed_pixel_ratio,
                    'fg_diff': fg_diff,
                    'component_diff': component_diff,
                    'endpoint_diff': endpoint_diff,
                    'branchpoint_diff': branchpoint_diff,
                    'largest_component_ratio': aug_metrics['largest_component_ratio'],
                    'flow_abs_mean': flow_abs_mean,
                    'flow_abs_max': flow_abs_max,
                    'continuous_l1': continuous_l1,
                    'continuous_l2': continuous_l2,
                    'reject_reason': '; '.join(reject_reasons) if reject_reasons else ('accepted' if trial_accepted else 'unknown')
                }
                all_trials.append(trial_record)

                # 如果被接受，保存为最佳候选
                if trial_accepted:
                    best_candidate = {
                        'aug': aug_np_processed,
                        'flow': flow.squeeze().cpu().numpy(),
                        'metrics': aug_metrics,
                        'pred': pred,
                        'classifier_keep': classifier_keep,
                        'fg_diff': fg_diff,
                        'component_diff': component_diff,
                        'endpoint_diff': endpoint_diff,
                        'branchpoint_diff': branchpoint_diff,
                        'changed_pixel_ratio': changed_pixel_ratio,
                        'flow_abs_mean': flow_abs_mean,
                        'flow_abs_max': flow_abs_max,
                        'continuous_l1': continuous_l1,
                        'continuous_l2': continuous_l2,
                        'reject_reason': 'accepted'
                    }
                    # 计算得分
                    score = (1.0 if classifier_keep else 0.0) * 100 + changed_pixel_ratio * 10 - fg_diff
                    if score > best_candidate_score:
                        best_candidate_score = score
                    # 找到 accepted 就退出
                    break

            except Exception as e:
                all_trials.append({
                    'trial': trial,
                    'keep_correct': False,
                    'changed_pixel_ratio': 0,
                    'fg_diff': 0,
                    'component_diff': 0,
                    'endpoint_diff': 0,
                    'branchpoint_diff': 0,
                    'largest_component_ratio': 0,
                    'flow_abs_mean': 0,
                    'flow_abs_max': 0,
                    'continuous_l1': 0,
                    'continuous_l2': 0,
                    'reject_reason': f'error:{str(e)}'
                })
                continue

        # 如果没有找到 accepted，选择 best candidate
        if best_candidate is None:
            # 从所有 trial 中选择最佳候选
            for trial_record in all_trials:
                if trial_record['keep_correct'] and trial_record['changed_pixel_ratio'] > 0:
                    # 计算得分
                    score = 1.0 * 100 + trial_record['changed_pixel_ratio'] * 10 - trial_record['fg_diff']
                    if score > best_candidate_score:
                        best_candidate_score = score
                        # 重新生成该 trial 的结果
                        best_candidate = recreate_candidate_from_trial(
                            model, img_tensor, label, img_binary, trial_record,
                            max_keypoints, max_disp, rbf_sigma, binary_threshold, postprocess,
                            disp_mode, target_avg_disp, min_flow_abs_mean, device, topology_cfg, orig_metrics
                        )

            # 如果仍然没有候选，尝试 fallback
            if best_candidate is None:
                fallback_result = try_fallback(
                    model, img_tensor, label, img_binary, max_disp, binary_threshold, device
                )
                if fallback_result is not None:
                    best_candidate = fallback_result
                else:
                    # 使用原始图像
                    best_candidate = {
                        'aug': img_binary,
                        'flow': np.zeros((2, H, W), dtype=np.float32),
                        'metrics': orig_metrics,
                        'pred': label.item(),
                        'classifier_keep': True,
                        'fg_diff': 0,
                        'component_diff': 0,
                        'endpoint_diff': 0,
                        'branchpoint_diff': 0,
                        'changed_pixel_ratio': 0,
                        'flow_abs_mean': 0,
                        'flow_abs_max': 0,
                        'continuous_l1': 0,
                        'continuous_l2': 0,
                        'reject_reason': 'all_trials_failed_using_original'
                    }

        # 添加到结果列表
        aug_images_list.append(torch.from_numpy(best_candidate['aug']).unsqueeze(0).unsqueeze(0).float().to(device))
        flows_list.append(best_candidate['flow'])

        final_metrics = {
            'filename': '',
            'label': label.item(),
            'pred': best_candidate['pred'],
            'accepted': 1 if best_candidate['reject_reason'] == 'accepted' else 0,
            'reject_reason': best_candidate['reject_reason'],
            'classifier_keep': 1 if best_candidate['classifier_keep'] else 0,
            'changed_pixel_ratio': best_candidate['changed_pixel_ratio'],
            'flow_abs_mean': best_candidate['flow_abs_mean'],
            'flow_abs_max': best_candidate['flow_abs_max'],
            'continuous_l1': best_candidate['continuous_l1'],
            'continuous_l2': best_candidate['continuous_l2'],
            'orig_fg': orig_metrics['foreground_ratio'],
            'aug_fg': best_candidate['metrics']['foreground_ratio'],
            'fg_diff': best_candidate['fg_diff'],
            'component_diff': best_candidate['component_diff'],
            'endpoint_diff': best_candidate['endpoint_diff'],
            'branchpoint_diff': best_candidate['branchpoint_diff'],
            'num_components': best_candidate['metrics']['num_components'],
            'num_endpoints': best_candidate['metrics']['num_endpoints'],
            'num_branchpoints': best_candidate['metrics']['num_branchpoints'],
            'all_trials': all_trials
        }
        metrics_list.append(final_metrics)

    # 合并 batch
    aug_images = torch.cat(aug_images_list, dim=0)

    return aug_images, flows_list, metrics_list

def recreate_candidate_from_trial(
    model, img_tensor, label, img_binary, trial_record,
    max_keypoints, max_disp, rbf_sigma, binary_threshold, postprocess,
    disp_mode, target_avg_disp, min_flow_abs_mean, device, topology_cfg, orig_metrics
):
    """从 trial 记录重新生成候选"""
    try:
        keypoints = extract_skeleton_keypoints(img_binary, max_points=max_keypoints, min_distance=5)

        if len(keypoints) == 0:
            return None

        displacements = generate_keypoint_displacements(keypoints, max_disp=max_disp, mode=disp_mode, seed=None)

        flow = rbf_interpolate_flow(
            keypoints, displacements, img_binary.shape[0], img_binary.shape[1],
            sigma=rbf_sigma, device=device,
            target_avg_disp=target_avg_disp,
            min_flow_abs_mean=min_flow_abs_mean,
            max_disp=max_disp
        )

        warped = warp_image(img_tensor, flow)
        aug_binary = (warped > binary_threshold).float()
        aug_np = aug_binary.squeeze().cpu().numpy()

        if postprocess:
            aug_np = postprocess_binary(aug_np, closing_size=3, min_object_size=5)

        aug_metrics = compute_topology_metrics(aug_np)

        model.eval()
        with torch.no_grad():
            aug_tensor = torch.from_numpy(aug_np).unsqueeze(0).unsqueeze(0).float().to(device)
            logits = model(aug_tensor)
            pred = logits.argmax(dim=1).item()

        classifier_keep = (pred == label.item())

        return {
            'aug': aug_np,
            'flow': flow.squeeze().cpu().numpy(),
            'metrics': aug_metrics,
            'pred': pred,
            'classifier_keep': classifier_keep,
            'fg_diff': abs(aug_metrics['foreground_ratio'] - orig_metrics['foreground_ratio']),
            'component_diff': abs(aug_metrics['num_components'] - orig_metrics['num_components']),
            'endpoint_diff': abs(aug_metrics['num_endpoints'] - orig_metrics['num_endpoints']),
            'branchpoint_diff': abs(aug_metrics['num_branchpoints'] - orig_metrics['num_branchpoints']),
            'changed_pixel_ratio': trial_record['changed_pixel_ratio'],
            'flow_abs_mean': trial_record['flow_abs_mean'],
            'flow_abs_max': trial_record['flow_abs_max'],
            'continuous_l1': trial_record['continuous_l1'],
            'continuous_l2': trial_record['continuous_l2'],
            'reject_reason': trial_record['reject_reason']
        }
    except:
        return None

def try_fallback(model, img_tensor, label, img_binary, max_disp, binary_threshold, device):
    """尝试 fallback 全局平移"""
    try:
        fallback_flow = generate_global_translation_flow(1, img_binary.shape[0], img_binary.shape[1], max_disp, device)
        fallback_warped = warp_image(img_tensor, fallback_flow)
        fallback_binary = (fallback_warped > binary_threshold).float()
        fallback_np = fallback_binary.squeeze().cpu().numpy()

        changed_ratio = np.abs(fallback_np - img_binary).mean()

        if changed_ratio > 0:
            aug_metrics = compute_topology_metrics(fallback_np)

            model.eval()
            with torch.no_grad():
                aug_tensor = torch.from_numpy(fallback_np).unsqueeze(0).unsqueeze(0).float().to(device)
                logits = model(aug_tensor)
                pred = logits.argmax(dim=1).item()

            fallback_flow_mag = torch.sqrt(fallback_flow[:, 0]**2 + fallback_flow[:, 1]**2)

            return {
                'aug': fallback_np,
                'flow': fallback_flow.squeeze().cpu().numpy(),
                'metrics': aug_metrics,
                'pred': pred,
                'classifier_keep': (pred == label.item()),
                'fg_diff': abs(aug_metrics['foreground_ratio'] - img_binary.mean()),
                'component_diff': abs(aug_metrics['num_components'] - 1),
                'endpoint_diff': abs(aug_metrics['num_endpoints']),
                'branchpoint_diff': abs(aug_metrics['num_branchpoints']),
                'changed_pixel_ratio': changed_ratio,
                'flow_abs_mean': fallback_flow_mag.mean().item(),
                'flow_abs_max': fallback_flow_mag.max().item(),
                'continuous_l1': torch.abs(fallback_warped - img_tensor).mean().item(),
                'continuous_l2': torch.sqrt(((fallback_warped - img_tensor)**2).mean()).item(),
                'reject_reason': 'fallback_global_translation'
            }
    except:
        pass
    return None

def generate_global_translation_flow(batch_size, H, W, max_disp, device):
    """
    生成全局平移 flow（fallback 机制）

    Args:
        batch_size: 批次大小
        H, W: 图像尺寸
        max_disp: 最大位移
        device: 设备

    Returns:
        flow: 位移场，shape [batch_size, 2, H, W]
    """
    flow = torch.zeros(batch_size, 2, H, W, device=device)

    # 随机生成全局平移
    dx = np.random.uniform(-max_disp, max_disp)
    dy = np.random.uniform(-max_disp, max_disp)

    flow[:, 0, :, :] = dx
    flow[:, 1, :, :] = dy

    return flow

def compute_mhoa_metrics(model, original, augmented, labels, device):
    """
    计算 MHOA 增强的评估指标

    Args:
        model: 分类器
        original: 原始图像 [B, 1, H, W]
        augmented: 增强图像 [B, 1, H, W]
        labels: 标签 [B]
        device: 设备

    Returns:
        metrics dict
    """
    model.eval()

    with torch.no_grad():
        # 原始图像预测
        orig_logits = model(original)
        orig_preds = orig_logits.argmax(dim=1)
        orig_acc = (orig_preds == labels).float().mean().item()

        # 增强图像预测
        aug_logits = model(augmented)
        aug_preds = aug_logits.argmax(dim=1)
        aug_acc = (aug_preds == labels).float().mean().item()

        # 保持率
        keep_mask = (orig_preds == labels) & (aug_preds == labels)
        keep_rate = keep_mask.float().mean().item()

    # 变化像素比例
    changed_pixel_ratio = torch.abs(augmented - original).mean().item()

    # 前景比例
    orig_fg = original.mean().item()
    aug_fg = augmented.mean().item()
    fg_diff = abs(aug_fg - orig_fg)

    return {
        'original_acc': orig_acc,
        'augmented_acc': aug_acc,
        'keep_rate': keep_rate,
        'changed_pixel_ratio': changed_pixel_ratio,
        'orig_fg': orig_fg,
        'aug_fg': aug_fg,
        'fg_diff': fg_diff
    }