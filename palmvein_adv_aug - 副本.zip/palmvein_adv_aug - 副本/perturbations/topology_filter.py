import numpy as np
from skimage import morphology, measure
from scipy import ndimage

def compute_topology_metrics(binary_img):
    """
    计算拓扑指标

    Args:
        binary_img: numpy array, H×W, 值为 0 或 1

    Returns:
        metrics dict
    """
    binary_img = (binary_img > 0).astype(np.uint8)
    h, w = binary_img.shape

    # 前景比例
    foreground_ratio = binary_img.mean()

    # 连通域分析
    labeled_array, num_components = ndimage.label(binary_img)

    if num_components == 0:
        largest_component_ratio = 0
    else:
        # 找到最大连通域
        component_sizes = ndimage.sum(binary_img, labeled_array, range(1, num_components + 1))
        largest_component_size = max(component_sizes) if len(component_sizes) > 0 else 0
        largest_component_ratio = largest_component_size / (h * w)

    # 骨架分析
    try:
        skeleton = morphology.skeletonize(binary_img)
        skeleton_length = skeleton.sum()
    except:
        skeleton_length = 0

    # 端点和分叉点
    num_endpoints = count_endpoints(binary_img)
    num_branchpoints = count_branchpoints(binary_img)

    return {
        'foreground_ratio': foreground_ratio,
        'num_components': num_components,
        'largest_component_ratio': largest_component_ratio,
        'skeleton_length': skeleton_length,
        'num_endpoints': num_endpoints,
        'num_branchpoints': num_branchpoints
    }

def count_endpoints(binary_img):
    """
    统计端点数量

    Args:
        binary_img: 二值图像

    Returns:
        端点数量
    """
    if binary_img.sum() == 0:
        return 0

    skeleton = morphology.skeletonize(binary_img)

    # 8邻域偏移
    offsets = [
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1),          (0, 1),
        (1, -1),  (1, 0), (1, 1)
    ]

    h, w = skeleton.shape
    endpoints = 0

    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if skeleton[y, x] == 0:
                continue

            neighbors = 0
            for dx, dy in offsets:
                if skeleton[y + dy, x + dx] > 0:
                    neighbors += 1

            if neighbors == 1:
                endpoints += 1

    return endpoints

def count_branchpoints(binary_img):
    """
    统计分叉点数量

    Args:
        binary_img: 二值图像

    Returns:
        分叉点数量
    """
    if binary_img.sum() == 0:
        return 0

    skeleton = morphology.skeletonize(binary_img)

    # 8邻域偏移
    offsets = [
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1),          (0, 1),
        (1, -1),  (1, 0), (1, 1)
    ]

    h, w = skeleton.shape
    branchpoints = 0

    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if skeleton[y, x] == 0:
                continue

            neighbors = 0
            for dx, dy in offsets:
                if skeleton[y + dy, x + dx] > 0:
                    neighbors += 1

            if neighbors >= 3:
                branchpoints += 1

    return branchpoints

def check_constraints(orig_metrics, aug_metrics, classifier_keep, cfg):
    """
    检查增强样本是否满足拓扑约束

    Args:
        orig_metrics: 原始图像的拓扑指标
        aug_metrics: 增强图像的拓扑指标
        classifier_keep: 分类器是否保持正确
        cfg: 配置字典

    Returns:
        (accepted, reject_reasons_list, hard_reject, soft_reasons_list)
        - accepted: 是否接受
        - reject_reasons_list: 拒绝原因列表
        - hard_reject: 是否是硬约束拒绝
        - soft_reasons_list: 软约束违反原因（只记录不拒绝）
    """
    reject_reasons = []
    soft_reasons = []

    # 计算差异
    fg_diff = abs(aug_metrics['foreground_ratio'] - orig_metrics['foreground_ratio'])
    component_diff = abs(aug_metrics['num_components'] - orig_metrics['num_components'])
    endpoint_diff = abs(aug_metrics['num_endpoints'] - orig_metrics['num_endpoints'])
    branchpoint_diff = abs(aug_metrics['num_branchpoints'] - orig_metrics['num_branchpoints'])

    # 硬约束检查（无论 strict_topology_filter 如何都会拒绝）
    # 1. 分类器保持检查
    if not classifier_keep:
        reject_reasons.append('classifier_changed')
        return False, reject_reasons, True, soft_reasons

    # 2. 前景比例变化检查
    max_fg_diff = cfg.get('max_fg_diff', 0.03)
    if fg_diff > max_fg_diff:
        reject_reasons.append(f'fg_diff_too_large:{fg_diff:.4f}>{max_fg_diff}')
        return False, reject_reasons, True, soft_reasons

    # 3. 变化像素比例检查
    min_changed = cfg.get('min_changed_ratio', 0.01)
    max_changed = cfg.get('max_changed_ratio', 0.20)
    changed_ratio = cfg.get('changed_pixel_ratio', 0)

    if changed_ratio < min_changed:
        reject_reasons.append(f'changed_ratio_too_small:{changed_ratio:.4f}<{min_changed}')
        return False, reject_reasons, True, soft_reasons
    if changed_ratio > max_changed:
        reject_reasons.append(f'changed_ratio_too_large:{changed_ratio:.4f}>{max_changed}')
        return False, reject_reasons, True, soft_reasons

    # 如果 strict_topology_filter=false，只用上面的硬约束
    strict_topology = cfg.get('strict_topology_filter', True)
    if not strict_topology:
        # 软约束：只记录，不拒绝
        if component_diff > cfg.get('max_component_diff', 50):
            soft_reasons.append(f'component_diff:{component_diff}')
        if endpoint_diff > cfg.get('max_endpoint_diff', 200):
            soft_reasons.append(f'endpoint_diff:{endpoint_diff}')
        if branchpoint_diff > cfg.get('max_branchpoint_diff', 500):
            soft_reasons.append(f'branchpoint_diff:{branchpoint_diff}')
        if aug_metrics['largest_component_ratio'] < cfg.get('min_largest_component_ratio', 0.3):
            soft_reasons.append(f'largest_ratio:{aug_metrics["largest_component_ratio"]:.4f}')

        return True, soft_reasons, False, soft_reasons

    # strict_topology_filter=true 时，启用全部拓扑约束
    # 4. 连通域数量变化检查
    max_component_diff = cfg.get('max_component_diff', 3)
    if component_diff > max_component_diff:
        reject_reasons.append(f'component_diff_too_large:{component_diff}>{max_component_diff}')

    # 5. 端点数量变化检查
    max_endpoint_diff = cfg.get('max_endpoint_diff', 10)
    if endpoint_diff > max_endpoint_diff:
        reject_reasons.append(f'endpoint_diff_too_large:{endpoint_diff}>{max_endpoint_diff}')

    # 6. 分叉点数量变化检查
    max_branchpoint_diff = cfg.get('max_branchpoint_diff', 10)
    if branchpoint_diff > max_branchpoint_diff:
        reject_reasons.append(f'branchpoint_diff_too_large:{branchpoint_diff}>{max_branchpoint_diff}')

    # 7. 最大连通域比例检查
    min_largest_ratio = cfg.get('min_largest_component_ratio', 0.6)
    if aug_metrics['largest_component_ratio'] < min_largest_ratio:
        reject_reasons.append(f'largest_ratio_too_small:{aug_metrics["largest_component_ratio"]:.4f}<{min_largest_ratio}')

    if reject_reasons:
        return False, reject_reasons, True, soft_reasons
    else:
        return True, [], False, soft_reasons

def postprocess_binary(binary_img, closing_size=3, min_object_size=5):
    """
    对二值图像进行后处理，修复小断裂并去除小噪声

    Args:
        binary_img: numpy array, H×W, 值为 0 或 1
        closing_size: morphology closing 的结构元素大小
        min_object_size: 最小连通域大小

    Returns:
        处理后的二值图像
    """
    binary_img = binary_img.astype(np.uint8)

    # Morphology closing 修复小断裂
    selem = morphology.disk(closing_size)
    closed = morphology.binary_closing(binary_img, selem)

    # 去除小噪声
    labeled, num_features = ndimage.label(closed)
    if num_features > 0:
        component_sizes = ndimage.sum(closed, labeled, range(1, num_features + 1))
        for i, size in enumerate(component_sizes, 1):
            if size < min_object_size:
                closed[labeled == i] = 0

    return closed.astype(np.uint8)