import torch
import numpy as np
from scipy import ndimage
from skimage import morphology
from .keypoint_utils import extract_skeleton_keypoints
from .rbf_warp import generate_keypoint_displacements, rbf_interpolate_flow
from .warp import warp_image
from .topology_filter import compute_topology_metrics, check_constraints, postprocess_binary

def compute_skeleton_distance_mask(binary_img, sigma_vessel):
    """
    计算骨架距离衰减 mask

    Args:
        binary_img: numpy array, H×W, 值为 0 或 1
        sigma_vessel: 控制骨架邻域影响范围

    Returns:
        skeleton: 骨架图像
        distance_mask: 距离衰减 mask，范围 [0, 1]
    """
    binary_img = (binary_img > 0).astype(np.uint8)

    if binary_img.sum() == 0:
        return np.zeros_like(binary_img), np.zeros_like(binary_img).astype(np.float32)

    # 提取骨架
    try:
        skeleton = morphology.skeletonize(binary_img).astype(np.uint8)
    except:
        skeleton = binary_img.copy()

    # 计算每个像素到骨架的距离
    distance = ndimage.distance_transform_edt(skeleton)

    # 计算距离衰减 mask：高斯衰减
    distance_mask = np.exp(-(distance ** 2) / (2 * sigma_vessel ** 2))

    # 归一化到 [0, 1]（已经在范围内，但确保类型正确）
    distance_mask = distance_mask.astype(np.float32)

    return skeleton, distance_mask

def apply_centerline_decay_to_flow(flow, distance_mask):
    """
    将中心线衰减应用于 flow

    Args:
        flow: 位移场，shape [1, 2, H, W]
        distance_mask: 距离衰减 mask，shape [H, W]

    Returns:
        flow_local: 应用衰减后的位移场，shape [1, 2, H, W]
    """
    # 转换 distance_mask 为 tensor
    if isinstance(distance_mask, np.ndarray):
        distance_mask_tensor = torch.from_numpy(distance_mask).float()
    else:
        distance_mask_tensor = distance_mask.float()

    # 扩展维度：[H, W] -> [1, 1, H, W]
    distance_mask_tensor = distance_mask_tensor.unsqueeze(0).unsqueeze(0)

    # 确保与 flow 在同一设备
    if flow.is_cuda:
        distance_mask_tensor = distance_mask_tensor.to(flow.device)
    else:
        distance_mask_tensor = distance_mask_tensor

    # 应用衰减：flow_local = flow * distance_mask
    flow_local = flow * distance_mask_tensor

    return flow_local

def generate_centerline_local_deform_aug(
    model,
    image,
    label,
    cfg,
    device
):
    """
    生成中心线驱动的局部结构保持形变增强

    Args:
        model: 预训练分类器
        image: 原始二值图像，shape [1, 1, H, W]，范围 [0, 1]
        label: 标签
        cfg: 配置字典
        device: 设备

    Returns:
        aug_binary: 增强后的二值图像
        flow_global: 全局位移场
        flow_local: 局部位移场
        skeleton: 骨架图像
        distance_mask: 距离衰减 mask
        metrics: 指标字典
    """
    # 提取配置
    max_keypoints = cfg.get('max_keypoints', 80)
    disp_mode = cfg.get('disp_mode', 'coherent_random')
    max_disp = cfg.get('max_disp', 3.0)
    target_avg_disp = cfg.get('target_avg_disp', 1.2)
    rbf_sigma = cfg.get('rbf_sigma', 8.0)
    use_centerline_decay = cfg.get('use_centerline_decay', True)
    sigma_vessel = cfg.get('sigma_vessel', 6.0)
    binary_threshold = cfg.get('binary_threshold', 0.45)
    postprocess = cfg.get('postprocess', True)
    closing_radius = cfg.get('closing_radius', 1)
    min_object_size = cfg.get('min_object_size', 8)
    num_trials = cfg.get('num_trials', 20)
    min_changed_ratio = cfg.get('min_changed_ratio', 0.005)
    max_changed_ratio = cfg.get('max_changed_ratio', 0.18)
    max_fg_diff = cfg.get('max_fg_diff', 0.05)
    strict_topology_filter = cfg.get('strict_topology_filter', False)
    topology_cfg = {
        'max_fg_diff': max_fg_diff,
        'max_component_diff': cfg.get('max_component_diff', 50),
        'max_endpoint_diff': cfg.get('max_endpoint_diff', 200),
        'max_branchpoint_diff': cfg.get('max_branchpoint_diff', 500),
        'min_largest_component_ratio': cfg.get('min_largest_component_ratio', 0.3),
        'min_changed_ratio': min_changed_ratio,
        'max_changed_ratio': max_changed_ratio,
        'strict_topology_filter': strict_topology_filter
    }

    # 转换为 numpy
    img_np = image.squeeze().cpu().numpy()  # [H, W]
    img_binary = (img_np > binary_threshold).astype(np.float32)
    H, W = img_binary.shape

    # 计算原始拓扑指标
    orig_metrics = compute_topology_metrics(img_binary)

    # 提取骨架和距离 mask
    skeleton, distance_mask = compute_skeleton_distance_mask(img_binary, sigma_vessel)

    # 转换 image 为 tensor（如果需要）
    if isinstance(image, np.ndarray):
        img_tensor = torch.from_numpy(img_np).unsqueeze(0).unsqueeze(0).float().to(device)
    else:
        img_tensor = image

    # 尝试生成合格的增强图像
    best_candidate = None
    best_candidate_score = float('-inf')

    for trial in range(num_trials):
        try:
            # 提取骨架关键点
            keypoints = extract_skeleton_keypoints(
                img_binary,
                max_points=max_keypoints,
                min_distance=5
            )

            if len(keypoints) == 0:
                continue

            # 生成关键点位移
            displacements = generate_keypoint_displacements(
                keypoints,
                max_disp=max_disp,
                mode=disp_mode,
                seed=None
            )

            # RBF 插值得到全局 flow
            flow_global = rbf_interpolate_flow(
                keypoints,
                displacements,
                H, W,
                sigma=rbf_sigma,
                device=device,
                target_avg_disp=target_avg_disp,
                min_flow_abs_mean=0.5,
                max_disp=max_disp
            )

            # 计算全局 flow 统计
            flow_global_mag = torch.sqrt(flow_global[:, 0]**2 + flow_global[:, 1]**2)
            flow_global_abs_mean = flow_global_mag.mean().item()
            flow_global_abs_max = flow_global_mag.max().item()

            # 应用中心线衰减
            if use_centerline_decay:
                flow_local = apply_centerline_decay_to_flow(flow_global, distance_mask)
            else:
                flow_local = flow_global

            # 计算局部 flow 统计
            flow_local_mag = torch.sqrt(flow_local[:, 0]**2 + flow_local[:, 1]**2)
            flow_local_abs_mean = flow_local_mag.mean().item()
            flow_local_abs_max = flow_local_mag.max().item()

            # 计算局部 flow 衰减比例
            if flow_global_abs_mean > 0:
                local_flow_reduction_ratio = 1.0 - (flow_local_abs_mean / flow_global_abs_mean)
            else:
                local_flow_reduction_ratio = 0.0

            # Warp 图像
            warped = warp_image(img_tensor, flow_local)

            # 计算连续图像差异
            continuous_diff = warped - img_tensor
            continuous_l1 = torch.abs(continuous_diff).mean().item()
            continuous_l2 = torch.sqrt((continuous_diff**2).mean()).item()

            # 二值化
            aug_binary_np = (warped.squeeze().cpu().numpy() > binary_threshold).astype(np.float32)

            # 计算二值变化比例
            changed_pixel_ratio = np.abs(aug_binary_np - img_binary).mean()

            # 检查二值变化是否太小
            if changed_pixel_ratio < min_changed_ratio:
                continue

            # 后处理
            if postprocess:
                aug_binary_processed = postprocess_binary(
                    aug_binary_np.astype(np.uint8),
                    closing_size=closing_radius,
                    min_object_size=min_object_size
                ).astype(np.float32)
            else:
                aug_binary_processed = aug_binary_np

            # 计算增强图像的拓扑指标
            aug_metrics = compute_topology_metrics(aug_binary_processed)

            # 检查分类器是否保持（原始和增强都必须预测正确）
            model.eval()
            with torch.no_grad():
                # 原始图像预测
                orig_tensor = torch.from_numpy(img_binary).unsqueeze(0).unsqueeze(0).float().to(device)
                orig_logits = model(orig_tensor)
                orig_pred = orig_logits.argmax(dim=1).item()

                # 增强图像预测
                aug_tensor = torch.from_numpy(aug_binary_processed).unsqueeze(0).unsqueeze(0).float().to(device)
                aug_logits = model(aug_tensor)
                aug_pred = aug_logits.argmax(dim=1).item()

            classifier_keep = (orig_pred == label) and (aug_pred == label)

            # 计算差异
            fg_diff = abs(aug_metrics['foreground_ratio'] - orig_metrics['foreground_ratio'])
            component_diff = abs(aug_metrics['num_components'] - orig_metrics['num_components'])
            endpoint_diff = abs(aug_metrics['num_endpoints'] - orig_metrics['num_endpoints'])
            branchpoint_diff = abs(aug_metrics['num_branchpoints'] - orig_metrics['num_branchpoints'])
            skeleton_length_diff = abs(aug_metrics['skeleton_length'] - orig_metrics['skeleton_length'])

            # 检查约束
            current_cfg = {**topology_cfg, 'changed_pixel_ratio': changed_pixel_ratio}
            accepted, reject_reasons, hard_reject, soft_reasons = check_constraints(
                orig_metrics, aug_metrics, classifier_keep, current_cfg
            )

            # 计算得分
            if classifier_keep and min_changed_ratio <= changed_pixel_ratio <= max_changed_ratio and fg_diff <= max_fg_diff:
                score = 100.0 + changed_pixel_ratio * 10 - fg_diff
            else:
                score = -1000.0 + changed_pixel_ratio * 10 - fg_diff

            if score > best_candidate_score:
                best_candidate_score = score
                best_candidate = {
                    'aug': aug_binary_processed,
                    'flow_global': flow_global.squeeze().cpu().numpy(),
                    'flow_local': flow_local.squeeze().cpu().numpy(),
                    'skeleton': skeleton,
                    'distance_mask': distance_mask,
                    'pred': aug_pred,
                    'orig_pred': orig_pred,
                    'classifier_keep': classifier_keep,
                    'changed_pixel_ratio': changed_pixel_ratio,
                    'fg_diff': fg_diff,
                    'component_diff': component_diff,
                    'endpoint_diff': endpoint_diff,
                    'branchpoint_diff': branchpoint_diff,
                    'skeleton_length_diff': skeleton_length_diff,
                    'flow_global_abs_mean': flow_global_abs_mean,
                    'flow_global_abs_max': flow_global_abs_max,
                    'flow_local_abs_mean': flow_local_abs_mean,
                    'flow_local_abs_max': flow_local_abs_max,
                    'local_flow_reduction_ratio': local_flow_reduction_ratio,
                    'continuous_l1': continuous_l1,
                    'continuous_l2': continuous_l2,
                    'reject_reason': '; '.join(reject_reasons) if reject_reasons else ('accepted' if accepted else 'unknown'),
                    'accepted': accepted
                }

            if accepted:
                break

        except Exception as e:
            continue

    # 如果没有找到合格候选，选择最佳候选
    if best_candidate is None:
        # 使用原始图像
        best_candidate = {
            'aug': img_binary,
            'flow_global': np.zeros((2, H, W), dtype=np.float32),
            'flow_local': np.zeros((2, H, W), dtype=np.float32),
            'skeleton': skeleton,
            'distance_mask': distance_mask,
            'pred': label,
            'orig_pred': label,
            'classifier_keep': True,
            'changed_pixel_ratio': 0.0,
            'fg_diff': 0.0,
            'component_diff': 0.0,
            'endpoint_diff': 0.0,
            'branchpoint_diff': 0.0,
            'skeleton_length_diff': 0.0,
            'flow_global_abs_mean': 0.0,
            'flow_global_abs_max': 0.0,
            'flow_local_abs_mean': 0.0,
            'flow_local_abs_max': 0.0,
            'local_flow_reduction_ratio': 0.0,
            'continuous_l1': 0.0,
            'continuous_l2': 0.0,
            'reject_reason': 'all_trials_failed',
            'accepted': 0
        }

    # 构建 metrics
    metrics = {
        'orig_pred': best_candidate['orig_pred'],
        'pred': best_candidate['pred'],
        'classifier_keep': 1 if best_candidate['classifier_keep'] else 0,
        'accepted': best_candidate['accepted'],
        'reject_reason': best_candidate['reject_reason'],
        'changed_pixel_ratio': best_candidate['changed_pixel_ratio'],
        'fg_diff': best_candidate['fg_diff'],
        'component_diff': best_candidate['component_diff'],
        'endpoint_diff': best_candidate['endpoint_diff'],
        'branchpoint_diff': best_candidate['branchpoint_diff'],
        'skeleton_length_diff': best_candidate['skeleton_length_diff'],
        'flow_global_abs_mean': best_candidate['flow_global_abs_mean'],
        'flow_global_abs_max': best_candidate['flow_global_abs_max'],
        'flow_local_abs_mean': best_candidate['flow_local_abs_mean'],
        'flow_local_abs_max': best_candidate['flow_local_abs_max'],
        'local_flow_reduction_ratio': best_candidate['local_flow_reduction_ratio'],
        'continuous_l1': best_candidate['continuous_l1'],
        'continuous_l2': best_candidate['continuous_l2'],
        'orig_fg': orig_metrics['foreground_ratio'],
        'aug_fg': best_candidate['aug'].mean(),
        'num_endpoints': best_candidate.get('aug_metrics', orig_metrics)['num_endpoints'],
        'num_branchpoints': best_candidate.get('aug_metrics', orig_metrics)['num_branchpoints'],
        'num_components': best_candidate.get('aug_metrics', orig_metrics)['num_components']
    }

    aug_binary = torch.from_numpy(best_candidate['aug']).unsqueeze(0).unsqueeze(0).float()

    return aug_binary, best_candidate['flow_global'], best_candidate['flow_local'], \
           best_candidate['skeleton'], best_candidate['distance_mask'], metrics