import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

def generate_gaussian_kernel(sigma, kernel_size=None):
    """
    生成高斯核
    
    Args:
        sigma: 高斯标准差
        kernel_size: 核大小，默认为 2*ceil(3*sigma) + 1
    
    Returns:
        二维高斯核
    """
    if kernel_size is None:
        kernel_size = 2 * int(np.ceil(3 * sigma)) + 1
    
    x = torch.arange(kernel_size) - kernel_size // 2
    g = torch.exp(-x**2 / (2 * sigma**2))
    g = g / g.sum()
    
    kernel = g.unsqueeze(0) * g.unsqueeze(1)
    return kernel

def generate_deformation_field(
    batch_size,
    height,
    width,
    max_displacement,
    smooth_sigma,
    device
):
    """
    生成二维位移场
    
    Args:
        batch_size: 批次大小
        height: 图像高度
        width: 图像宽度
        max_displacement: 最大位移（像素）
        smooth_sigma: 高斯平滑标准差
        device: 设备
    
    Returns:
        flow: 位移场，shape [B, 2, H, W]
              channel 0: dx（水平位移）
              channel 1: dy（垂直位移）
    """
    # 生成随机噪声作为初始位移场
    flow = torch.rand(batch_size, 2, height, width, device=device) * 2 - 1  # [-1, 1]
    
    # 创建高斯核
    kernel = generate_gaussian_kernel(smooth_sigma).to(device)
    kernel_size = kernel.size(0)
    
    # 对位移场进行高斯平滑
    # 需要对每个通道分别处理
    flow_smoothed = torch.zeros_like(flow)
    
    for i in range(2):
        # 添加 padding 以保持尺寸
        padding = kernel_size // 2
        flow_smoothed[:, i:i+1] = F.conv2d(
            flow[:, i:i+1],
            kernel.unsqueeze(0).unsqueeze(0),
            padding=padding
        )
    
    # 将位移缩放到最大位移
    flow_smoothed = flow_smoothed * max_displacement
    
    return flow_smoothed