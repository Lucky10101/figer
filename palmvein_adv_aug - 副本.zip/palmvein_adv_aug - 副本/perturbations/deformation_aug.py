import torch
import torch.nn.functional as F
from .deformation_field import generate_deformation_field
from .warp import warp_image

def generate_structure_preserving_aug(
    model,
    images,
    labels,
    max_displacement,
    smooth_sigma,
    binary_threshold,
    lambda_foreground,
    device
):
    """
    生成结构保持的形变扰动图像
    
    Args:
        model: 预训练分类器
        images: 原始二值图像，shape [B, 1, H, W]，范围 [0, 1]
        labels: 原始标签，shape [B]
        max_displacement: 最大位移（像素）
        smooth_sigma: 高斯平滑标准差
        binary_threshold: 二值化阈值
        lambda_foreground: 前景比例约束权重
        device: 设备
    
    Returns:
        x_binary: 形变后的二值图像
        flow: 使用的位移场
        metrics_dict: 指标字典
    """
    batch_size, _, height, width = images.size()
    
    # 生成位移场
    flow = generate_deformation_field(
        batch_size=batch_size,
        height=height,
        width=width,
        max_displacement=max_displacement,
        smooth_sigma=smooth_sigma,
        device=device
    )
    
    # warp 图像
    x_warped = warp_image(images, flow)
    
    # 二值化
    x_binary = (x_warped > binary_threshold).float()
    
    # 计算指标
    metrics_dict = compute_metrics(model, images, x_binary, labels, flow, device)
    
    return x_binary, flow, metrics_dict

def compute_metrics(model, original, deformed, labels, flow, device):
    """
    计算形变扰动的评估指标
    
    Args:
        model: 预训练分类器
        original: 原始图像，shape [B, 1, H, W]
        deformed: 形变后的图像，shape [B, 1, H, W]
        labels: 标签，shape [B]
        flow: 位移场，shape [B, 2, H, W]
        device: 设备
    
    Returns:
        metrics_dict: 指标字典
    """
    # 分类保持约束
    model.eval()
    with torch.no_grad():
        logits = model(deformed)
        preds = logits.argmax(dim=1)
        keep_rate = (preds == labels).float().mean().item()
    
    # 位移约束
    flow_magnitude = torch.sqrt(flow[:, 0]**2 + flow[:, 1]**2)
    avg_displacement = flow_magnitude.mean().item()
    
    # 前景比例约束
    orig_fg = original.mean().item()
    aug_fg = deformed.mean().item()
    fg_diff = abs(orig_fg - aug_fg)
    
    # 结构稳定性（变化像素比例）
    changed_pixel_ratio = torch.abs(deformed - original).mean().item()
    
    return {
        'keep_rate': keep_rate,
        'avg_displacement': avg_displacement,
        'changed_pixel_ratio': changed_pixel_ratio,
        'orig_fg': orig_fg,
        'aug_fg': aug_fg,
        'fg_diff': fg_diff
    }