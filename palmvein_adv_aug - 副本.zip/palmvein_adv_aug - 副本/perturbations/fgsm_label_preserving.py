import torch
import torch.nn as nn

def generate_fgsm_label_preserving(
    model,
    images,
    labels,
    epsilon,
    lambda_distance,
    binary_threshold,
    clamp_min=0.0,
    clamp_max=1.0,
    device=None
):
    """
    生成标签保持的 FGSM 扰动图像（连续模式）
    
    Args:
        model: 预训练好的分类模型，已设置为 eval 模式
        images: 原始图像，shape [B, 1, H, W]，范围 [0, 1]
        labels: 原始标签，shape [B]
        epsilon: FGSM 扰动步长
        lambda_distance: 距离损失权重
        binary_threshold: 二值化阈值
        clamp_min: 像素最小值
        clamp_max: 像素最大值
        device: 设备
    
    Returns:
        adv_continuous: 连续扰动图，范围 [0, 1]
        adv_binary: 二值化扰动图，范围 {0, 1}
        loss_dict: 损失字典
    """
    if device is None:
        device = images.device
    
    # 保存原始图像
    original_images = images.detach().clone()
    
    # 对输入图像开启梯度
    x_adv = images.clone().detach().requires_grad_(True)
    
    # 前向传播
    logits = model(x_adv)
    
    # 计算分类保持损失（希望预测不变）
    cls_loss_fn = nn.CrossEntropyLoss()
    cls_loss = cls_loss_fn(logits, labels)
    
    # 计算距离损失（希望图像变化）
    dist_loss = torch.norm(x_adv - original_images, p=2, dim=(1, 2, 3)).mean()
    
    # 总损失：cls_loss - lambda_distance * dist_loss
    total_loss = cls_loss - lambda_distance * dist_loss
    
    # 反向传播到输入图像
    model.zero_grad()
    total_loss.backward()
    
    # 获取梯度
    grad = x_adv.grad.data
    
    # 获取梯度符号
    grad_sign = grad.sign()
    
    # FGSM 更新：x_adv = x - epsilon * sign(grad)
    x_adv.data = x_adv.data - epsilon * grad_sign
    
    # Clamp 到 [0, 1]
    x_adv.data = torch.clamp(x_adv.data, clamp_min, clamp_max)
    
    # 生成连续扰动图
    adv_continuous = x_adv.detach()
    
    # 生成二值扰动图
    adv_binary = (adv_continuous > binary_threshold).float()
    
    # 计算连续扰动后的指标
    continuous_diff = adv_continuous - original_images
    continuous_l2 = torch.norm(continuous_diff, p=2, dim=(1, 2, 3)).mean().item()
    continuous_l1 = torch.norm(continuous_diff, p=1, dim=(1, 2, 3)).mean().item()
    continuous_changed_ratio = torch.abs(continuous_diff).mean().item()
    
    # 计算梯度统计
    grad_abs_mean = grad.abs().mean().item()
    grad_abs_max = grad.abs().max().item()
    
    # 计算损失值
    loss_dict = {
        'cls_loss': cls_loss.item(),
        'dist_loss': dist_loss.item(),
        'total_loss': total_loss.item(),
        'grad_abs_mean': grad_abs_mean,
        'grad_abs_max': grad_abs_max,
        'continuous_l2': continuous_l2,
        'continuous_l1': continuous_l1,
        'continuous_changed_ratio': continuous_changed_ratio,
        'num_flipped_pixels': 0,
        'actual_bitflip_ratio': 0.0
    }
    
    return adv_continuous, adv_binary, loss_dict

def generate_gradient_bitflip_label_preserving(
    model,
    images,
    labels,
    bitflip_ratio,
    binary_threshold=0.5,
    flip_foreground=True,
    flip_background=True,
    device=None
):
    """
    根据梯度重要性翻转二值图像像素（标签保持）
    
    Args:
        model: 预训练好的分类模型，已设置为 eval 模式
        images: 原始二值图像，shape [B, 1, H, W]，范围 [0, 1]
        labels: 原始标签，shape [B]
        bitflip_ratio: 每张图最多翻转的像素比例
        binary_threshold: 二值化阈值
        flip_foreground: 是否允许翻转前景像素（1→0）
        flip_background: 是否允许翻转背景像素（0→1）
        device: 设备
    
    Returns:
        adv_binary: 扰动后的二值图，范围 {0, 1}
        loss_dict: 损失字典
    """
    if device is None:
        device = images.device
    
    # 保存原始图像
    original_images = images.detach().clone()
    
    # 对输入图像开启梯度
    x_adv = images.clone().detach().requires_grad_(True)
    
    # 前向传播
    logits = model(x_adv)
    
    # 计算分类保持损失
    cls_loss_fn = nn.CrossEntropyLoss()
    cls_loss = cls_loss_fn(logits, labels)
    
    # 反向传播到输入图像
    model.zero_grad()
    cls_loss.backward()
    
    # 获取梯度
    grad = x_adv.grad.data
    
    # 计算梯度统计
    grad_abs_mean = grad.abs().mean().item()
    grad_abs_max = grad.abs().max().item()
    
    # 初始化扰动图像
    adv_binary = original_images.clone()
    
    batch_size, _, height, width = images.shape
    total_pixels = height * width
    k = int(bitflip_ratio * total_pixels)
    
    # 对每张图进行处理
    for i in range(batch_size):
        img = original_images[i, 0]  # [H, W]
        grad_i = grad[i, 0]  # [H, W]
        
        # 确定翻转候选像素
        candidates = []
        
        if flip_foreground:
            # 前景像素（x=1），如果梯度方向提示减小该像素有利于保持类别
            # update_direction = -sign(grad) < 0 表示应该减小像素值
            foreground_mask = (img > binary_threshold)
            foreground_negative_grad = (grad_i < 0)
            fg_candidates = foreground_mask & foreground_negative_grad
            
            # 获取前景候选像素的坐标和梯度绝对值
            fg_coords = torch.nonzero(fg_candidates)
            for coord in fg_coords:
                y, x = coord
                candidates.append((-grad_i[y, x].abs().item(), y.item(), x.item(), 'fg'))
        
        if flip_background:
            # 背景像素（x=0），如果梯度方向提示增大该像素有利于保持类别
            # update_direction = -sign(grad) > 0 表示应该增大像素值
            background_mask = (img <= binary_threshold)
            background_positive_grad = (grad_i > 0)
            bg_candidates = background_mask & background_positive_grad
            
            # 获取背景候选像素的坐标和梯度绝对值
            bg_coords = torch.nonzero(bg_candidates)
            for coord in bg_coords:
                y, x = coord
                candidates.append((-grad_i[y, x].abs().item(), y.item(), x.item(), 'bg'))
        
        # 按梯度绝对值从大到小排序，选择 top-k
        candidates.sort()
        selected = candidates[:k]
        
        # 执行翻转
        for _, y, x, _ in selected:
            current_val = adv_binary[i, 0, y, x].item()
            adv_binary[i, 0, y, x] = 1 - current_val  # 翻转
    
    # 计算翻转的像素数量
    diff = torch.abs(adv_binary - original_images)
    num_flipped_pixels = diff.sum().item()
    actual_bitflip_ratio = num_flipped_pixels / (batch_size * total_pixels)
    
    # 计算损失值
    loss_dict = {
        'cls_loss': cls_loss.item(),
        'grad_abs_mean': grad_abs_mean,
        'grad_abs_max': grad_abs_max,
        'num_flipped_pixels': num_flipped_pixels,
        'actual_bitflip_ratio': actual_bitflip_ratio,
        'continuous_l2': 0.0,
        'continuous_l1': 0.0,
        'continuous_changed_ratio': 0.0
    }
    
    return adv_binary, loss_dict