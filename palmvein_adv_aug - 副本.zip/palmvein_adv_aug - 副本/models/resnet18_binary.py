import torch
import torch.nn as nn
from torchvision.models import resnet18

class ResNet18Binary(nn.Module):
    def __init__(self, num_classes=100, dropout=0.5):
        super(ResNet18Binary, self).__init__()
        
        # 加载预定义的 ResNet18 模型，不使用预训练权重
        self.model = resnet18(pretrained=False)
        
        # 修改第一层卷积，将输入通道从 3 改为 1
        self.model.conv1 = nn.Conv2d(
            1, 64, kernel_size=7, stride=2, padding=3, bias=False
        )
        
        # 添加 Dropout
        if dropout > 0:
            self.model.fc = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(self.model.fc.in_features, num_classes)
            )
        else:
            # 修改全连接层，输出类别数为 num_classes
            self.model.fc = nn.Linear(self.model.fc.in_features, num_classes)
    
    def forward(self, x):
        return self.model(x)

def create_resnet18_binary(num_classes=100, dropout=0.5):
    """创建 ResNet18 二值分类模型
    
    Args:
        num_classes: 类别数量
        dropout: Dropout 概率
    
    Returns:
        ResNet18Binary 模型
    """
    return ResNet18Binary(num_classes=num_classes, dropout=dropout)