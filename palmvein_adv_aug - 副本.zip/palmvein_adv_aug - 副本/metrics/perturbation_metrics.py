import torch
import torch.nn as nn

def compute_continuous_metrics(model, original, adv_continuous, labels):
    """
    计算连续扰动图的评估指标
    
    Args:
        model: 预训练好的分类模型，已设置为 eval 模式
        original: 原始图像，shape [B, 1, H, W]，范围 [0, 1]
        adv_continuous: 连续扰动图，shape [B, 1, H, W]，范围 [0, 1]
        labels: 原始标签，shape [B]
    
    Returns:
        metrics dict
    """
    device = original.device
    
    # 将数据移到设备上
    original = original.to(device)
    adv_continuous = adv_continuous.to(device)
    labels = labels.to(device)
    
    # 确保模型在正确的设备上
    model = model.to(device)
    
    # 前向传播获取预测
    with torch.no_grad():
        original_logits = model(original)
        adv_logits = model(adv_continuous)
    
    # 计算原始准确率
    original_preds = original_logits.argmax(dim=1)
    original_acc = (original_preds == labels).float().mean().item()
    
    # 计算扰动后准确率
    adv_preds = adv_logits.argmax(dim=1)
    adv_continuous_acc = (adv_preds == labels).float().mean().item()
    
    # 计算保持率
    keep_mask = (original_preds == labels) & (adv_preds == labels)
    keep_rate_continuous = keep_mask.float().mean().item()
    
    # 计算距离指标
    diff = adv_continuous - original
    continuous_l2 = torch.norm(diff, p=2, dim=(1, 2, 3)).mean().item()
    continuous_l1 = torch.norm(diff, p=1, dim=(1, 2, 3)).mean().item()
    continuous_abs_diff_mean = torch.abs(diff).mean().item()
    
    # 计算前景比例
    original_foreground_ratio = original.mean().item()
    continuous_foreground_ratio = adv_continuous.mean().item()
    
    return {
        'original_acc': original_acc,
        'adv_continuous_acc': adv_continuous_acc,
        'keep_rate_continuous': keep_rate_continuous,
        'continuous_l2': continuous_l2,
        'continuous_l1': continuous_l1,
        'continuous_abs_diff_mean': continuous_abs_diff_mean,
        'original_foreground_ratio': original_foreground_ratio,
        'continuous_foreground_ratio': continuous_foreground_ratio
    }

def compute_binary_metrics(model, original, adv_binary, labels):
    """
    计算二值扰动图的评估指标
    
    Args:
        model: 预训练好的分类模型，已设置为 eval 模式
        original: 原始图像，shape [B, 1, H, W]，范围 [0, 1]
        adv_binary: 二值扰动图，shape [B, 1, H, W]，值为 0 或 1
        labels: 原始标签，shape [B]
    
    Returns:
        metrics dict
    """
    device = original.device
    
    # 将数据移到设备上
    original = original.to(device)
    adv_binary = adv_binary.to(device)
    labels = labels.to(device)
    
    # 确保模型在正确的设备上
    model = model.to(device)
    
    # 前向传播获取预测
    with torch.no_grad():
        original_logits = model(original)
        adv_logits = model(adv_binary)
    
    # 计算原始准确率
    original_preds = original_logits.argmax(dim=1)
    original_acc = (original_preds == labels).float().mean().item()
    
    # 计算扰动后准确率
    adv_preds = adv_logits.argmax(dim=1)
    adv_binary_acc = (adv_preds == labels).float().mean().item()
    
    # 计算保持率
    keep_mask = (original_preds == labels) & (adv_preds == labels)
    keep_rate_binary = keep_mask.float().mean().item()
    
    # 计算距离指标
    diff = adv_binary - original
    binary_l2 = torch.norm(diff, p=2, dim=(1, 2, 3)).mean().item()
    binary_l1 = torch.norm(diff, p=1, dim=(1, 2, 3)).mean().item()
    changed_pixel_ratio = torch.abs(diff).mean().item()
    
    # 计算前景比例
    original_foreground_ratio = original.mean().item()
    adv_foreground_ratio = adv_binary.mean().item()
    foreground_ratio_diff = adv_foreground_ratio - original_foreground_ratio
    
    return {
        'original_acc': original_acc,
        'adv_binary_acc': adv_binary_acc,
        'keep_rate_binary': keep_rate_binary,
        'binary_l2': binary_l2,
        'binary_l1': binary_l1,
        'changed_pixel_ratio': changed_pixel_ratio,
        'original_foreground_ratio': original_foreground_ratio,
        'adv_foreground_ratio': adv_foreground_ratio,
        'foreground_ratio_diff': foreground_ratio_diff
    }

def compute_perturbation_metrics(model, original, adv_binary, labels):
    """
    计算扰动评估指标（兼容旧接口）
    
    Args:
        model: 预训练好的分类模型，已设置为 eval 模式
        original: 原始图像，shape [B, 1, H, W]，范围 [0, 1]
        adv_binary: 扰动后的二值图，shape [B, 1, H, W]，值为 0 或 1
        labels: 原始标签，shape [B]
    
    Returns:
        metrics dict
    """
    return compute_binary_metrics(model, original, adv_binary, labels)