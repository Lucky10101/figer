# 手指/掌静脉二值图像身份分类 Baseline 项目

## 项目结构

```
palmvein_adv_aug/
├── datasets/
│   └── finger_vein_dataset.py  # 分类模型的自定义数据集类
├── models/
│   └── resnet18_binary.py      # 修改后的 ResNet18 模型
├── perturbations/
│   ├── __init__.py
│   └── fgsm_label_preserving.py  # FGSM 标签保持扰动生成
├── losses/
│   ├── __init__.py
│   └── constraint_losses.py    # 约束损失函数
├── metrics/
│   ├── __init__.py
│   └── perturbation_metrics.py # 扰动评估指标
├── scripts/
│   ├── train_baseline.py       # 分类模型训练脚本
│   ├── evaluate_baseline.py     # 分类模型评估脚本
│   ├── debug_dataset.py         # 数据集调试脚本
│   ├── generate_fgsm_aug.py     # FGSM 扰动生成脚本
│   └── evaluate_fgsm_aug.py     # FGSM 扰动评估脚本
├── configs/
│   ├── baseline.yaml           # 分类模型配置文件
│   └── fgsm_aug.yaml           # FGSM 扰动配置文件
├── checkpoints/                # 模型保存目录
├── outputs/                    # 输出文件目录
├── requirements.txt            # 依赖包
└── README.md                   # 项目说明
```

## 数据集结构

```
finger/
└── train/
    └── train_mask/
        ├── 1.bmp
        ├── 2.bmp
        └── ...
        └── 600.bmp
```

## 标签规则

```
label = (image_id - 1) // 6
```

例如：
- 1.bmp 到 6.bmp 属于第 0 类
- 7.bmp 到 12.bmp 属于第 1 类
- ...
- 595.bmp 到 600.bmp 属于第 99 类

## 数据划分方式

### 每类 6 张：
- 4 张作为训练集
- 1 张作为验证集
- 1 张作为测试集

### 最终：
- 训练集：400 张
- 验证集：100 张
- 测试集：100 张

### 特点：
- 三个集合都包含 100 个身份
- 数据划分使用固定随机种子，保证可复现性

## 当前阶段不包含：
- 分割模型
- test 原图
- test_mask 生成
- 对抗扰动
- 大模型扰动

## 环境配置

安装依赖包：

```bash
pip install -r requirements.txt
```

## 运行步骤

### Step 1：调试数据集
```bash
python scripts/debug_dataset.py --config configs/baseline.yaml
```

### Step 2：训练模型
```bash
python scripts/train_baseline.py --config configs/baseline.yaml
```

### Step 3：评估模型
```bash
python scripts/evaluate_baseline.py --config configs/baseline.yaml --checkpoint checkpoints/resnet18_binary_best.pth --split test
```

## 模型说明

- 使用修改后的 ResNet18 模型，将第一层卷积改为单通道输入，全连接层输出 100 类
- 不使用预训练权重
- 支持 Dropout 防止过拟合
- 支持 label smoothing
- 支持训练数据增强（随机旋转、仿射变换等）
- 支持早停机制，防止过拟合
- 支持 GPU/CPU 自动选择

## 训练特点

- 只使用 finger/train/train_mask 的 600 张二值 mask 图像
- 通过 build_class_balanced_splits 函数划分 train/val/test
- 训练时只用 train split
- 验证时用 val split
- 评估时可选择评估 train/val/test 任意一个 split
- 保存最佳模型和最后一个模型
- 保存训练日志和训练曲线

## 评估特点

- 输出总体准确率、平均损失和每个类别的准确率
- 保存混淆矩阵
- 保存预测结果，包括文件名、真实标签、预测标签、是否正确和置信度

---

## 第二阶段：FGSM 标签保持扰动生成

### 阶段目标
- 固定已训练好的 ResNet18 分类器参数
- 只优化输入图像，生成 FGSM 扰动
- 扰动目标：类别保持 + 图像有变化
- 验证导师说的 loss 反传修改图像流程
- 暂不追求最终增强效果

### 新增模块说明

**扰动模块 (perturbations/)**
- `fgsm_label_preserving.py`: 实现 FGSM 标签保持扰动生成
- 损失函数: `total_loss = cls_loss - lambda_distance * dist_loss`
- 目标：最小化分类损失（保持分类）同时最大化距离损失（产生变化）

**约束模块 (losses/)**
- `constraint_losses.py`: 实现约束损失函数
- 包含 L2 距离、前景比例、二值差异比例、分类保持率

**评估模块 (metrics/)**
- `perturbation_metrics.py`: 实现扰动评估指标
- 计算保持准确率、距离度量、像素变化比例等

### 运行步骤

#### Step 4：生成 FGSM 扰动图像
```bash
python scripts/generate_fgsm_aug.py --config configs/fgsm_aug.yaml --split train
```

#### Step 5：评估 FGSM 扰动图像
```bash
python scripts/evaluate_fgsm_aug.py --config configs/fgsm_aug.yaml --split train
```

### 输出说明

**生成的文件结构：**
```
outputs/fgsm_aug/
├── {split}/
│   ├── continuous/  # 连续扰动图
│   └── binary/      # 二值化扰动图
├── vis/
│   └── {split}_comparison.png  # 可视化对比图
├── {split}_metrics.csv          # 每张图的详细指标
└── evaluate_{split}.csv         # 评估结果汇总
```

### 当前阶段不包含
- PGD（投影梯度下降）
- 形变场
- 大模型扰动
- 复杂的增强策略

### 两种扰动模式

#### 1. continuous_fgsm 模式
- 生成连续扰动图（像素值在 [0,1] 范围内连续变化）
- 二值化后可能没有变化（因为小扰动可能不会跨越阈值）
- 适用于观察连续梯度变化

#### 2. binary_bitflip 模式（推荐）
- 根据梯度重要性直接翻转二值像素
- 确保生成的扰动图有实际变化
- 翻转规则：
  - 前景像素（1）：如果梯度为负，翻转到 0
  - 背景像素（0）：如果梯度为正，翻转到 1
- 按梯度绝对值从大到小选择像素翻转

### 配置参数说明 (fgsm_aug.yaml)

| 参数 | 说明 | 默认值 |
|------|------|--------|
| mode | 扰动模式：continuous_fgsm 或 binary_bitflip | binary_bitflip |
| epsilon | FGSM 扰动步长（continuous_fgsm 模式） | 0.03 |
| lambda_distance | 距离损失权重 | 0.0 |
| bitflip_ratio | 每张图最多翻转的像素比例（binary_bitflip 模式） | 0.01 |
| max_bitflip_ratio | 最大翻转比例限制 | 0.05 |
| flip_foreground | 是否允许翻转前景像素（1→0） | true |
| flip_background | 是否允许翻转背景像素（0→1） | true |
| binary_threshold | 二值化阈值 | 0.5 |
| batch_size | 批次大小 | 16 |

### bitflip_ratio 推荐值

建议从较小的值开始尝试：

| bitflip_ratio | 效果 |
|---------------|------|
| 0.001 (0.1%) | 非常轻微的扰动 |
| 0.005 (0.5%) | 轻微扰动 |
| 0.01 (1%) | 中等扰动 |
| 0.02 (2%) | 较明显扰动 |

> **推荐**：先从 `bitflip_ratio: 0.001` 开始测试，观察效果后再调整。

### 预期结果

对于 binary_bitflip 模式，期望：

```
changed_pixel_ratio ≈ bitflip_ratio
keep_rate_binary 尽量接近 1.0
```

### 重要提示
- 如果 keep_acc 很低（< 0.9），需要降低 bitflip_ratio（或 epsilon）值
- 如果 changed_pixel_ratio 接近 0，需要增大 bitflip_ratio 值
- 扰动生成是独立脚本，不影响原始训练代码
- continuous_fgsm 模式下二值图可能没有变化，这是正常现象

---

## 第三阶段：增强训练闭环

### 阶段目标
- 将扰动生成的增强数据加入训练集
- 重新训练分类器
- 对比 baseline 和 augmented 的性能
- 判断扰动是否提升模型泛化能力

### 新增脚本说明

**build_augmented_dataset.py**
- 将原始 train split 与扰动图合并
- 支持 aug_ratio 参数控制增强样本比例
- 保存 train_list.csv, val_list.csv, test_list.csv

**train_with_aug.py**
- 使用增强数据训练分类器
- 分别统计原图和扰动图的训练准确率
- 保存增强训练模型到 checkpoints/resnet18_aug_best.pth

**compare_models.py**
- 对比 baseline 和 augmented 模型
- 输出 Train Acc, Val Acc, Test Acc, Train-Val Gap
- 自动分析增强效果

### 运行步骤

#### Step 1：生成扰动图
```bash
python scripts/generate_fgsm_aug.py --config configs/fgsm_aug.yaml --split train
```

#### Step 2：构建增强数据集
```bash
python scripts/build_augmented_dataset.py --config configs/baseline.yaml --aug_config configs/fgsm_aug.yaml --aug_ratio 1.0
```

#### Step 3：训练增强模型
```bash
python scripts/train_with_aug.py --config configs/baseline.yaml --aug_config configs/aug_train.yaml
```

#### Step 4：对比模型
```bash
python scripts/compare_models.py \
  --baseline_ckpt checkpoints/resnet18_binary_best.pth \
  --aug_ckpt checkpoints/resnet18_aug_best.pth
```

### aug_ratio 参数说明

| aug_ratio | 效果 |
|-----------|------|
| 0.5 | 原图400 + 扰动200 = 600训练样本 |
| 1.0 | 原图400 + 扰动400 = 800训练样本 |
| 2.0 | 原图400 + 扰动800 = 1200训练样本（扰动样本重复使用） |

### 增强成功的标志

| 指标 | 预期变化 |
|------|----------|
| Val Acc | 上升（例如 0.88 → 0.90+） |
| Train-Val Gap | 变小 |
| Test Acc | 提升 |
| 训练稳定性 | Loss 不震荡 |

### 可能的失败情况

| 现象 | 原因 | 解决方法 |
|------|------|----------|
| Train Acc 更高但 Val 不变 | 扰动无效 | 调整扰动参数 |
| Val 下降 | 扰动破坏结构 | 减小 bitflip_ratio |
| Gap 变大 | 扰动过强 | 降低扰动强度 |

### 输出文件

```
outputs/
├── aug_dataset/
│   ├── train_list.csv
│   ├── val_list.csv
│   └── test_list.csv
├── aug_training_log.csv
├── aug_training_curves.png
└── model_comparison.csv
```

### 当前阶段不包含

- 可学习扰动网络 G
- PGD 攻击
- 形变场
- 拓扑损失

### 实验设计建议

建议尝试不同的 aug_ratio：
```bash
# 实验 1：轻微增强
python scripts/build_augmented_dataset.py --aug_ratio 0.5
python scripts/train_with_aug.py

# 实验 2：中等增强
python scripts/build_augmented_dataset.py --aug_ratio 1.0
python scripts/train_with_aug.py

# 实验 3：强增强
python scripts/build_augmented_dataset.py --aug_ratio 2.0
python scripts/train_with_aug.py
```

---

## 第四阶段：结构保持的空间形变扰动

### 阶段目标
- 实现 deformation-based augmentation
- 在空间上移动血管结构，而不是修改像素值
- 保持类别不变，控制形变幅度
- 不破坏血管拓扑结构

### 新增模块说明

**perturbations/deformation_field.py**
- `generate_deformation_field()`: 生成二维位移场
- 使用高斯平滑保证位移场连续性

**perturbations/warp.py**
- `warp_image()`: 使用位移场 warp 图像
- 使用 `torch.nn.functional.grid_sample`

**perturbations/deformation_aug.py**
- `generate_structure_preserving_aug()`: 生成结构保持的形变扰动

**scripts/generate_deform_aug.py**
- 生成形变扰动图像
- 保存二值扰动图和位移场可视化

### 扰动原理

```
x_aug = warp(x, flow)
```

1. **生成位移场**: 使用随机噪声 + 高斯平滑
2. **图像 Warp**: 使用 grid_sample 进行空间变换
3. **二值化**: 保持输出为二值图像

### 关键约束

| 约束 | 计算方式 |
|------|----------|
| 分类保持 | keep_rate = mean(pred == labels) |
| 位移幅度 | avg_displacement = mean(sqrt(dx² + dy²)) |
| 前景比例 | fg_diff = abs(orig_fg - aug_fg) |
| 结构稳定性 | changed_pixel_ratio = mean(\|x_binary - images\|) |

### 运行步骤

#### Step 1：生成形变扰动图
```bash
python scripts/generate_deform_aug.py --config configs/deform_aug.yaml --split train
```

#### Step 2：构建增强数据集（使用形变扰动）
```bash
python scripts/build_augmented_dataset.py --config configs/baseline.yaml --aug_type deform --aug_ratio 1.0
```

#### Step 3：训练增强模型
```bash
python scripts/train_with_aug.py --config configs/baseline.yaml --aug_config configs/aug_train.yaml
```

#### Step 4：对比模型
```bash
python scripts/compare_models.py \
  --baseline_ckpt checkpoints/resnet18_binary_best.pth \
  --aug_ckpt checkpoints/resnet18_aug_best.pth
```

### 配置参数说明 (deform_aug.yaml)

| 参数 | 说明 | 默认值 |
|------|------|--------|
| max_displacement | 最大位移（像素） | 3.0 |
| smooth_sigma | 高斯平滑标准差 | 5.0 |
| binary_threshold | 二值化阈值 | 0.5 |
| batch_size | 批次大小 | 16 |

### 参数扫描建议

必须测试不同的参数组合：

**max_displacement:**
```bash
1.0 / 2.0 / 3.0 / 5.0
```

**smooth_sigma:**
```bash
3 / 5 / 7
```

### 预期观察

| 现象 | 原因 |
|------|------|
| displacement 太小 | 图像几乎无变化 |
| displacement 太大 | 血管结构被破坏 |
| smooth_sigma 太小 | 位移场不连续，产生伪影 |
| smooth_sigma 太大 | 位移过于平滑，变化不明显 |

### 输出文件

```
outputs/deform_aug/
├── {split}/
│   ├── binary/     # 形变后的二值图像
│   └── flow/       # 位移场可视化
├── vis/
│   └── {split}_comparison.png
└── {split}_metrics.csv
```

### 当前阶段不包含

- 可学习位移场网络
- PGD 攻击
- 拓扑损失（后续阶段）
- 复杂的形变约束

### 实验对比设计

对比三种增强策略：

| 模型 | 增强方式 | 预期效果 |
|------|----------|----------|
| Baseline | 无增强 | 基准性能 |
| FGSM-Aug | 像素级扰动 | 轻微增强 |
| Deform-Aug | 结构形变扰动 | 保持结构的增强 |

判断标准：
- Val Acc 是否提升
- Train-Val Gap 是否减小
- 测试集性能是否增强

---

## 第五阶段：MHOA-lite 结构保持形变增强

### 阶段目标
- 实现基于静脉骨架关键点的结构保持空间形变增强
- 替代随机 dense flow，解决血管断裂、像素块偏移问题
- 通过拓扑约束筛选合格的增强样本

### 理论原理

```
输入：二值静脉图 x ∈ {0,1}^{H×W}
1. 提取骨架关键点 K={p_i}
2. 对关键点生成小位移 U={u_i}
3. 用 RBF 插值得到平滑形变场 flow=Φ(K,U)
4. 生成增强图：x_aug = warp(x, flow)
```

### 新增模块说明

**perturbations/keypoint_utils.py**
- `extract_skeleton_keypoints()`: 提取骨架端点、分叉点、均匀采样普通点

**perturbations/rbf_warp.py**
- `generate_keypoint_displacements()`: 生成关键点位移
- `rbf_interpolate_flow()`: RBF 插值得到 dense flow

**perturbations/topology_filter.py**
- `compute_topology_metrics()`: 计算拓扑指标
- `check_constraints()`: 检查拓扑约束
- `postprocess_binary()`: 后处理修复小断裂

**perturbations/mhoa_lite.py**
- `generate_mhoa_lite_aug()`: MHOA-lite 主函数

**scripts/generate_mhoa_aug.py**
- 生成 MHOA 增强图，支持拓扑筛选

**scripts/evaluate_mhoa_aug.py**
- 评估 MHOA 增强质量

### 拓扑约束

| 约束 | 说明 |
|------|------|
| classifier_keep | 分类器保持正确 |
| fg_diff | 前景比例变化 <= max_fg_diff |
| component_diff | 连通域数量变化 <= max_component_diff |
| endpoint_diff | 端点数量变化 <= max_endpoint_diff |
| branchpoint_diff | 分叉点变化 <= max_branchpoint_diff |
| largest_component_ratio | 最大连通域比例 >= min_largest_component_ratio |
| changed_ratio | 变化像素比例在 [min, max] 之间 |

### 调试步骤

在运行增强生成之前，建议先运行调试脚本来验证 warp 功能是否正常：

```bash
python scripts/debug_mhoa_warp.py --config configs/mhoa_aug.yaml
```

该脚本会测试三种 flow：
- 固定水平平移 flow（dx=5）
- 固定垂直平移 flow（dy=5）
- MHOA RBF 生成的 flow

判断标准：
- 固定 dx=5 后 changed_pixel_ratio 必须 > 0
- 如果固定平移都为 0，说明 warp_image 有 bug
- 如果固定平移有效但 MHOA 无效，说明 RBF flow 太弱或被抵消

输出文件：
- `outputs/mhoa_debug/warp_debug.png` - 可视化对比
- `outputs/mhoa_debug/warp_debug_metrics.csv` - 详细指标

### 运行步骤

#### Step 1：先运行调试脚本（推荐）
```bash
python scripts/debug_mhoa_warp.py --config configs/mhoa_aug.yaml
```

确认固定平移可以产生 changed_pixel_ratio > 0 后，再运行：

#### Step 2：生成 MHOA-lite 增强图
```bash
python scripts/generate_mhoa_aug.py --config configs/mhoa_aug.yaml --split train
```

#### Step 2：构建增强数据集（使用 MHOA 增强）
```bash
python scripts/build_augmented_dataset.py --config configs/baseline.yaml --aug_type mhoa --aug_ratio 1.0
```

#### Step 3：训练增强模型
```bash
python scripts/train_with_aug.py --config configs/baseline.yaml --aug_config configs/aug_train.yaml
```

#### Step 4：评估 MHOA 增强质量
```bash
python scripts/evaluate_mhoa_aug.py --config configs/mhoa_aug.yaml --split train
```

#### Step 5：对比模型
```bash
python scripts/compare_models.py \
  --baseline_ckpt checkpoints/resnet18_binary_best.pth \
  --aug_ckpt checkpoints/resnet18_aug_best.pth
```

### 配置参数说明 (mhoa_aug.yaml)

| 参数 | 说明 | 默认值 |
|------|------|--------|
| max_keypoints | 最大关键点数量 | 80 |
| max_disp | 最大位移（像素） | 3.0 |
| rbf_sigma | RBF 高斯核标准差 | 18.0 |
| num_trials | 最大尝试次数 | 10 |
| max_fg_diff | 前景比例变化上限 | 0.03 |
| max_component_diff | 连通域数量变化上限 | 3 |
| max_endpoint_diff | 端点数量变化上限 | 10 |
| max_branchpoint_diff | 分叉点数量变化上限 | 10 |

### 参数扫描建议

**max_disp:** 2.0 / 3.0 / 5.0

**rbf_sigma:** 15.0 / 18.0 / 25.0

### 输出文件

```
outputs/mhoa_aug/
├── {split}/
│   ├── binary/     # MHOA 增强的二值图像
│   └── flow/       # 位移场可视化
├── vis/
│   └── {split}_comparison.png
├── {split}_metrics.csv
└── evaluation_summary.csv
```

### 当前阶段不包含

- 可学习的位移场网络
- 复杂的拓扑损失
- 多步迭代优化

### 实验对比设计

对比四种增强策略：

| 模型 | 增强方式 | 预期效果 |
|------|----------|----------|
| Baseline | 无增强 | 基准性能 |
| FGSM-Aug | 像素级扰动 | 轻微增强 |
| Deform-Aug | 随机形变扰动 | 结构变化 |
| MHOA-lite | 骨架关键点形变 | 结构保持增强 |

判断标准：
- Val Acc 是否提升
- Train-Val Gap 是否减小
- 测试集性能是否增强
- 拓扑约束通过率是否合理（>50%）

---

## 第五阶段：中心线驱动的局部结构保持形变

### 阶段目标
- 改进 MHOA-lite，使用 skeleton distance mask 使形变集中在血管中心线附近
- 保留血管细节，避免背景大范围移动
- 保持血管拓扑结构

### 核心公式
```
flow_local = flow_global * exp(-dist_to_skeleton^2 / (2 * sigma_vessel^2))
```

### 新增模块说明

**perturbations/centerline_local_deform.py**
- `compute_skeleton_distance_mask()`: 计算骨架距离衰减 mask
- `apply_centerline_decay_to_flow()`: 将中心线衰减应用于 flow
- `generate_centerline_local_deform_aug()`: 中心线局部形变增强主函数

**scripts/generate_centerline_deform_aug.py**
- 生成中心线局部形变增强图

**scripts/evaluate_centerline_deform_aug.py**
- 评估中心线局部形变增强质量

### 配置参数 (configs/centerline_deform.yaml)

| 参数 | 说明 | 默认值 |
|------|------|--------|
| sigma_vessel | 骨架邻域影响范围 | 6.0 |
| max_disp | 最大位移 | 3.0 |
| target_avg_disp | 目标平均位移 | 1.2 |
| rbf_sigma | RBF 核标准差 | 8.0 |
| binary_threshold | 二值化阈值 | 0.45 |

### 运行步骤

```bash
# Step 1: 生成中心线局部形变增强图
python scripts/generate_centerline_deform_aug.py --config configs/centerline_deform.yaml --split train

# Step 2: 评估增强质量
python scripts/evaluate_centerline_deform_aug.py --config configs/centerline_deform.yaml --split train

# Step 3: 构建增强训练集
python scripts/build_augmented_dataset.py --config configs/baseline.yaml --aug_type centerline_deform --aug_ratio 1.0

# Step 4: 训练增强模型
python scripts/train_with_aug.py --config configs/baseline.yaml --aug_config configs/aug_train.yaml

# Step 5: 对比模型
python scripts/compare_models.py --baseline_ckpt checkpoints/resnet18_binary_best.pth --aug_ckpt checkpoints/resnet18_aug_best.pth
```

### 参数建议

**sigma_vessel:** 3 / 5 / 7 / 9

**max_disp:** 1.5 / 2.0 / 3.0

**target_avg_disp:** 0.8 / 1.0 / 1.2

### 判断标准
- changed_pixel_ratio 不能为 0
- fg_diff 不宜超过 0.05
- keep_correct 尽量接近 1
- endpoint_diff / branchpoint_diff 不应明显大于 MHOA-lite
- 增强训练后 val/test acc 应高于 baseline

### 输出文件
```
outputs/centerline_deform/
├── {split}/
│   ├── binary/      # 增强的二值图像
│   └── flow/        # 局部 flow 可视化
├── vis/             # 可视化对比
├── {split}_metrics.csv
└── evaluation_summary.csv
```

### 当前阶段不包含

- 可学习的位移场网络
- 复杂的拓扑损失
- 多步迭代优化

### 实验对比设计

对比五种增强策略：

| 模型 | 增强方式 | 预期效果 |
|------|----------|----------|
| Baseline | 无增强 | 基准性能 |
| FGSM-Aug | 像素级扰动 | 轻微增强 |
| Deform-Aug | 随机形变扰动 | 结构变化 |
| MHOA-lite | 骨架关键点形变 | 结构保持增强 |
| Centerline-Deform | 中心线局部形变 | 细节保持增强 |

判断标准：
- Val Acc 是否提升
- Train-Val Gap 是否减小
- 测试集性能是否增强