from pathlib import Path
from PIL import Image
import torch
from torch.utils.data import Dataset
import numpy as np
import random
import csv

def build_class_balanced_splits(
    image_dir,
    images_per_class=6,
    num_classes=100,
    train_per_class=4,
    val_per_class=1,
    test_per_class=1,
    seed=42
):
    """
    构建类别平衡的数据分割
    
    Args:
        image_dir: 图像目录路径
        images_per_class: 每类图像数量
        num_classes: 类别数量
        train_per_class: 每类训练图像数量
        val_per_class: 每类验证图像数量
        test_per_class: 每类测试图像数量
        seed: 随机种子
    
    Returns:
        train_samples, val_samples, test_samples: 三个分割的样本列表
    """
    # 设置随机种子
    random.seed(seed)
    np.random.seed(seed)
    
    image_dir = Path(image_dir)
    
    # 检查目录是否存在
    if not image_dir.exists():
        raise FileNotFoundError(f"Directory {image_dir} does not exist")
    
    # 收集所有 .bmp 文件
    image_files = list(image_dir.glob("*.bmp"))
    
    # 按文件名数字排序
    def sort_key(file_path):
        try:
            return int(file_path.stem)
        except ValueError:
            return 0
    
    image_files.sort(key=sort_key)
    
    # 检查总数
    if len(image_files) != num_classes * images_per_class:
        raise ValueError(f"Expected {num_classes * images_per_class} images, but found {len(image_files)}")
    
    # 按类别分组
    class_files = {i: [] for i in range(num_classes)}
    for image_file in image_files:
        image_id = int(image_file.stem)
        label = (image_id - 1) // images_per_class
        if label not in class_files:
            raise ValueError(f"Invalid label {label}, expected 0-{num_classes-1}")
        class_files[label].append(image_file)
    
    # 检查每类数量
    for label, files in class_files.items():
        if len(files) != images_per_class:
            raise ValueError(f"Class {label} has {len(files)} images, expected {images_per_class}")
    
    # 检查类别数
    if len(class_files) != num_classes:
        raise ValueError(f"Expected {num_classes} classes, but found {len(class_files)}")
    
    # 划分数据
    train_samples = []
    val_samples = []
    test_samples = []
    
    for label, files in class_files.items():
        # 打乱顺序
        random.shuffle(files)
        
        # 划分
        train_files = files[:train_per_class]
        val_files = files[train_per_class:train_per_class+val_per_class]
        test_files = files[train_per_class+val_per_class:]
        
        # 添加到样本列表
        for file in train_files:
            train_samples.append({
                'image_path': file,
                'label': label,
                'filename': file.name
            })
        
        for file in val_files:
            val_samples.append({
                'image_path': file,
                'label': label,
                'filename': file.name
            })
        
        for file in test_files:
            test_samples.append({
                'image_path': file,
                'label': label,
                'filename': file.name
            })
    
    return train_samples, val_samples, test_samples

class FingerVeinDataset(Dataset):
    def __init__(self, image_dir, samples, image_size=224, binary_threshold=0.5, transform=None):
        """
        手指静脉数据集
        
        Args:
            image_dir: 图像目录路径
            samples: 样本列表，每个元素包含 image_path, label, filename
            image_size: 图像大小
            binary_threshold: 二值化阈值
            transform: 变换
        """
        self.image_dir = Path(image_dir)
        self.samples = samples
        self.image_size = image_size
        self.binary_threshold = binary_threshold
        self.transform = transform
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        image_path = sample['image_path']
        label = sample['label']
        filename = sample['filename']
        
        # 读取图像为灰度图
        image = Image.open(image_path).convert('L')
        
        # 调整大小
        image = image.resize((self.image_size, self.image_size))
        
        # 转换为 numpy 数组
        image_np = np.array(image, dtype=np.float32) / 255.0
        
        # 二值化
        image_np = (image_np > self.binary_threshold).astype(np.float32)
        
        # 应用变换
        if self.transform:
            image_np = self.transform(image_np)
        
        # 转换为张量并添加通道维度
        image_tensor = torch.tensor(image_np).unsqueeze(0)  # 形状变为 [1, image_size, image_size]
        
        return image_tensor, label, filename

class AugmentedFingerVeinDataset(Dataset):
    def __init__(self, samples, image_size=224, binary_threshold=0.5, transform=None):
        """
        增强手指静脉数据集
        
        Args:
            samples: 样本列表，每个元素包含 filename, label, path, is_augmented
            image_size: 图像大小
            binary_threshold: 二值化阈值
            transform: 变换
        """
        self.samples = samples
        self.image_size = image_size
        self.binary_threshold = binary_threshold
        self.transform = transform
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        image_path = sample['path']
        label = sample['label']
        is_augmented = sample['is_augmented']
        
        # 读取图像为灰度图
        image = Image.open(image_path).convert('L')
        
        # 调整大小
        image = image.resize((self.image_size, self.image_size))
        
        # 转换为 numpy 数组
        image_np = np.array(image, dtype=np.float32) / 255.0
        
        # 二值化
        image_np = (image_np > self.binary_threshold).astype(np.float32)
        
        # 应用变换
        if self.transform:
            image_np = self.transform(image_np)
        
        # 转换为张量并添加通道维度
        image_tensor = torch.tensor(image_np).unsqueeze(0)  # 形状变为 [1, image_size, image_size]
        
        return image_tensor, label, is_augmented

def load_augmented_samples(csv_path):
    """
    从 CSV 文件加载增强样本列表
    
    Args:
        csv_path: CSV 文件路径
    
    Returns:
        samples: 样本列表
    """
    samples = []
    with open(csv_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            samples.append({
                'filename': row['filename'],
                'label': int(row['label']),
                'path': row['path'],
                'is_augmented': int(row['is_augmented'])
            })
    return samples