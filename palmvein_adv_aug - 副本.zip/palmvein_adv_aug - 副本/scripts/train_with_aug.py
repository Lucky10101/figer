import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import AugmentedFingerVeinDataset, load_augmented_samples
from models.resnet18_binary import create_resnet18_binary
import random
import numpy as np
import matplotlib.pyplot as plt
import csv

# 设置随机种子
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

# 训练一个 epoch
def train_one_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    correct_original = 0
    total_original = 0
    correct_augmented = 0
    total_augmented = 0

    for images, labels, is_augmented in dataloader:
        images = images.to(device)
        labels = labels.to(device)
        is_augmented = is_augmented.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

        # 区分原图和扰动图的准确率
        mask_original = (is_augmented == 0)
        mask_augmented = (is_augmented == 1)

        if mask_original.any():
            total_original += mask_original.sum().item()
            correct_original += predicted[mask_original].eq(labels[mask_original]).sum().item()

        if mask_augmented.any():
            total_augmented += mask_augmented.sum().item()
            correct_augmented += predicted[mask_augmented].eq(labels[mask_augmented]).sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc_all = correct / total
    epoch_acc_original = correct_original / total_original if total_original > 0 else 0
    epoch_acc_augmented = correct_augmented / total_augmented if total_augmented > 0 else 0

    return epoch_loss, epoch_acc_all, epoch_acc_original, epoch_acc_augmented

# 验证
def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels, _ in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc = correct / total
    return epoch_loss, epoch_acc

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Train model with augmented data')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml',
                        help='Path to baseline config file')
    parser.add_argument('--aug_config', type=str, default='../configs/aug_train.yaml',
                        help='Path to augmentation training config file')
    args = parser.parse_args()

    # 读取 baseline 配置
    with open(args.config, 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)

    # 读取增强训练配置
    with open(args.aug_config, 'r', encoding='utf-8') as f:
        aug_config = yaml.safe_load(f)

    # 合并配置（aug_config 覆盖 baseline_config）
    config = {**baseline_config, **aug_config}

    # 设置随机种子
    set_seed(config['seed'])

    # 创建目录
    checkpoint_dir = Path(config['checkpoint_dir'])
    output_dir = Path(config['output_dir'])
    checkpoint_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)

    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')

    # 加载增强数据集
    aug_dataset_dir = Path('./outputs/aug_dataset')
    train_samples = load_augmented_samples(aug_dataset_dir / 'train_list.csv')
    val_samples = load_augmented_samples(aug_dataset_dir / 'val_list.csv')

    print(f'Train samples: {len(train_samples)}')
    print(f'Val samples: {len(val_samples)}')

    # 统计增强样本比例
    num_augmented = sum(1 for s in train_samples if s['is_augmented'] == 1)
    print(f'Augmented samples in train: {num_augmented}')

    # 创建数据集
    train_dataset = AugmentedFingerVeinDataset(
        samples=train_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    val_dataset = AugmentedFingerVeinDataset(
        samples=val_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers']
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )

    # 创建模型
    model = create_resnet18_binary(
        num_classes=config['num_classes'],
        dropout=config.get('dropout', 0.5)
    ).to(device)

    # 损失函数
    label_smoothing = config.get('label_smoothing', 0.0)
    if label_smoothing > 0:
        criterion = nn.CrossEntropyLoss(label_smoothing=label_smoothing)
    else:
        criterion = nn.CrossEntropyLoss()

    # 优化器
    optimizer_name = config.get('optimizer', 'adam').lower()
    if optimizer_name == 'adam':
        optimizer = optim.Adam(
            model.parameters(),
            lr=config['learning_rate'],
            weight_decay=config['weight_decay']
        )
    elif optimizer_name == 'sgd':
        optimizer = optim.SGD(
            model.parameters(),
            lr=config['learning_rate'],
            momentum=0.9,
            weight_decay=config['weight_decay']
        )
    else:
        raise ValueError(f"Unsupported optimizer: {optimizer_name}")

    # 早停设置
    early_stop_metric = config.get('early_stop_metric', 'val_loss')
    early_stop_patience = config.get('early_stop_patience', 10)
    min_delta = config.get('min_delta', 0.001)

    # 训练循环
    best_val_acc = 0.0
    best_val_loss = float('inf')
    best_epoch = 0
    patience_counter = 0

    # 训练日志
    training_log = []

    for epoch in range(config['num_epochs']):
        # 训练
        train_loss, train_acc_all, train_acc_original, train_acc_augmented = train_one_epoch(
            model, train_loader, criterion, optimizer, device
        )

        # 验证
        val_loss, val_acc = evaluate(
            model, val_loader, criterion, device
        )

        # 计算 train-val gap
        train_val_gap = train_acc_all - val_acc

        # 判断是否保存最佳模型
        is_best = False
        if early_stop_metric == 'val_loss':
            if val_loss < best_val_loss - min_delta:
                best_val_loss = val_loss
                best_val_acc = val_acc
                best_epoch = epoch + 1
                patience_counter = 0
                is_best = True
                # 保存最佳模型
                save_path = checkpoint_dir / 'resnet18_aug_best.pth'
                torch.save({
                    'epoch': epoch + 1,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'best_val_acc': best_val_acc,
                    'best_val_loss': best_val_loss,
                    'config': config
                }, save_path)
                print(f'Best model saved to {save_path}')
            else:
                patience_counter += 1
        else:  # val_acc
            if val_acc > best_val_acc + min_delta:
                best_val_acc = val_acc
                best_val_loss = val_loss
                best_epoch = epoch + 1
                patience_counter = 0
                is_best = True
                # 保存最佳模型
                save_path = checkpoint_dir / 'resnet18_aug_best.pth'
                torch.save({
                    'epoch': epoch + 1,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'best_val_acc': best_val_acc,
                    'best_val_loss': best_val_loss,
                    'config': config
                }, save_path)
                print(f'Best model saved to {save_path}')
            else:
                patience_counter += 1

        # 记录日志
        training_log.append({
            'epoch': epoch + 1,
            'train_loss': train_loss,
            'train_acc_all': train_acc_all,
            'train_acc_original': train_acc_original,
            'train_acc_augmented': train_acc_augmented,
            'val_loss': val_loss,
            'val_acc': val_acc,
            'train_val_gap': train_val_gap,
            'best_val_acc': best_val_acc,
            'best_val_loss': best_val_loss,
            'is_best': 1 if is_best else 0
        })

        # 打印结果
        print(f'Epoch [{epoch+1}/{config["num_epochs"]}]: ')
        print(f'  Train Loss: {train_loss:.4f}')
        print(f'  Train Acc (All): {train_acc_all:.4f}')
        print(f'  Train Acc (Original): {train_acc_original:.4f}')
        print(f'  Train Acc (Augmented): {train_acc_augmented:.4f}')
        print(f'  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}')
        print(f'  Train-Val Gap: {train_val_gap:.4f}')

        # 检查是否早停
        if patience_counter >= early_stop_patience:
            print(f'\nEarly stopping triggered at epoch {epoch + 1}')
            print(f'Best epoch: {best_epoch}')
            print(f'Best Val Acc: {best_val_acc:.4f}')
            break

    # 保存最后一个模型
    last_save_path = checkpoint_dir / 'resnet18_aug_last.pth'
    torch.save({
        'epoch': epoch + 1,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_val_acc': best_val_acc,
        'best_val_loss': best_val_loss,
        'config': config
    }, last_save_path)
    print(f'Last model saved to {last_save_path}')

    # 保存训练日志
    log_path = output_dir / 'aug_training_log.csv'
    with open(log_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=training_log[0].keys())
        writer.writeheader()
        writer.writerows(training_log)
    print(f'Training log saved to {log_path}')

    # 保存训练曲线
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))

    # Loss 曲线
    axes[0, 0].plot([entry['epoch'] for entry in training_log], [entry['train_loss'] for entry in training_log], label='Train Loss')
    axes[0, 0].plot([entry['epoch'] for entry in training_log], [entry['val_loss'] for entry in training_log], label='Val Loss')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].set_title('Training and Validation Loss')
    axes[0, 0].legend()
    axes[0, 0].grid(True)

    # Accuracy 曲线
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['train_acc_all'] for entry in training_log], label='Train Acc (All)')
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['train_acc_original'] for entry in training_log], label='Train Acc (Original)')
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['train_acc_augmented'] for entry in training_log], label='Train Acc (Augmented)')
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['val_acc'] for entry in training_log], label='Val Acc')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Accuracy')
    axes[0, 1].set_title('Training and Validation Accuracy')
    axes[0, 1].legend()
    axes[0, 1].grid(True)

    # Train-Val Gap 曲线
    axes[1, 0].plot([entry['epoch'] for entry in training_log], [entry['train_val_gap'] for entry in training_log], label='Train-Val Gap', color='red')
    axes[1, 0].axhline(y=0, color='gray', linestyle='-', alpha=0.5)
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('Gap')
    axes[1, 0].set_title('Train-Val Accuracy Gap')
    axes[1, 0].legend()
    axes[1, 0].grid(True)

    # Best Val Acc 曲线
    axes[1, 1].plot([entry['epoch'] for entry in training_log], [entry['best_val_acc'] for entry in training_log], label='Best Val Acc', color='purple')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Accuracy')
    axes[1, 1].set_title('Best Validation Accuracy over Epochs')
    axes[1, 1].legend()
    axes[1, 1].grid(True)

    plt.tight_layout()
    curve_path = output_dir / 'aug_training_curves.png'
    plt.savefig(curve_path)
    print(f'Training curves saved to {curve_path}')
    plt.close()

if __name__ == '__main__':
    main()