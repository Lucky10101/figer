import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import csv
from datasets.finger_vein_dataset import build_class_balanced_splits
import random

# 设置随机种子
def set_seed(seed):
    random.seed(seed)

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Build augmented dataset')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml',
                        help='Path to baseline config file')
    parser.add_argument('--aug_config', type=str, default=None,
                        help='Path to augmentation config file')
    parser.add_argument('--aug_type', type=str, choices=['fgsm', 'deform', 'mhoa', 'centerline_deform'], default='fgsm',
                        help='Type of augmentation: fgsm, deform, mhoa, or centerline_deform')
    parser.add_argument('--aug_ratio', type=float, default=1.0,
                        help='Ratio of augmented samples to original samples')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default='train',
                        help='Split to augment')
    args = parser.parse_args()
    
    # 读取 baseline 配置
    with open(args.config, 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)
    
    # 根据 aug_type 选择配置文件
    if args.aug_config is None:
        if args.aug_type == 'fgsm':
            args.aug_config = '../configs/fgsm_aug.yaml'
        elif args.aug_type == 'deform':
            args.aug_config = '../configs/deform_aug.yaml'
        elif args.aug_type == 'mhoa':
            args.aug_config = '../configs/mhoa_aug.yaml'
        else:  # centerline_deform
            args.aug_config = '../configs/centerline_deform.yaml'
    
    # 读取增强配置
    with open(args.aug_config, 'r', encoding='utf-8') as f:
        aug_config = yaml.safe_load(f)
    
    # 设置随机种子
    set_seed(baseline_config['seed'])
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )
    
    # 获取扰动图像目录
    output_dir = Path(aug_config['output_dir'])
    aug_binary_dir = output_dir / args.split / 'binary'
    
    if not aug_binary_dir.exists():
        raise FileNotFoundError(f"Augmented binary images directory not found: {aug_binary_dir}")
    
    print(f"Using augmentation type: {args.aug_type}")
    print(f"Augmented images directory: {aug_binary_dir}")
    
    # 获取原始训练样本
    original_train = train_samples

    # 获取扰动训练样本
    aug_samples = []

    # 如果是 MHOA 或 centerline_deform 增强，只读取 accepted=True 且 keep_correct=True 的样本
    if args.aug_type in ['mhoa', 'centerline_deform']:
        metrics_path = output_dir / f'{args.split}_metrics.csv'
        if not metrics_path.exists():
            raise FileNotFoundError(f"{args.aug_type} metrics file not found: {metrics_path}")

        # 读取 metrics 文件，筛选 accepted=True 且 keep_correct=True 的样本
        accepted_filenames = set()
        with open(metrics_path, 'r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    accepted = int(row.get('accepted', '0')) == 1
                    keep_correct = int(row.get('keep_correct', '0')) == 1
                    if accepted and keep_correct:
                        accepted_filenames.add(row['filename'])
                except:
                    pass

        print(f"Found {len(accepted_filenames)} accepted samples from {metrics_path}")

        for sample in original_train:
            filename = sample['filename']
            aug_path = aug_binary_dir / filename

            if aug_path.exists() and filename in accepted_filenames:
                aug_samples.append({
                    'filename': filename,
                    'label': sample['label'],
                    'path': str(aug_path),
                    'is_augmented': 1
                })
    else:
        # FGSM 或 deform 增强，直接使用所有扰动样本
        for sample in original_train:
            filename = sample['filename']
            aug_path = aug_binary_dir / filename

            if aug_path.exists():
                aug_samples.append({
                    'filename': filename,
                    'label': sample['label'],
                    'path': str(aug_path),
                    'is_augmented': 1
                })
    
    # 根据 aug_ratio 随机选择扰动样本
    if args.aug_ratio < 1.0:
        num_to_select = int(len(aug_samples) * args.aug_ratio)
        aug_samples = random.sample(aug_samples, num_to_select)
    elif args.aug_ratio > 1.0:
        # 如果 aug_ratio > 1.0，可以重复采样
        augmented_samples = []
        for _ in range(int(args.aug_ratio)):
            augmented_samples.extend(aug_samples)
        aug_samples = augmented_samples
    
    # 构建增强训练集：原始训练样本 + 扰动样本
    augmented_train = []
    
    # 添加原始样本
    for sample in original_train:
        augmented_train.append({
            'filename': sample['filename'],
            'label': sample['label'],
            'path': str(sample['image_path']),
            'is_augmented': 0
        })
    
    # 添加扰动样本
    augmented_train.extend(aug_samples)
    
    # 创建输出目录
    output_dataset_dir = Path('./outputs/aug_dataset')
    output_dataset_dir.mkdir(parents=True, exist_ok=True)
    
    # 保存增强训练集列表
    train_list_path = output_dataset_dir / 'train_list.csv'
    with open(train_list_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['filename', 'label', 'path', 'is_augmented'])
        for sample in augmented_train:
            writer.writerow([sample['filename'], sample['label'], sample['path'], sample['is_augmented']])
    
    print(f"Augmented training set saved to: {train_list_path}")
    print(f"Original train samples: {len(original_train)}")
    print(f"Augmented samples: {len(aug_samples)}")
    print(f"Total augmented train samples: {len(augmented_train)}")
    
    # 保存验证集列表（保持不变）
    val_list_path = output_dataset_dir / 'val_list.csv'
    with open(val_list_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['filename', 'label', 'path', 'is_augmented'])
        for sample in val_samples:
            writer.writerow([sample['filename'], sample['label'], str(sample['image_path']), 0])
    
    print(f"Validation set saved to: {val_list_path}")
    print(f"Validation samples: {len(val_samples)}")
    
    # 保存测试集列表（保持不变）
    test_list_path = output_dataset_dir / 'test_list.csv'
    with open(test_list_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['filename', 'label', 'path', 'is_augmented'])
        for sample in test_samples:
            writer.writerow([sample['filename'], sample['label'], str(sample['image_path']), 0])
    
    print(f"Test set saved to: {test_list_path}")
    print(f"Test samples: {len(test_samples)}")

if __name__ == '__main__':
    main()