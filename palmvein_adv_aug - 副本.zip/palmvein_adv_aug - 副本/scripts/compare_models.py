import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
import csv

# 评估函数
def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels, _ in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc = correct / total
    return epoch_loss, epoch_acc

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Compare baseline and augmented models')
    parser.add_argument('--baseline_ckpt', type=str, default='./checkpoints/resnet18_binary_best.pth',
                        help='Path to baseline checkpoint')
    parser.add_argument('--aug_ckpt', type=str, default='./checkpoints/resnet18_aug_best.pth',
                        help='Path to augmented checkpoint')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml',
                        help='Path to baseline config file')
    args = parser.parse_args()

    # 读取配置
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')

    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=config['mask_dir'],
        images_per_class=config['images_per_class'],
        num_classes=config['num_classes'],
        train_per_class=config['train_per_class'],
        val_per_class=config['val_per_class'],
        test_per_class=config['test_per_class'],
        seed=config['seed']
    )

    # 创建数据集
    train_dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=train_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    val_dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=val_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    test_dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=test_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )

    # 创建模型
    baseline_model = create_resnet18_binary(
        num_classes=config['num_classes'],
        dropout=config.get('dropout', 0.5)
    ).to(device)

    aug_model = create_resnet18_binary(
        num_classes=config['num_classes'],
        dropout=config.get('dropout', 0.5)
    ).to(device)

    # 加载模型权重
    baseline_checkpoint = torch.load(args.baseline_ckpt, map_location=device)
    aug_checkpoint = torch.load(args.aug_ckpt, map_location=device)

    if 'model_state_dict' in baseline_checkpoint:
        baseline_model.load_state_dict(baseline_checkpoint['model_state_dict'])
    else:
        baseline_model.load_state_dict(baseline_checkpoint)

    if 'model_state_dict' in aug_checkpoint:
        aug_model.load_state_dict(aug_checkpoint['model_state_dict'])
    else:
        aug_model.load_state_dict(aug_checkpoint)

    # 设置为 eval 模式
    baseline_model.eval()
    aug_model.eval()

    # 损失函数
    criterion = nn.CrossEntropyLoss()

    # 评估 baseline 模型
    print('Evaluating Baseline model...')
    baseline_train_loss, baseline_train_acc = evaluate(baseline_model, train_loader, criterion, device)
    baseline_val_loss, baseline_val_acc = evaluate(baseline_model, val_loader, criterion, device)
    baseline_test_loss, baseline_test_acc = evaluate(baseline_model, test_loader, criterion, device)
    baseline_gap = baseline_train_acc - baseline_val_acc

    # 评估 augmented 模型
    print('Evaluating Augmented model...')
    aug_train_loss, aug_train_acc = evaluate(aug_model, train_loader, criterion, device)
    aug_val_loss, aug_val_acc = evaluate(aug_model, val_loader, criterion, device)
    aug_test_loss, aug_test_acc = evaluate(aug_model, test_loader, criterion, device)
    aug_gap = aug_train_acc - aug_val_acc

    # 打印对比表格
    print('\n' + '='*70)
    print(f"{'Model':<15} {'Train Acc':<12} {'Val Acc':<12} {'Test Acc':<12} {'Gap':<10}")
    print('-'*70)
    print(f"{'Baseline':<15} {baseline_train_acc:<12.4f} {baseline_val_acc:<12.4f} {baseline_test_acc:<12.4f} {baseline_gap:<10.4f}")
    print(f"{'Augmented':<15} {aug_train_acc:<12.4f} {aug_val_acc:<12.4f} {aug_test_acc:<12.4f} {aug_gap:<10.4f}")
    print('='*70)

    # 分析结果
    print('\n=== 结果分析 ===')
    
    # 比较 Val Acc
    if aug_val_acc > baseline_val_acc + 0.001:
        print(f'✓ Val Acc 提升: {baseline_val_acc:.4f} → {aug_val_acc:.4f} (+{(aug_val_acc - baseline_val_acc)*100:.2f}%)')
    else:
        print(f'✗ Val Acc 未提升: {baseline_val_acc:.4f} → {aug_val_acc:.4f}')

    # 比较 Gap
    if aug_gap < baseline_gap - 0.001:
        print(f'✓ Train-Val Gap 减小: {baseline_gap:.4f} → {aug_gap:.4f} (-{(baseline_gap - aug_gap)*100:.2f}%)')
    else:
        print(f'✗ Train-Val Gap 未减小: {baseline_gap:.4f} → {aug_gap:.4f}')

    # 比较 Test Acc
    if aug_test_acc > baseline_test_acc + 0.001:
        print(f'✓ Test Acc 提升: {baseline_test_acc:.4f} → {aug_test_acc:.4f} (+{(aug_test_acc - baseline_test_acc)*100:.2f}%)')
    else:
        print(f'✗ Test Acc 未提升: {baseline_test_acc:.4f} → {aug_test_acc:.4f}')

    # 综合判断
    if aug_val_acc > baseline_val_acc + 0.001 and aug_gap < baseline_gap - 0.001:
        print('\n🎉 增强训练成功！扰动数据有效提升了模型泛化能力。')
    elif aug_val_acc > baseline_val_acc + 0.001:
        print('\n⚠️  Val Acc 提升但 Gap 未减小，建议进一步调整扰动参数。')
    else:
        print('\n❌ 增强训练未达到预期效果，建议尝试不同的 aug_ratio 或调整扰动参数。')

    # 保存对比结果
    output_dir = Path(config['output_dir'])
    comparison_path = output_dir / 'model_comparison.csv'
    
    with open(comparison_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Model', 'Train Acc', 'Val Acc', 'Test Acc', 'Train-Val Gap'])
        writer.writerow(['Baseline', baseline_train_acc, baseline_val_acc, baseline_test_acc, baseline_gap])
        writer.writerow(['Augmented', aug_train_acc, aug_val_acc, aug_test_acc, aug_gap])
    
    print(f'\nComparison results saved to {comparison_path}')

if __name__ == '__main__':
    main()