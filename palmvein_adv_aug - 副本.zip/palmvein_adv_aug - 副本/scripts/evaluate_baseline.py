import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import csv

# 评估函数
def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    all_labels = []
    all_preds = []
    all_filenames = []
    all_confidences = []
    
    with torch.no_grad():
        for images, labels, filenames in dataloader:
            images = images.to(device)
            labels = labels.to(device)
            
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            
            # 计算置信度（使用 softmax）
            confidences = torch.softmax(outputs, dim=1).max(dim=1)[0]
            
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
            
            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(predicted.cpu().numpy())
            all_filenames.extend(filenames)
            all_confidences.extend(confidences.cpu().numpy())
    
    overall_acc = correct / total
    average_loss = running_loss / total
    
    # 计算每个类别的准确率
    class_acc = []
    for cls in range(100):
        cls_indices = [i for i, label in enumerate(all_labels) if label == cls]
        cls_preds = [all_preds[i] for i in cls_indices]
        cls_correct = sum(1 for pred in cls_preds if pred == cls)
        cls_total = len(cls_indices)
        cls_acc.append(cls_correct / cls_total if cls_total > 0 else 0)
    
    return overall_acc, average_loss, class_acc, all_filenames, all_labels, all_preds, all_confidences

# 保存混淆矩阵
def save_confusion_matrix(labels, preds, save_path, num_classes=100):
    cm = np.zeros((num_classes, num_classes), dtype=int)
    for true, pred in zip(labels, preds):
        cm[true, pred] += 1
    
    plt.figure(figsize=(20, 16))
    sns.heatmap(cm, annot=False, fmt='d', cmap='Blues')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix')
    plt.savefig(save_path)
    plt.close()

# 保存预测结果
def save_predictions(filenames, labels, preds, confidences, save_path):
    with open(save_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['filename', 'true_label', 'pred_label', 'correct', 'confidence'])
        for filename, true_label, pred_label, confidence in zip(filenames, labels, preds, confidences):
            correct = 1 if true_label == pred_label else 0
            writer.writerow([filename, true_label, pred_label, correct, confidence])

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Evaluate baseline model for finger vein classification')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml', help='Path to config file')
    parser.add_argument('--checkpoint', type=str, default='../checkpoints/resnet18_binary_best.pth', help='Path to checkpoint file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default='test', help='Split to evaluate')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=config['mask_dir'],
        images_per_class=config['images_per_class'],
        num_classes=config['num_classes'],
        train_per_class=config['train_per_class'],
        val_per_class=config['val_per_class'],
        test_per_class=config['test_per_class'],
        seed=config['seed']
    )
    
    # 选择要评估的分割
    if args.split == 'train':
        samples = train_samples
    elif args.split == 'val':
        samples = val_samples
    else:  # test
        samples = test_samples
    
    print(f'Evaluating {args.split} split with {len(samples)} samples')
    
    # 创建数据集
    dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )
    
    # 创建数据加载器
    dataloader = DataLoader(
        dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )
    
    # 创建模型
    model = create_resnet18_binary(
        num_classes=config['num_classes'],
        dropout=config.get('dropout', 0.5)
    ).to(device)
    
    # 加载模型权重
    checkpoint_path = Path(args.checkpoint)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {args.checkpoint} does not exist")
    
    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    
    # 损失函数
    criterion = nn.CrossEntropyLoss()
    
    # 评估
    overall_acc, average_loss, class_acc, filenames, labels, preds, confidences = evaluate(
        model, dataloader, criterion, device
    )
    
    # 输出结果
    print(f'Overall Accuracy: {overall_acc:.4f}')
    print(f'Average Loss: {average_loss:.4f}')
    print('Per-class Accuracy:')
    for cls in range(config['num_classes']):
        print(f'Class {cls}: {class_acc[cls]:.4f}')
    
    # 创建输出目录
    output_dir = Path(config['output_dir'])
    output_dir.mkdir(exist_ok=True)
    
    # 保存混淆矩阵
    confusion_matrix_path = output_dir / f'confusion_matrix_{args.split}.png'
    save_confusion_matrix(labels, preds, confusion_matrix_path, num_classes=config['num_classes'])
    print(f'Confusion matrix saved to {confusion_matrix_path}')
    
    # 保存预测结果
    predictions_path = output_dir / f'{args.split}_predictions.csv'
    save_predictions(filenames, labels, preds, confidences, predictions_path)
    print(f'Predictions saved to {predictions_path}')

if __name__ == '__main__':
    main()