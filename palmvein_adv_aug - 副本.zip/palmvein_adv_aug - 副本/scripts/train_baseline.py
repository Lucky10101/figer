import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
import random
import numpy as np
import matplotlib.pyplot as plt
import csv
from PIL import Image

# 设置随机种子
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

# 训练一个 epoch
def train_one_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for images, labels, _ in dataloader:
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc = correct / total
    return epoch_loss, epoch_acc

# 验证
def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels, _ in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc = correct / total
    return epoch_loss, epoch_acc

# 训练增强变换
class TrainAugmentation:
    def __init__(self, rotation_degrees=10, translate=0.05, scale_min=0.95, scale_max=1.05, horizontal_flip=False):
        self.rotation_degrees = rotation_degrees
        self.translate = translate
        self.scale_min = scale_min
        self.scale_max = scale_max
        self.horizontal_flip = horizontal_flip

    def __call__(self, image):
        # 转换为 PIL 图像
        img = Image.fromarray((image * 255).astype(np.uint8), mode='L')

        # 随机旋转
        if self.rotation_degrees > 0:
            angle = random.uniform(-self.rotation_degrees, self.rotation_degrees)
            img = img.rotate(angle, fillcolor=0)

        # 随机仿射变换
        if self.translate > 0 or self.scale_min < 1.0 or self.scale_max > 1.0:
            translate_x = random.uniform(-self.translate, self.translate)
            translate_y = random.uniform(-self.translate, self.translate)
            scale = random.uniform(self.scale_min, self.scale_max)
            img = img.transform(
                img.size,
                Image.AFFINE,
                (scale, 0, translate_x * img.width, 0, scale, translate_y * img.height),
                fillcolor=0
            )

        # 水平翻转
        if self.horizontal_flip and random.random() > 0.5:
            img = img.transpose(Image.FLIP_LEFT_RIGHT)

        # 转换回 numpy 数组
        return np.array(img, dtype=np.float32) / 255.0

# 保存检查点
def save_checkpoint(model, optimizer, epoch, best_val_acc, best_val_loss, config, save_path):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_val_acc': best_val_acc,
        'best_val_loss': best_val_loss,
        'config': config
    }, save_path)

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Train baseline model for finger vein classification')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml',
                        help='Path to config file')
    args = parser.parse_args()

    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 设置随机种子
    set_seed(config['seed'])

    # 创建目录
    checkpoint_dir = Path(config['checkpoint_dir'])
    output_dir = Path(config['output_dir'])
    checkpoint_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)

    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')

    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=config['mask_dir'],
        images_per_class=config['images_per_class'],
        num_classes=config['num_classes'],
        train_per_class=config['train_per_class'],
        val_per_class=config['val_per_class'],
        test_per_class=config['test_per_class'],
        seed=config['seed']
    )

    print(f'Train samples: {len(train_samples)}')
    print(f'Val samples: {len(val_samples)}')
    print(f'Test samples: {len(test_samples)}')

    # 创建数据集
    if config.get('use_train_augmentation', False):
        train_transform = TrainAugmentation(
            rotation_degrees=config.get('rotation_degrees', 10),
            translate=config.get('translate', 0.05),
            scale_min=config.get('scale_min', 0.95),
            scale_max=config.get('scale_max', 1.05),
            horizontal_flip=config.get('horizontal_flip', False)
        )
    else:
        train_transform = None

    train_dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=train_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold'],
        transform=train_transform
    )

    val_dataset = FingerVeinDataset(
        image_dir=config['mask_dir'],
        samples=val_samples,
        image_size=config['image_size'],
        binary_threshold=config['binary_threshold']
    )

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers']
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )

    # 创建模型
    model = create_resnet18_binary(
        num_classes=config['num_classes'],
        dropout=config.get('dropout', 0.5)
    ).to(device)

    # 损失函数
    label_smoothing = config.get('label_smoothing', 0.0)
    if label_smoothing > 0:
        criterion = nn.CrossEntropyLoss(label_smoothing=label_smoothing)
    else:
        criterion = nn.CrossEntropyLoss()

    # 优化器
    optimizer_name = config.get('optimizer', 'adam').lower()
    if optimizer_name == 'adam':
        optimizer = optim.Adam(
            model.parameters(),
            lr=config['learning_rate'],
            weight_decay=config['weight_decay']
        )
    elif optimizer_name == 'sgd':
        optimizer = optim.SGD(
            model.parameters(),
            lr=config['learning_rate'],
            momentum=0.9,
            weight_decay=config['weight_decay']
        )
    else:
        raise ValueError(f"Unsupported optimizer: {optimizer_name}")

    # 早停设置
    early_stop_metric = config.get('early_stop_metric', 'val_acc')
    early_stop_patience = config.get('early_stop_patience', 12)
    min_delta = config.get('min_delta', 0.001)

    # 过拟合早停设置
    enable_overfit_early_stop = config.get('enable_overfit_early_stop', True)
    overfit_train_acc_threshold = config.get('overfit_train_acc_threshold', 0.98)
    overfit_gap_threshold = config.get('overfit_gap_threshold', 0.10)
    overfit_patience = config.get('overfit_patience', 8)

    # 训练循环
    best_val_acc = 0.0
    best_val_loss = float('inf')
    best_epoch = 0
    patience_counter = 0
    overfit_counter = 0

    # 训练日志
    training_log = []

    for epoch in range(config['num_epochs']):
        # 训练
        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device
        )

        # 验证
        val_loss, val_acc = evaluate(
            model, val_loader, criterion, device
        )

        # 计算 train-val gap
        train_val_gap = train_acc - val_acc

        # 判断是否保存最佳模型
        is_best = False
        if early_stop_metric == 'val_loss':
            if val_loss < best_val_loss - min_delta:
                best_val_loss = val_loss
                best_val_acc = val_acc
                best_epoch = epoch + 1
                patience_counter = 0
                overfit_counter = 0
                is_best = True
                # 保存最佳模型
                save_path = checkpoint_dir / 'resnet18_binary_best.pth'
                save_checkpoint(model, optimizer, epoch + 1, best_val_acc, best_val_loss, config, save_path)
                print(f'Best model saved to {save_path}')
            else:
                patience_counter += 1
        else:  # val_acc
            if val_acc > best_val_acc + min_delta:
                best_val_acc = val_acc
                best_val_loss = val_loss
                best_epoch = epoch + 1
                patience_counter = 0
                overfit_counter = 0
                is_best = True
                # 保存最佳模型
                save_path = checkpoint_dir / 'resnet18_binary_best.pth'
                save_checkpoint(model, optimizer, epoch + 1, best_val_acc, best_val_loss, config, save_path)
                print(f'Best model saved to {save_path}')
            else:
                patience_counter += 1

        # 过拟合检测
        if enable_overfit_early_stop:
            if train_acc >= overfit_train_acc_threshold and train_val_gap >= overfit_gap_threshold:
                if val_acc > best_val_acc + min_delta:
                    overfit_counter = 0
                else:
                    overfit_counter += 1

        # 记录日志
        training_log.append({
            'epoch': epoch + 1,
            'train_loss': train_loss,
            'train_acc': train_acc,
            'val_loss': val_loss,
            'val_acc': val_acc,
            'best_val_acc': best_val_acc,
            'best_val_loss': best_val_loss,
            'train_val_acc_gap': train_val_gap,
            'normal_early_stop_counter': patience_counter,
            'overfit_counter': overfit_counter,
            'is_best': 1 if is_best else 0
        })

        # 打印结果
        print(f'Epoch [{epoch+1}/{config["num_epochs"]}]: ')
        print(f'  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}')
        print(f'  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}')
        print(f'  Train-Val Gap: {train_val_gap:.4f}')
        print(f'  Normal Early Stop Counter: {patience_counter}/{early_stop_patience}')
        if enable_overfit_early_stop:
            print(f'  Overfit Counter: {overfit_counter}/{overfit_patience}')

        # 检查是否早停
        should_stop = False
        stop_reason = ''
        stop_type = ''

        # 普通早停检查
        if patience_counter >= early_stop_patience:
            should_stop = True
            stop_reason = 'val_acc did not improve for {} epochs'.format(early_stop_patience)
            stop_type = 'normal'

        # 过拟合早停检查
        if enable_overfit_early_stop and overfit_counter >= overfit_patience:
            should_stop = True
            stop_reason = 'overfitting detected'
            stop_type = 'overfit'

        if should_stop:
            print('\n' + '='*60)
            print('Early stopping triggered at epoch {}'.format(epoch + 1))
            print('Reason: {}'.format(stop_reason))
            print('Best epoch: {}'.format(best_epoch))
            print('Best Val Acc: {:.4f}'.format(best_val_acc))
            print('Best Val Loss: {:.4f}'.format(best_val_loss))
            print('Final Train Acc: {:.4f}'.format(train_acc))
            print('Final Val Acc: {:.4f}'.format(val_acc))
            print('Train-Val Gap: {:.4f}'.format(train_val_gap))
            print('='*60 + '\n')
            break

    # 保存最后一个模型
    last_save_path = checkpoint_dir / 'resnet18_binary_last.pth'
    save_checkpoint(model, optimizer, epoch + 1, best_val_acc, best_val_loss, config, last_save_path)
    print(f'Last model saved to {last_save_path}')

    # 保存训练日志
    log_path = output_dir / 'training_log.csv'
    fieldnames = ['epoch', 'train_loss', 'train_acc', 'val_loss', 'val_acc',
                  'best_val_acc', 'best_val_loss', 'train_val_acc_gap',
                  'normal_early_stop_counter', 'overfit_counter', 'is_best']
    with open(log_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(training_log)
    print(f'Training log saved to {log_path}')

    # 保存训练曲线
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))

    # Loss 曲线
    axes[0, 0].plot([entry['epoch'] for entry in training_log], [entry['train_loss'] for entry in training_log], label='Train Loss')
    axes[0, 0].plot([entry['epoch'] for entry in training_log], [entry['val_loss'] for entry in training_log], label='Val Loss')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].set_title('Training and Validation Loss')
    axes[0, 0].legend()
    axes[0, 0].grid(True)

    # Accuracy 曲线
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['train_acc'] for entry in training_log], label='Train Acc')
    axes[0, 1].plot([entry['epoch'] for entry in training_log], [entry['val_acc'] for entry in training_log], label='Val Acc')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Accuracy')
    axes[0, 1].set_title('Training and Validation Accuracy')
    axes[0, 1].legend()
    axes[0, 1].grid(True)

    # Train-Val Gap 曲线
    axes[1, 0].plot([entry['epoch'] for entry in training_log], [entry['train_val_acc_gap'] for entry in training_log], label='Train-Val Gap', color='red')
    axes[1, 0].axhline(y=overfit_gap_threshold, color='green', linestyle='--', label=f'Overfit Threshold ({overfit_gap_threshold})')
    axes[1, 0].axhline(y=0, color='gray', linestyle='-', alpha=0.5)
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('Gap')
    axes[1, 0].set_title('Train-Val Accuracy Gap')
    axes[1, 0].legend()
    axes[1, 0].grid(True)

    # Best Val Acc 曲线
    axes[1, 1].plot([entry['epoch'] for entry in training_log], [entry['best_val_acc'] for entry in training_log], label='Best Val Acc', color='purple')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Accuracy')
    axes[1, 1].set_title('Best Validation Accuracy over Epochs')
    axes[1, 1].legend()
    axes[1, 1].grid(True)

    plt.tight_layout()
    curve_path = output_dir / 'training_curves.png'
    plt.savefig(curve_path)
    print(f'Training curves saved to {curve_path}')
    plt.close()

if __name__ == '__main__':
    main()