import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
from perturbations.mhoa_lite import generate_mhoa_lite_aug
from perturbations.keypoint_utils import extract_skeleton_keypoints
from perturbations.topology_filter import compute_topology_metrics
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import csv
from PIL import Image
from skimage import morphology


# 设置随机种子
def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def visualize_flow(flow):
    """
    可视化位移场
    """
    # 确保flow在CPU上并转换为numpy
    if isinstance(flow, torch.Tensor):
        dx = flow[0].cpu().numpy()
        dy = flow[1].cpu().numpy()
    else:
        dx = flow[0]
        dy = flow[1]

    magnitude = np.sqrt(dx ** 2 + dy ** 2)
    angle = np.arctan2(dy, dx)

    # 创建HSV图像
    hsv = np.zeros((dx.shape[0], dx.shape[1], 3), dtype=np.float32)
    hsv[..., 0] = (angle + np.pi) / (2 * np.pi)
    hsv[..., 1] = 1.0  # 饱和度设为1
    hsv[..., 2] = magnitude / (magnitude.max() + 1e-6) if magnitude.max() > 0 else 0

    # 转换为RGB
    rgb = plt.cm.hsv(hsv[..., 0])
    rgb = rgb[..., :3]
    rgb = rgb * hsv[..., 1:2] * hsv[..., 2:3]
    rgb = (rgb * 255).astype(np.uint8)

    return rgb


def visualize_skeleton_with_keypoints(binary_img, keypoints):
    """
    可视化骨架和关键点
    """
    skeleton = morphology.skeletonize(binary_img > 0).astype(np.uint8) * 255

    # 创建 RGB 图像
    vis = np.zeros((binary_img.shape[0], binary_img.shape[1], 3), dtype=np.uint8)
    vis[..., 0] = skeleton  # 红色显示骨架
    vis[..., 1] = skeleton
    vis[..., 2] = skeleton

    # 标记关键点
    for x, y in keypoints:
        x, y = int(x), int(y)
        if 0 <= x < vis.shape[1] and 0 <= y < vis.shape[0]:
            vis[y - 2:y + 3, x - 2:x + 3, 0] = 255  # 绿色标记关键点
            vis[y - 2:y + 3, x - 2:x + 3, 1] = 0
            vis[y - 2:y + 3, x - 2:x + 3, 2] = 255

    return vis


# 主函数
def main():
    parser = argparse.ArgumentParser(description='Generate MHOA-lite augmentation')
    parser.add_argument('--config', type=str, default='../configs/mhoa_aug.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default=None,
                        help='Split to generate perturbations for')
    args = parser.parse_args()

    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    if args.split is not None:
        config['split'] = args.split

    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)

    # 设置随机种子
    set_seed(config['seed'])

    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')

    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )

    split = config['split']
    if split == 'train':
        samples = train_samples
    elif split == 'val':
        samples = val_samples
    else:
        samples = test_samples

    print(f'Processing {split} split with {len(samples)} samples')

    # 创建数据集
    dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )

    # 创建数据加载器
    dataloader = DataLoader(
        dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=0
    )

    # 创建模型
    model = create_resnet18_binary(
        num_classes=baseline_config['num_classes'],
        dropout=baseline_config.get('dropout', 0.5)
    )

    # 加载模型权重
    checkpoint_path = Path(config['checkpoint'])
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {config['checkpoint']} does not exist")

    checkpoint = torch.load(checkpoint_path, map_location=device)

    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)

    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    model = model.to(device)

    # 创建输出目录
    output_dir = Path(config['output_dir'])
    binary_dir = output_dir / split / 'binary'
    flow_dir = output_dir / split / 'flow'
    vis_dir = output_dir / 'vis'

    binary_dir.mkdir(parents=True, exist_ok=True)
    flow_dir.mkdir(parents=True, exist_ok=True)
    vis_dir.mkdir(parents=True, exist_ok=True)

    # 拓扑约束配置
    topology_cfg = {
        'max_fg_diff': config.get('max_fg_diff', 0.03),
        'max_component_diff': config.get('max_component_diff', 3),
        'max_endpoint_diff': config.get('max_endpoint_diff', 10),
        'max_branchpoint_diff': config.get('max_branchpoint_diff', 10),
        'min_largest_component_ratio': config.get('min_largest_component_ratio', 0.6),
        'min_changed_ratio': config.get('min_changed_ratio', 0.01),
        'max_changed_ratio': config.get('max_changed_ratio', 0.20)
    }

    # 存储所有 trial 级别的指标
    all_trial_metrics = []

    # 存储最终指标
    all_metrics = []
    acceptance_count = 0
    total_count = 0

    # 收集可视化样本
    vis_samples = []

    for batch_idx, (images, labels, filenames) in enumerate(dataloader):
        print(f'Processing batch {batch_idx + 1}/{len(dataloader)}')

        images = images.to(device)
        labels = labels.to(device)

        # 生成 MHOA-lite 增强
        aug_images, flows, metrics_list = generate_mhoa_lite_aug(
            model=model,
            images=images,
            labels=labels,
            max_keypoints=config['max_keypoints'],
            max_disp=config['max_disp'],
            rbf_sigma=config['rbf_sigma'],
            binary_threshold=config['binary_threshold'],
            postprocess=config.get('postprocess', True),
            num_trials=config['num_trials'],
            topology_cfg=topology_cfg,
            device=device,
            disp_mode=config.get('disp_mode', 'random'),
            target_avg_disp=config.get('target_avg_disp', 2.0),
            min_flow_abs_mean=config.get('min_flow_abs_mean', 0.5)
        )

        for i in range(len(filenames)):
            filename = filenames[i]
            label = labels[i].item()
            aug_img = aug_images[i].squeeze().cpu().numpy()
            flow = flows[i]
            metrics = metrics_list[i]

            accepted = metrics.get('reject_reason') == 'accepted'

            # 保存二值增强图 - 修正第1处错误：正确处理数据类型
            binary_img = (aug_img * 255).astype(np.uint8)
            # 如果是2D数组，直接使用；如果是3D且有单通道，去除通道维度
            if binary_img.ndim == 3 and binary_img.shape[0] == 1:
                binary_img = binary_img[0]
            binary_pil = Image.fromarray(binary_img, mode='L')
            binary_pil.save(binary_dir / filename)

            # 保存位移场可视化 - 修正第2处错误：确保flow_vis是RGB格式
            flow_vis = visualize_flow(flow)
            # 确保形状正确
            if flow_vis.ndim == 3 and flow_vis.shape[2] == 3:
                flow_pil = Image.fromarray(flow_vis)
                flow_filename = filename.replace('.bmp', '_flow.png')
                flow_pil.save(flow_dir / flow_filename)

            # 记录指标
            all_metrics.append({
                'filename': filename,
                'label': label,
                'pred': metrics.get('pred', -1),
                'accepted': metrics.get('accepted', 0),
                'reject_reason': metrics.get('reject_reason', 'unknown'),
                'keep_correct': metrics.get('classifier_keep', 0),
                'changed_pixel_ratio': metrics.get('changed_pixel_ratio', 0),
                'flow_abs_mean': metrics.get('flow_abs_mean', 0),
                'flow_abs_max': metrics.get('flow_abs_max', 0),
                'continuous_l1': metrics.get('continuous_l1', 0),
                'continuous_l2': metrics.get('continuous_l2', 0),
                'orig_fg': metrics.get('orig_fg', 0),
                'aug_fg': metrics.get('aug_fg', 0),
                'fg_diff': metrics.get('fg_diff', 0),
                'component_diff': metrics.get('component_diff', 0),
                'endpoint_diff': metrics.get('endpoint_diff', 0),
                'branchpoint_diff': metrics.get('branchpoint_diff', 0),
                'num_endpoints': metrics.get('num_endpoints', 0),
                'num_branchpoints': metrics.get('num_branchpoints', 0),
                'num_components': metrics.get('num_components', 0)
            })

            # 记录 trial-level 指标
            if 'all_trials' in metrics and metrics['all_trials']:
                for trial_rec in metrics['all_trials']:
                    trial_rec['filename'] = filename
                    trial_rec['orig_label'] = label
                    all_trial_metrics.append(trial_rec)

            if metrics.get('accepted', 0) == 1:
                acceptance_count += 1
            total_count += 1

            # 收集可视化样本
            if len(vis_samples) < 10 and batch_idx * config['batch_size'] + i < len(samples):
                original_img = images[i].squeeze().cpu().numpy()
                keypoints = extract_skeleton_keypoints(original_img, max_points=config['max_keypoints'])

                vis_samples.append({
                    'original': original_img,
                    'keypoints': keypoints,
                    'augmented': aug_img,
                    'flow': flow_vis,  # 使用处理后的可视化flow
                    'filename': filename,
                    'label': label,
                    'pred': metrics.get('pred', -1),
                    'accepted': accepted
                })

    # 保存指标 CSV
    metrics_path = output_dir / f'{split}_metrics.csv'
    with open(metrics_path, 'w', newline='') as f:
        if all_metrics:
            writer = csv.DictWriter(f, fieldnames=all_metrics[0].keys())
            writer.writeheader()
            writer.writerows(all_metrics)
    print(f'Metrics saved to {metrics_path}')

    # 保存 trial-level CSV
    if all_trial_metrics:
        trial_csv_path = output_dir / f'{split}_trial_metrics.csv'
        with open(trial_csv_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=all_trial_metrics[0].keys())
            writer.writeheader()
            writer.writerows(all_trial_metrics)
        print(f'Trial metrics saved to {trial_csv_path}')

    # 保存可视化
    if vis_samples:
        num_cols = 5
        num_rows = len(vis_samples)

        fig, axes = plt.subplots(num_rows, num_cols, figsize=(25, 5 * num_rows))
        if num_rows == 1:
            axes = axes.reshape(1, -1)

        for i, sample in enumerate(vis_samples):
            # 判断是否被拒绝（Pred != Label）
            is_rejected = sample['pred'] != sample['label']
            
            # 原始图
            axes[i, 0].imshow(sample['original'], cmap='gray')
            axes[i, 0].set_title(f'{sample["filename"]}\nLabel: {sample["label"]}')
            axes[i, 0].axis('off')

            # 骨架和关键点
            skeleton_vis = visualize_skeleton_with_keypoints(sample['original'], sample['keypoints'])
            axes[i, 1].imshow(skeleton_vis)
            axes[i, 1].set_title('Skeleton + Keypoints')
            axes[i, 1].axis('off')

            # 增强后的图像
            axes[i, 2].imshow(sample['augmented'], cmap='gray')
            # 如果 Pred != Label，标注 REJECTED
            if is_rejected:
                axes[i, 2].set_title(f'Augmented\nPred: {sample["pred"]}\n\033[91mREJECTED\033[0m')
                # 在图像上添加红色边框表示拒绝
                axes[i, 2].add_patch(plt.Rectangle((0, 0), sample['augmented'].shape[1], 
                                                  sample['augmented'].shape[0], 
                                                  fill=False, edgecolor='red', linewidth=3))
            else:
                axes[i, 2].set_title(f'Augmented\nPred: {sample["pred"]}')
            axes[i, 2].axis('off')

            # 差异图
            diff = np.abs(sample['augmented'] - sample['original'])
            axes[i, 3].imshow(diff, cmap='gray')
            axes[i, 3].set_title(f'Diff')
            axes[i, 3].axis('off')

            # 光流图
            flow_display = sample['flow']
            if flow_display.ndim == 3 and flow_display.shape[2] == 3:
                axes[i, 4].imshow(flow_display)
            else:
                axes[i, 4].imshow(np.zeros_like(sample['original']), cmap='gray')
            axes[i, 4].set_title('Flow')
            axes[i, 4].axis('off')

        plt.tight_layout()
        vis_path = vis_dir / f'{split}_comparison.png'
        plt.savefig(vis_path)
        plt.close()
        print(f'Visualization saved to {vis_path}')

    # 计算接受率
    acceptance_rate = acceptance_count / total_count if total_count > 0 else 0

    # 打印统计
    print('\n' + '=' * 60)
    print(f'MHOA-lite Generation Summary for {split} split')
    print('=' * 60)
    print(f"Total samples: {total_count}")
    print(f"Accepted samples: {acceptance_count}")
    print(f"Acceptance rate: {acceptance_rate:.4f}")
    print('=' * 60)

    # 提示信息
    if acceptance_rate < 0.5:
        print('\n⚠️  WARNING: Acceptance rate is low (< 0.5).')
        print('  Consider:')
        print('    - Increasing max_fg_diff')
        print('    - Increasing max_endpoint_diff / max_branchpoint_diff')
        print('    - Decreasing max_disp')


if __name__ == '__main__':
    main()