import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from perturbations.warp import warp_image
from perturbations.rbf_warp import rbf_interpolate_flow, generate_keypoint_displacements
from perturbations.keypoint_utils import extract_skeleton_keypoints
import numpy as np
import matplotlib.pyplot as plt
import csv

def create_horizontal_flow(batch_size, H, W, dx, device):
    """创建固定水平平移 flow"""
    flow = torch.zeros(batch_size, 2, H, W, device=device)
    flow[:, 0, :, :] = dx  # x方向位移
    return flow

def create_vertical_flow(batch_size, H, W, dy, device):
    """创建固定垂直平移 flow"""
    flow = torch.zeros(batch_size, 2, H, W, device=device)
    flow[:, 1, :, :] = dy  # y方向位移
    return flow

def compute_flow_stats(flow):
    """计算 flow 统计信息"""
    dx = flow[:, 0]
    dy = flow[:, 1]
    mag = torch.sqrt(dx**2 + dy**2)
    
    return {
        'flow_min': mag.min().item(),
        'flow_max': mag.max().item(),
        'flow_mean': mag.mean().item(),
        'flow_abs_mean': mag.abs().mean().item()
    }

def compute_image_metrics(original, warped_continuous, warped_binary):
    """计算图像指标"""
    continuous_diff = warped_continuous - original
    continuous_l1 = torch.norm(continuous_diff, p=1).item()
    continuous_l2 = torch.norm(continuous_diff, p=2).item()
    
    diff_binary = torch.abs(warped_binary - original)
    changed_pixel_ratio = diff_binary.mean().item()
    
    orig_fg = original.mean().item()
    aug_fg = warped_binary.mean().item()
    fg_diff = abs(orig_fg - aug_fg)
    
    return {
        'continuous_l1': continuous_l1,
        'continuous_l2': continuous_l2,
        'binary_changed_pixel_ratio': changed_pixel_ratio,
        'orig_fg': orig_fg,
        'aug_fg': aug_fg,
        'fg_diff': fg_diff
    }

def main():
    parser = argparse.ArgumentParser(description='Debug MHOA warp functionality')
    parser.add_argument('--config', type=str, default='../configs/mhoa_aug.yaml',
                        help='Path to config file')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)
    
    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    
    # 构建数据分割
    train_samples, _, _ = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )
    
    # 取前5张图
    test_samples = train_samples[:5]
    
    # 创建数据集
    dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=test_samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )
    
    # 创建数据加载器
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    
    # 创建输出目录
    output_dir = Path('./outputs/mhoa_debug')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 测试的 flow 类型
    flow_types = [
        {'name': 'horizontal_dx5', 'type': 'horizontal', 'dx': 5, 'dy': 0},
        {'name': 'vertical_dy5', 'type': 'vertical', 'dx': 0, 'dy': 5},
        {'name': 'mhoa_rbf', 'type': 'rbf', 'dx': 0, 'dy': 0}
    ]
    
    # 存储所有指标
    all_metrics = []
    
    # 收集可视化数据
    vis_data = []
    
    for images, labels, filenames in dataloader:
        images = images.to(device)
        filename = filenames[0]
        
        for flow_info in flow_types:
            H, W = images.shape[2], images.shape[3]
            
            # 创建 flow
            if flow_info['type'] == 'horizontal':
                flow = create_horizontal_flow(1, H, W, flow_info['dx'], device)
            elif flow_info['type'] == 'vertical':
                flow = create_vertical_flow(1, H, W, flow_info['dy'], device)
            else:  # rbf
                # 提取关键点并生成 RBF flow
                img_np = images[0].squeeze().cpu().numpy()
                keypoints = extract_skeleton_keypoints(img_np, max_points=config['max_keypoints'])
                
                if len(keypoints) > 0:
                    displacements = generate_keypoint_displacements(
                        keypoints,
                        max_disp=config['max_disp'],
                        mode=config.get('disp_mode', 'random'),
                        seed=None
                    )
                    flow = rbf_interpolate_flow(
                        keypoints,
                        displacements,
                        H, W,
                        sigma=config['rbf_sigma'],
                        device=device
                    )
                else:
                    flow = torch.zeros(1, 2, H, W, device=device)
            
            # 计算 flow 统计
            flow_stats = compute_flow_stats(flow)
            
            # Warp 图像
            warped_continuous = warp_image(images, flow)
            
            # 二值化
            warped_binary = (warped_continuous > config['binary_threshold']).float()
            
            # 计算图像指标
            img_metrics = compute_image_metrics(images, warped_continuous, warped_binary)
            
            # 收集指标
            metrics = {
                'filename': filename,
                'flow_type': flow_info['name'],
                **flow_stats,
                **img_metrics
            }
            all_metrics.append(metrics)
            
            # 收集可视化数据
            vis_data.append({
                'filename': filename,
                'flow_type': flow_info['name'],
                'original': images[0].squeeze().cpu().numpy(),
                'flow': flow[0].cpu().numpy(),
                'warped_continuous': warped_continuous[0].squeeze().cpu().numpy(),
                'warped_binary': warped_binary[0].squeeze().cpu().numpy(),
                'changed_pixel_ratio': img_metrics['binary_changed_pixel_ratio']
            })
            
            print(f'File: {filename}, Flow: {flow_info["name"]}')
            print(f'  Flow stats: min={flow_stats["flow_min"]:.4f}, max={flow_stats["flow_max"]:.4f}, mean={flow_stats["flow_mean"]:.4f}')
            print(f'  Changed pixel ratio: {img_metrics["binary_changed_pixel_ratio"]:.4f}')
            print()
    
    # 保存指标 CSV
    metrics_path = output_dir / 'warp_debug_metrics.csv'
    with open(metrics_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=all_metrics[0].keys())
        writer.writeheader()
        writer.writerows(all_metrics)
    print(f'Metrics saved to {metrics_path}')
    
    # 生成可视化
    num_samples = len(test_samples)
    num_flow_types = len(flow_types)
    num_cols = 6  # original, flow_x, flow_y, continuous, binary, diff
    num_rows = num_samples * num_flow_types
    
    fig, axes = plt.subplots(num_rows, num_cols, figsize=(24, 4 * num_rows))
    
    idx = 0
    for sample_idx in range(num_samples):
        for flow_idx, flow_info in enumerate(flow_types):
            data = vis_data[idx]
            
            # 原始图
            axes[idx, 0].imshow(data['original'], cmap='gray')
            axes[idx, 0].set_title(f'{data["filename"]}\n{data["flow_type"]}')
            axes[idx, 0].axis('off')
            
            # flow_x
            axes[idx, 1].imshow(data['flow'][0], cmap='coolwarm', vmin=-5, vmax=5)
            axes[idx, 1].set_title('flow_x')
            axes[idx, 1].axis('off')
            
            # flow_y
            axes[idx, 2].imshow(data['flow'][1], cmap='coolwarm', vmin=-5, vmax=5)
            axes[idx, 2].set_title('flow_y')
            axes[idx, 2].axis('off')
            
            # warped continuous
            axes[idx, 3].imshow(data['warped_continuous'], cmap='gray')
            axes[idx, 3].set_title('continuous')
            axes[idx, 3].axis('off')
            
            # warped binary
            axes[idx, 4].imshow(data['warped_binary'], cmap='gray')
            axes[idx, 4].set_title(f'binary\nratio={data["changed_pixel_ratio"]:.4f}')
            axes[idx, 4].axis('off')
            
            # diff
            diff = np.abs(data['warped_binary'] - data['original'])
            axes[idx, 5].imshow(diff, cmap='gray')
            axes[idx, 5].set_title('diff')
            axes[idx, 5].axis('off')
            
            idx += 1
    
    plt.tight_layout()
    vis_path = output_dir / 'warp_debug.png'
    plt.savefig(vis_path)
    plt.close()
    print(f'Visualization saved to {vis_path}')
    
    # 分析结果
    print('\n' + '='*60)
    print('Warp Debug Analysis')
    print('='*60)
    
    for flow_info in flow_types:
        flow_metrics = [m for m in all_metrics if m['flow_type'] == flow_info['name']]
        avg_changed_ratio = np.mean([m['binary_changed_pixel_ratio'] for m in flow_metrics])
        avg_flow_mean = np.mean([m['flow_abs_mean'] for m in flow_metrics])
        
        print(f"{flow_info['name']}:")
        print(f"  Average changed pixel ratio: {avg_changed_ratio:.4f}")
        print(f"  Average flow magnitude: {avg_flow_mean:.4f}")
        
        if flow_info['type'] in ['horizontal', 'vertical']:
            if avg_changed_ratio > 0.001:
                print(f"  ✓ Fixed translation works correctly")
            else:
                print(f"  ✗ ERROR: Fixed translation should produce changes!")
        else:
            if avg_changed_ratio > 0.001:
                print(f"  ✓ RBF flow produces changes")
            else:
                print(f"  ✗ RBF flow produces no changes")
                print(f"    Suggestion: Check RBF interpolation or increase max_disp")
    
    print('='*60)

if __name__ == '__main__':
    main()