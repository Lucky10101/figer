import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
from perturbations.fgsm_label_preserving import generate_fgsm_label_preserving, generate_gradient_bitflip_label_preserving
from metrics.perturbation_metrics import compute_continuous_metrics, compute_binary_metrics
import numpy as np
import matplotlib.pyplot as plt
import csv
from PIL import Image

# 设置随机种子
def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Generate FGSM label-preserving perturbations')
    parser.add_argument('--config', type=str, default='../configs/fgsm_aug.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default=None,
                        help='Split to generate perturbations for')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 如果命令行指定了 split，则覆盖配置文件中的值
    if args.split is not None:
        config['split'] = args.split
    
    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)
    
    # 设置随机种子
    set_seed(config['seed'])
    
    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')
    
    # 获取模式
    mode = config.get('mode', 'binary_bitflip')
    print(f'Using mode: {mode}')
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )
    
    # 选择要处理的分割
    split = config['split']
    if split == 'train':
        samples = train_samples
    elif split == 'val':
        samples = val_samples
    else:  # test
        samples = test_samples
    
    print(f'Processing {split} split with {len(samples)} samples')
    
    # 创建数据集
    dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )
    
    # 创建数据加载器
    dataloader = DataLoader(
        dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )
    
    # 创建模型
    model = create_resnet18_binary(
        num_classes=baseline_config['num_classes'],
        dropout=baseline_config.get('dropout', 0.5)
    )
    
    # 加载模型权重
    checkpoint_path = Path(config['checkpoint'])
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {config['checkpoint']} does not exist")
    
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # 兼容不同格式的 checkpoint
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)
    
    # 固定模型参数
    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    
    model = model.to(device)
    
    # 创建输出目录
    output_dir = Path(config['output_dir'])
    continuous_dir = output_dir / split / 'continuous'
    binary_dir = output_dir / split / 'binary'
    vis_dir = output_dir / 'vis'
    
    continuous_dir.mkdir(parents=True, exist_ok=True)
    binary_dir.mkdir(parents=True, exist_ok=True)
    vis_dir.mkdir(parents=True, exist_ok=True)
    
    # 存储所有图像的指标
    all_metrics = []
    
    # 收集用于可视化的样本
    vis_samples = []
    
    # 用于计算总体指标
    total_cls_loss = 0
    total_grad_abs_mean = 0
    total_grad_abs_max = 0
    total_continuous_l2 = 0
    total_continuous_l1 = 0
    total_continuous_changed_ratio = 0
    total_num_flipped_pixels = 0
    total_actual_bitflip_ratio = 0
    total_binary_l2 = 0
    total_binary_l1 = 0
    total_changed_pixel_ratio = 0
    total_original_foreground = 0
    total_adv_foreground = 0
    total_keep_correct = 0
    total_samples_count = 0
    
    # 处理每个 batch
    for batch_idx, (images, labels, filenames) in enumerate(dataloader):
        print(f'Processing batch {batch_idx + 1}/{len(dataloader)}')
        
        images = images.to(device)
        labels = labels.to(device)
        
        # 根据模式生成扰动
        if mode == 'continuous_fgsm':
            # 连续 FGSM 模式
            adv_continuous, adv_binary, loss_dict = generate_fgsm_label_preserving(
                model=model,
                images=images,
                labels=labels,
                epsilon=config['epsilon'],
                lambda_distance=config.get('lambda_distance', 0.0),
                binary_threshold=config['binary_threshold'],
                device=device
            )
            
            # 计算连续指标
            continuous_metrics = compute_continuous_metrics(model, images, adv_continuous, labels)
            
            # 计算二值指标
            binary_metrics = compute_binary_metrics(model, images, adv_binary, labels)
            
        elif mode == 'binary_bitflip':
            # 二值 bitflip 模式
            adv_binary, loss_dict = generate_gradient_bitflip_label_preserving(
                model=model,
                images=images,
                labels=labels,
                bitflip_ratio=config.get('bitflip_ratio', 0.01),
                binary_threshold=config['binary_threshold'],
                flip_foreground=config.get('flip_foreground', True),
                flip_background=config.get('flip_background', True),
                device=device
            )
            
            # 连续扰动图设为 None（此模式不生成连续扰动）
            adv_continuous = None
            
            # 计算二值指标
            binary_metrics = compute_binary_metrics(model, images, adv_binary, labels)
            
            # 连续指标设为 0
            continuous_metrics = {
                'continuous_l2': 0.0,
                'continuous_l1': 0.0,
                'continuous_abs_diff_mean': 0.0,
                'continuous_foreground_ratio': 0.0
            }
        else:
            raise ValueError(f"Unknown mode: {mode}")
        
        # 获取预测结果
        with torch.no_grad():
            original_logits = model(images)
            adv_logits = model(adv_binary)
        
        original_preds = original_logits.argmax(dim=1)
        adv_preds = adv_logits.argmax(dim=1)
        
        # 处理每张图像
        for i in range(len(filenames)):
            filename = filenames[i]
            label = labels[i].item()
            original_pred = original_preds[i].item()
            adv_pred = adv_preds[i].item()
            keep_correct = int((original_pred == label) and (adv_pred == label))
            
            # 保存连续扰动图（如果模式支持且配置允许）
            if mode == 'continuous_fgsm' and config.get('save_continuous', True):
                continuous_img = adv_continuous[i].squeeze().cpu().numpy() * 255
                continuous_img = continuous_img.astype(np.uint8)
                continuous_pil = Image.fromarray(continuous_img).convert('L')
                continuous_pil.save(continuous_dir / filename)
            
            # 保存二值扰动图（如果配置允许）
            if config.get('save_binary', True):
                binary_img = adv_binary[i].squeeze().cpu().numpy() * 255
                binary_img = binary_img.astype(np.uint8)
                binary_pil = Image.fromarray(binary_img).convert('L')
                binary_pil.save(binary_dir / filename)
            
            # 计算单个样本的二值指标
            l2_dist = torch.norm(adv_binary[i] - images[i], p=2).item()
            l1_dist = torch.norm(adv_binary[i] - images[i], p=1).item()
            changed_ratio = torch.abs(adv_binary[i] - images[i]).mean().item()
            original_fg = images[i].mean().item()
            adv_fg = adv_binary[i].mean().item()
            
            # 记录指标
            all_metrics.append({
                'mode': mode,
                'filename': filename,
                'label': label,
                'original_pred': original_pred,
                'adv_pred': adv_pred,
                'keep_correct': keep_correct,
                'cls_loss': loss_dict.get('cls_loss', 0.0),
                'grad_abs_mean': loss_dict.get('grad_abs_mean', 0.0),
                'grad_abs_max': loss_dict.get('grad_abs_max', 0.0),
                'continuous_l2': loss_dict.get('continuous_l2', 0.0),
                'continuous_l1': loss_dict.get('continuous_l1', 0.0),
                'continuous_changed_ratio': loss_dict.get('continuous_changed_ratio', 0.0),
                'num_flipped_pixels': loss_dict.get('num_flipped_pixels', 0),
                'actual_bitflip_ratio': loss_dict.get('actual_bitflip_ratio', 0.0),
                'binary_l2': l2_dist,
                'binary_l1': l1_dist,
                'changed_pixel_ratio': changed_ratio,
                'original_foreground_ratio': original_fg,
                'adv_foreground_ratio': adv_fg
            })
            
            # 累计总体指标
            total_cls_loss += loss_dict.get('cls_loss', 0.0)
            total_grad_abs_mean += loss_dict.get('grad_abs_mean', 0.0)
            total_grad_abs_max += loss_dict.get('grad_abs_max', 0.0)
            total_continuous_l2 += loss_dict.get('continuous_l2', 0.0)
            total_continuous_l1 += loss_dict.get('continuous_l1', 0.0)
            total_continuous_changed_ratio += loss_dict.get('continuous_changed_ratio', 0.0)
            total_num_flipped_pixels += loss_dict.get('num_flipped_pixels', 0)
            total_actual_bitflip_ratio += loss_dict.get('actual_bitflip_ratio', 0.0)
            total_binary_l2 += l2_dist
            total_binary_l1 += l1_dist
            total_changed_pixel_ratio += changed_ratio
            total_original_foreground += original_fg
            total_adv_foreground += adv_fg
            total_keep_correct += keep_correct
            total_samples_count += 1
            
            # 收集可视化样本（每20张收集一张）
            if len(vis_samples) < 10 and batch_idx * config['batch_size'] + i < len(samples):
                vis_samples.append({
                    'original': images[i].squeeze().cpu().numpy(),
                    'continuous': adv_continuous[i].squeeze().cpu().numpy() if adv_continuous is not None else None,
                    'binary': adv_binary[i].squeeze().cpu().numpy(),
                    'filename': filename,
                    'label': label,
                    'original_pred': original_pred,
                    'adv_pred': adv_pred,
                    'changed_pixel_ratio': changed_ratio
                })
    
    # 保存指标 CSV
    metrics_path = output_dir / f'{split}_metrics.csv'
    with open(metrics_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=all_metrics[0].keys())
        writer.writeheader()
        writer.writerows(all_metrics)
    print(f'Metrics saved to {metrics_path}')
    
    # 保存可视化对比图
    if vis_samples:
        num_samples = len(vis_samples)
        num_cols = 4 if mode == 'continuous_fgsm' else 3
        num_rows = num_samples
        
        fig, axes = plt.subplots(num_rows, num_cols, figsize=(16, 4 * num_rows))
        
        for i, sample in enumerate(vis_samples):
            # 原始图
            axes[i, 0].imshow(sample['original'], cmap='gray')
            axes[i, 0].set_title(f'{sample["filename"]}\nLabel: {sample["label"]}')
            axes[i, 0].axis('off')
            
            if mode == 'continuous_fgsm':
                # 连续扰动图
                axes[i, 1].imshow(sample['continuous'], cmap='gray')
                axes[i, 1].set_title('Continuous')
                axes[i, 1].axis('off')
                
                # 二值扰动图
                axes[i, 2].imshow(sample['binary'], cmap='gray')
                axes[i, 2].set_title(f'Binary\nPred: {sample["adv_pred"]}')
                axes[i, 2].axis('off')
                
                # 差异图
                diff = np.abs(sample['binary'] - sample['original'])
                axes[i, 3].imshow(diff, cmap='gray')
                axes[i, 3].set_title(f'Diff: {sample["changed_pixel_ratio"]:.4f}')
                axes[i, 3].axis('off')
            else:
                # 二值扰动图
                axes[i, 1].imshow(sample['binary'], cmap='gray')
                axes[i, 1].set_title(f'Binary\nPred: {sample["adv_pred"]}')
                axes[i, 1].axis('off')
                
                # 差异图
                diff = np.abs(sample['binary'] - sample['original'])
                axes[i, 2].imshow(diff, cmap='gray')
                axes[i, 2].set_title(f'Diff: {sample["changed_pixel_ratio"]:.4f}')
                axes[i, 2].axis('off')
        
        plt.tight_layout()
        vis_path = vis_dir / f'{split}_comparison.png'
        plt.savefig(vis_path)
        plt.close()
        print(f'Visualization saved to {vis_path}')
    
    # 计算平均指标
    avg_metrics = {}
    if total_samples_count > 0:
        avg_metrics['cls_loss'] = total_cls_loss / total_samples_count
        avg_metrics['grad_abs_mean'] = total_grad_abs_mean / total_samples_count
        avg_metrics['grad_abs_max'] = total_grad_abs_max / total_samples_count
        avg_metrics['continuous_l2'] = total_continuous_l2 / total_samples_count
        avg_metrics['continuous_l1'] = total_continuous_l1 / total_samples_count
        avg_metrics['continuous_changed_ratio'] = total_continuous_changed_ratio / total_samples_count
        avg_metrics['avg_num_flipped_pixels'] = total_num_flipped_pixels / total_samples_count
        avg_metrics['avg_actual_bitflip_ratio'] = total_actual_bitflip_ratio / total_samples_count
        avg_metrics['binary_l2'] = total_binary_l2 / total_samples_count
        avg_metrics['binary_l1'] = total_binary_l1 / total_samples_count
        avg_metrics['changed_pixel_ratio'] = total_changed_pixel_ratio / total_samples_count
        avg_metrics['original_foreground_ratio'] = total_original_foreground / total_samples_count
        avg_metrics['adv_foreground_ratio'] = total_adv_foreground / total_samples_count
        avg_metrics['keep_correct_rate'] = total_keep_correct / total_samples_count
    
    # 打印平均指标
    print('\n' + '='*60)
    print(f'Average Metrics for {split} split (mode: {mode})')
    print('='*60)
    print(f"Classification Loss: {avg_metrics.get('cls_loss', 0):.4f}")
    print(f"Gradient Abs Mean: {avg_metrics.get('grad_abs_mean', 0):.6f}")
    print(f"Gradient Abs Max: {avg_metrics.get('grad_abs_max', 0):.6f}")
    
    if mode == 'continuous_fgsm':
        print(f"Continuous L2 Distance: {avg_metrics.get('continuous_l2', 0):.4f}")
        print(f"Continuous L1 Distance: {avg_metrics.get('continuous_l1', 0):.4f}")
        print(f"Continuous Changed Ratio: {avg_metrics.get('continuous_changed_ratio', 0):.4f}")
        print(f"Binary Changed Pixel Ratio: {avg_metrics.get('changed_pixel_ratio', 0):.4f}")
        print('\n⚠️  Note: For continuous_fgsm mode, binary image may have 0 changes')
        print('  because small continuous perturbations may not cross the threshold.')
    
    elif mode == 'binary_bitflip':
        print(f"Number of Flipped Pixels: {avg_metrics.get('avg_num_flipped_pixels', 0):.1f}")
        print(f"Actual Bitflip Ratio: {avg_metrics.get('avg_actual_bitflip_ratio', 0):.4f}")
        print(f"Binary L2 Distance: {avg_metrics.get('binary_l2', 0):.4f}")
        print(f"Binary L1 Distance: {avg_metrics.get('binary_l1', 0):.4f}")
        print(f"Changed Pixel Ratio: {avg_metrics.get('changed_pixel_ratio', 0):.4f}")
    
    print(f"Original Foreground Ratio: {avg_metrics.get('original_foreground_ratio', 0):.4f}")
    print(f"Adversarial Foreground Ratio: {avg_metrics.get('adv_foreground_ratio', 0):.4f}")
    print(f"Keep Correct Rate: {avg_metrics.get('keep_correct_rate', 0):.4f}")
    print('='*60)
    
    # 提示信息
    if avg_metrics.get('keep_correct_rate', 0) < 0.9:
        print('\n⚠️  WARNING: Keep correct rate is low (< 0.9).')
        if mode == 'binary_bitflip':
            print(f'  Consider reducing bitflip_ratio from {config.get("bitflip_ratio", 0.01)}.')
        else:
            print(f'  Consider reducing epsilon from {config.get("epsilon", 0.03)}.')
    
    if mode == 'binary_bitflip':
        if avg_metrics.get('changed_pixel_ratio', 0) < 0.001:
            print('\n⚠️  WARNING: Changed pixel ratio is very low (< 0.001).')
            print(f'  Consider increasing bitflip_ratio from {config.get("bitflip_ratio", 0.01)}.')

if __name__ == '__main__':
    main()