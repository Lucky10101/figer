import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
from metrics.perturbation_metrics import compute_perturbation_metrics
import numpy as np
import csv
from PIL import Image

# 设置随机种子
def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

# 加载二值扰动图像
def load_adv_binary_images(samples, adv_dir, image_size=224):
    adv_images = []
    for sample in samples:
        filename = sample['filename']
        adv_path = adv_dir / filename
        
        # 读取图像
        image = Image.open(adv_path).convert('L')
        image = image.resize((image_size, image_size))
        image_np = np.array(image, dtype=np.float32) / 255.0
        image_tensor = torch.tensor(image_np).unsqueeze(0)  # [1, H, W]
        adv_images.append(image_tensor)
    
    return torch.stack(adv_images)

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Evaluate FGSM augmented images')
    parser.add_argument('--config', type=str, default='../configs/fgsm_aug.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default=None,
                        help='Split to evaluate')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 如果命令行指定了 split，则覆盖配置文件中的值
    if args.split is not None:
        config['split'] = args.split
    
    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)
    
    # 设置随机种子
    set_seed(config['seed'])
    
    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )
    
    # 选择要评估的分割
    split = config['split']
    if split == 'train':
        samples = train_samples
    elif split == 'val':
        samples = val_samples
    else:  # test
        samples = test_samples
    
    print(f'Evaluating {split} split with {len(samples)} samples')
    
    # 创建原始数据集
    original_dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )
    
    # 创建数据加载器
    original_loader = DataLoader(
        original_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers']
    )
    
    # 创建模型
    model = create_resnet18_binary(
        num_classes=baseline_config['num_classes'],
        dropout=baseline_config.get('dropout', 0.5)
    )
    
    # 加载模型权重
    checkpoint_path = Path(config['checkpoint'])
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {config['checkpoint']} does not exist")
    
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # 兼容不同格式的 checkpoint
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)
    
    # 设置模型为 eval 模式
    model.eval()
    model = model.to(device)
    
    # 检查扰动图像目录是否存在
    output_dir = Path(config['output_dir'])
    binary_dir = output_dir / split / 'binary'
    
    if not binary_dir.exists():
        raise FileNotFoundError(f"Adversarial binary images directory not found: {binary_dir}")
    
    # 加载扰动图像
    print('Loading adversarial images...')
    adv_binary_images = load_adv_binary_images(
        samples, 
        binary_dir, 
        image_size=baseline_config['image_size']
    )
    
    # 存储所有图像的评估结果
    all_results = []
    
    # 用于计算总体指标
    total_original_correct = 0
    total_adv_correct = 0
    total_keep_correct = 0
    total_l2_distance = 0
    total_l1_distance = 0
    total_changed_pixel_ratio = 0
    total_original_foreground = 0
    total_adv_foreground = 0
    total_samples = 0
    
    # 处理每个 batch
    for batch_idx, (original_images, labels, filenames) in enumerate(original_loader):
        print(f'Processing batch {batch_idx + 1}/{len(original_loader)}')
        
        original_images = original_images.to(device)
        labels = labels.to(device)
        
        # 获取对应的扰动图像
        start_idx = batch_idx * config['batch_size']
        end_idx = start_idx + len(filenames)
        adv_images = adv_binary_images[start_idx:end_idx].to(device)
        
        # 计算扰动指标
        metrics = compute_perturbation_metrics(model, original_images, adv_images, labels)
        
        # 获取预测结果
        with torch.no_grad():
            original_logits = model(original_images)
            adv_logits = model(adv_images)
        
        original_preds = original_logits.argmax(dim=1)
        adv_preds = adv_logits.argmax(dim=1)
        
        # 处理每张图像
        for i in range(len(filenames)):
            filename = filenames[i]
            label = labels[i].item()
            original_pred = original_preds[i].item()
            adv_pred = adv_preds[i].item()
            original_correct = int(original_pred == label)
            adv_correct = int(adv_pred == label)
            keep_correct = int(original_correct and adv_correct)
            
            # 计算单个样本的指标
            l2_dist = torch.norm(adv_images[i] - original_images[i], p=2).item()
            l1_dist = torch.norm(adv_images[i] - original_images[i], p=1).item()
            changed_ratio = torch.abs(adv_images[i] - original_images[i]).mean().item()
            original_fg = original_images[i].mean().item()
            adv_fg = adv_images[i].mean().item()
            
            # 记录结果
            all_results.append({
                'filename': filename,
                'label': label,
                'original_pred': original_pred,
                'original_correct': original_correct,
                'adv_pred': adv_pred,
                'adv_correct': adv_correct,
                'keep_correct': keep_correct,
                'l2_distance': l2_dist,
                'l1_distance': l1_dist,
                'changed_pixel_ratio': changed_ratio,
                'original_foreground_ratio': original_fg,
                'adv_foreground_ratio': adv_fg,
                'foreground_ratio_diff': adv_fg - original_fg
            })
            
            # 累计总体指标
            total_original_correct += original_correct
            total_adv_correct += adv_correct
            total_keep_correct += keep_correct
            total_l2_distance += l2_dist
            total_l1_distance += l1_dist
            total_changed_pixel_ratio += changed_ratio
            total_original_foreground += original_fg
            total_adv_foreground += adv_fg
            total_samples += 1
    
    # 计算总体指标
    overall_metrics = {
        'original_acc': total_original_correct / total_samples,
        'adv_acc': total_adv_correct / total_samples,
        'keep_rate': total_keep_correct / total_samples if total_original_correct > 0 else 0,
        'avg_l2_distance': total_l2_distance / total_samples,
        'avg_l1_distance': total_l1_distance / total_samples,
        'avg_changed_pixel_ratio': total_changed_pixel_ratio / total_samples,
        'avg_original_foreground': total_original_foreground / total_samples,
        'avg_adv_foreground': total_adv_foreground / total_samples,
        'avg_foreground_diff': (total_adv_foreground - total_original_foreground) / total_samples
    }
    
    # 保存评估结果
    eval_path = output_dir / f'evaluate_{split}.csv'
    with open(eval_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
        writer.writeheader()
        writer.writerows(all_results)
    print(f'Evaluation results saved to {eval_path}')
    
    # 打印总体指标
    print('\n' + '='*60)
    print(f'Overall Evaluation Metrics for {split} split:')
    print('='*60)
    print(f"Original Accuracy: {overall_metrics['original_acc']:.4f}")
    print(f"Adversarial Accuracy: {overall_metrics['adv_acc']:.4f}")
    print(f"Keep Rate: {overall_metrics['keep_rate']:.4f}")
    print(f"Average L2 Distance: {overall_metrics['avg_l2_distance']:.4f}")
    print(f"Average L1 Distance: {overall_metrics['avg_l1_distance']:.4f}")
    print(f"Average Changed Pixel Ratio: {overall_metrics['avg_changed_pixel_ratio']:.4f}")
    print(f"Average Original Foreground: {overall_metrics['avg_original_foreground']:.4f}")
    print(f"Average Adversarial Foreground: {overall_metrics['avg_adv_foreground']:.4f}")
    print(f"Average Foreground Diff: {overall_metrics['avg_foreground_diff']:.4f}")
    print('='*60)
    
    # 提示信息
    if overall_metrics['keep_rate'] < 0.8:
        print('\n⚠️  WARNING: Keep rate is low (< 0.8).')
        print('  Consider reducing epsilon value in fgsm_aug.yaml.')
    
    if overall_metrics['avg_changed_pixel_ratio'] < 0.01:
        print('\n⚠️  WARNING: Average changed pixel ratio is very low (< 0.01).')
        print('  Consider increasing epsilon value in fgsm_aug.yaml.')

if __name__ == '__main__':
    main()