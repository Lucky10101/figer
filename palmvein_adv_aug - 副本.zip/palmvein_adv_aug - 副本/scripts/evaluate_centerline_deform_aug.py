import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import csv
import numpy as np

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Evaluate centerline deform augmentation')
    parser.add_argument('--config', type=str, default='../configs/centerline_deform.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default='train',
                        help='Split to evaluate')
    args = parser.parse_args()

    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 输出目录
    output_dir = Path(config['output_dir'])
    metrics_path = output_dir / f'{args.split}_metrics.csv'

    if not metrics_path.exists():
        raise FileNotFoundError(f"Metrics file not found: {metrics_path}")

    # 读取 metrics
    metrics = []
    with open(metrics_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            metrics.append(row)

    if not metrics:
        print("No metrics found!")
        return

    # 计算统计
    total_count = len(metrics)
    # Updated to handle boolean-like strings for 'accepted'
    accepted_count = sum(1 for m in metrics if m.get('accepted', '0') in ['1', 'True'])
    keep_correct_count = sum(1 for m in metrics if int(m.get('keep_correct', '0')) == 1)

    acceptance_rate = accepted_count / total_count if total_count > 0 else 0
    keep_rate = keep_correct_count / total_count if total_count > 0 else 0

    # 计算平均值
    def safe_float(val, default=0.0):
        try:
            return float(val)
        except:
            return default

    changed_pixel_ratios = [safe_float(m.get('changed_pixel_ratio', 0)) for m in metrics]
    fg_diffs = [safe_float(m.get('fg_diff', 0)) for m in metrics]
    flow_global_abs_means = [safe_float(m.get('flow_global_abs_mean', 0)) for m in metrics]
    flow_local_abs_means = [safe_float(m.get('flow_local_abs_mean', 0)) for m in metrics]
    local_flow_reduction_ratios = [safe_float(m.get('local_flow_reduction_ratio', 0)) for m in metrics]
    endpoint_diffs = [safe_float(m.get('endpoint_diff', 0)) for m in metrics]
    branchpoint_diffs = [safe_float(m.get('branchpoint_diff', 0)) for m in metrics]
    component_diffs = [safe_float(m.get('component_diff', 0)) for m in metrics]

    mean_changed_pixel_ratio = np.mean(changed_pixel_ratios)
    mean_fg_diff = np.mean(fg_diffs)
    mean_flow_global_abs_mean = np.mean(flow_global_abs_means)
    mean_flow_local_abs_mean = np.mean(flow_local_abs_means)
    mean_local_flow_reduction_ratio = np.mean(local_flow_reduction_ratios)
    mean_endpoint_diff = np.mean(endpoint_diffs)
    mean_branchpoint_diff = np.mean(branchpoint_diffs)
    mean_component_diff = np.mean(component_diffs)

    # 打印结果
    print('\n' + '=' * 60)
    print(f'Centerline Local Deform Evaluation Summary for {args.split} split')
    print('=' * 60)
    print(f"Total samples: {total_count}")
    print(f"Accepted samples: {accepted_count}")
    print(f"Acceptance rate: {acceptance_rate:.4f}")
    print(f"Keep correct rate: {keep_rate:.4f}")
    print()
    print("Metrics:")
    print(f"  Mean changed_pixel_ratio: {mean_changed_pixel_ratio:.6f}")
    print(f"  Mean fg_diff: {mean_fg_diff:.6f}")
    print(f"  Mean flow_global_abs_mean: {mean_flow_global_abs_mean:.4f}")
    print(f"  Mean flow_local_abs_mean: {mean_flow_local_abs_mean:.4f}")
    print(f"  Mean local_flow_reduction_ratio: {mean_local_flow_reduction_ratio:.4f}")
    print(f"  Mean endpoint_diff: {mean_endpoint_diff:.2f}")
    print(f"  Mean branchpoint_diff: {mean_branchpoint_diff:.2f}")
    print(f"  Mean component_diff: {mean_component_diff:.2f}")
    print('=' * 60)

    # 保存汇总
    summary = {
        'split': args.split,
        'num_samples': total_count,
        'accepted_count': accepted_count,
        'acceptance_rate': acceptance_rate,
        'keep_rate': keep_rate,
        'mean_changed_pixel_ratio': mean_changed_pixel_ratio,
        'mean_fg_diff': mean_fg_diff,
        'mean_flow_global_abs_mean': mean_flow_global_abs_mean,
        'mean_flow_local_abs_mean': mean_flow_local_abs_mean,
        'mean_local_flow_reduction_ratio': mean_local_flow_reduction_ratio,
        'mean_endpoint_diff': mean_endpoint_diff,
        'mean_branchpoint_diff': mean_branchpoint_diff,
        'mean_component_diff': mean_component_diff
    }

    summary_path = output_dir / 'evaluation_summary.csv'
    with open(summary_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=summary.keys())
        writer.writeheader()
        writer.writerow(summary)
    print(f'\nSummary saved to {summary_path}')

    # 分析拒绝原因
    reject_reasons = {}
    for m in metrics:
        reason = m.get('reject_reason', 'unknown')
        reject_reasons[reason] = reject_reasons.get(reason, 0) + 1

    print('\nReject reason distribution:')
    for reason, count in sorted(reject_reasons.items(), key=lambda x: -x[1]):
        print(f"  {reason}: {count} ({count/total_count*100:.1f}%)")

if __name__ == '__main__':
    main()