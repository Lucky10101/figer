import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
from perturbations.deformation_aug import generate_structure_preserving_aug
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import csv
from PIL import Image


# 设置随机种子
def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


# 可视化位移场
def visualize_flow(flow):
    """
    可视化位移场

    Args:
        flow: 位移场，shape [2, H, W]

    Returns:
        可视化图像，shape [H, W, 3] uint8
    """
    # 确保flow在CPU上并转换为numpy
    if isinstance(flow, torch.Tensor):
        dx = flow[0].cpu().numpy()
        dy = flow[1].cpu().numpy()
    else:
        dx = flow[0]
        dy = flow[1]

    # 计算位移幅度和方向
    magnitude = np.sqrt(dx ** 2 + dy ** 2)
    angle = np.arctan2(dy, dx)

    # 使用 RGB 编码位移场
    hsv = np.zeros((dx.shape[0], dx.shape[1], 3), dtype=np.float32)
    hsv[..., 0] = (angle + np.pi) / (2 * np.pi)  # 方向映射到 [0, 1]
    hsv[..., 1] = 1.0  # 饱和度设为1
    hsv[..., 2] = magnitude / (magnitude.max() + 1e-6) if magnitude.max() > 0 else 0  # 明度

    # 转换为 RGB（使用matplotlib的hsv colormap）
    rgb = plt.cm.hsv(hsv[..., 0])  # 使用色调通道获取颜色
    rgb = rgb[..., :3]  # 去掉alpha通道

    # 应用饱和度和明度
    rgb = rgb * hsv[..., 1:2] * hsv[..., 2:3]

    # 转换为uint8
    rgb = (rgb * 255).astype(np.uint8)

    return rgb


# 主函数
def main():
    parser = argparse.ArgumentParser(description='Generate deformation-based augmentation')
    parser.add_argument('--config', type=str, default='../configs/deform_aug.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default=None,
                        help='Split to generate perturbations for')
    args = parser.parse_args()

    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 如果命令行指定了 split，则覆盖配置文件中的值
    if args.split is not None:
        config['split'] = args.split

    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)

    # 设置随机种子
    set_seed(baseline_config['seed'])

    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU: {torch.cuda.get_device_name(0)}')

    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )

    # 选择要处理的分割
    split = config['split']
    if split == 'train':
        samples = train_samples
    elif split == 'val':
        samples = val_samples
    else:  # test
        samples = test_samples

    print(f'Processing {split} split with {len(samples)} samples')

    # 创建数据集
    dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )

    # 创建数据加载器
    dataloader = DataLoader(
        dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=0  # 为了保证确定性，关闭多进程
    )

    # 创建模型
    model = create_resnet18_binary(
        num_classes=baseline_config['num_classes'],
        dropout=baseline_config.get('dropout', 0.5)
    )

    # 加载模型权重
    checkpoint_path = Path(config['checkpoint'])
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {config['checkpoint']} does not exist")

    checkpoint = torch.load(checkpoint_path, map_location=device)

    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)

    # 固定模型参数
    model.eval()
    for p in model.parameters():
        p.requires_grad = False

    model = model.to(device)

    # 创建输出目录
    output_dir = Path(config['output_dir'])
    binary_dir = output_dir / split / 'binary'
    flow_dir = output_dir / split / 'flow'
    vis_dir = output_dir / 'vis'

    binary_dir.mkdir(parents=True, exist_ok=True)
    flow_dir.mkdir(parents=True, exist_ok=True)
    vis_dir.mkdir(parents=True, exist_ok=True)

    # 存储所有图像的指标
    all_metrics = []

    # 收集用于可视化的样本
    vis_samples = []

    # 用于计算总体指标
    total_keep_rate = 0
    total_avg_displacement = 0
    total_changed_pixel_ratio = 0
    total_orig_fg = 0
    total_aug_fg = 0
    total_fg_diff = 0
    total_samples_count = 0

    # 处理每个 batch
    for batch_idx, (images, labels, filenames) in enumerate(dataloader):
        print(f'Processing batch {batch_idx + 1}/{len(dataloader)}')

        images = images.to(device)
        labels = labels.to(device)

        # 生成形变扰动
        x_binary, flow, metrics = generate_structure_preserving_aug(
            model=model,
            images=images,
            labels=labels,
            max_displacement=config['max_displacement'],
            smooth_sigma=config['smooth_sigma'],
            binary_threshold=config['binary_threshold'],
            lambda_foreground=config.get('lambda_foreground', 1.0),
            device=device
        )

        # 获取预测结果
        with torch.no_grad():
            logits = model(x_binary)
            preds = logits.argmax(dim=1)

        # 处理每张图像
        for i in range(len(filenames)):
            filename = filenames[i]
            label = labels[i].item()
            pred = preds[i].item()
            keep_correct = int(pred == label)

            # 保存二值扰动图 - 修复第1处错误：正确处理数据类型
            binary_img = x_binary[i].squeeze().cpu().numpy()
            # 确保值在 [0, 255] 范围内且为 uint8 类型
            binary_img = (binary_img * 255).astype(np.uint8)
            # 如果是2D数组，直接使用；如果是3D且有单通道，去除通道维度
            if binary_img.ndim == 3 and binary_img.shape[0] == 1:
                binary_img = binary_img[0]
            binary_pil = Image.fromarray(binary_img, mode='L')
            binary_pil.save(binary_dir / filename)

            # 保存位移场可视化 - 修复第2处错误：确保返回的是 (H, W, 3) uint8 数组
            flow_vis = visualize_flow(flow[i])
            # 确保形状正确
            if flow_vis.ndim == 3 and flow_vis.shape[2] == 3:
                flow_pil = Image.fromarray(flow_vis)
                flow_filename = filename.replace('.bmp', '_flow.png')
                flow_pil.save(flow_dir / flow_filename)

            # 记录指标
            all_metrics.append({
                'filename': filename,
                'label': label,
                'pred': pred,
                'keep_correct': keep_correct,
                'keep_rate': metrics['keep_rate'],
                'avg_displacement': metrics['avg_displacement'],
                'changed_pixel_ratio': metrics['changed_pixel_ratio'],
                'orig_fg': metrics['orig_fg'],
                'aug_fg': metrics['aug_fg'],
                'fg_diff': metrics['fg_diff']
            })

            # 累计总体指标
            total_keep_rate += metrics['keep_rate']
            total_avg_displacement += metrics['avg_displacement']
            total_changed_pixel_ratio += metrics['changed_pixel_ratio']
            total_orig_fg += metrics['orig_fg']
            total_aug_fg += metrics['aug_fg']
            total_fg_diff += metrics['fg_diff']
            total_samples_count += 1

            # 收集可视化样本
            if len(vis_samples) < 10 and batch_idx * config['batch_size'] + i < len(samples):
                vis_samples.append({
                    'original': images[i].squeeze().cpu().numpy(),
                    'binary': x_binary[i].squeeze().cpu().numpy(),
                    'flow': visualize_flow(flow[i]),
                    'filename': filename,
                    'label': label,
                    'pred': pred,
                    'changed_pixel_ratio': metrics['changed_pixel_ratio'],
                    'avg_displacement': metrics['avg_displacement']
                })

    # 保存指标 CSV
    metrics_path = output_dir / f'{split}_metrics.csv'
    with open(metrics_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=all_metrics[0].keys())
        writer.writeheader()
        writer.writerows(all_metrics)
    print(f'Metrics saved to {metrics_path}')

    # 保存可视化对比图
    if vis_samples:
        num_samples = len(vis_samples)
        num_cols = 4
        num_rows = num_samples

        fig, axes = plt.subplots(num_rows, num_cols, figsize=(20, 5 * num_rows))

        for i, sample in enumerate(vis_samples):
            # 原始图
            axes[i, 0].imshow(sample['original'], cmap='gray')
            axes[i, 0].set_title(f'{sample["filename"]}\nLabel: {sample["label"]}')
            axes[i, 0].axis('off')

            # 位移场可视化 - 确保flow是正确的形状
            flow_display = sample['flow']
            if flow_display.ndim == 3 and flow_display.shape[2] == 3:
                axes[i, 1].imshow(flow_display)
            else:
                # 如果形状不对，显示幅度图
                axes[i, 1].imshow(np.zeros_like(sample['original']), cmap='gray')
            axes[i, 1].set_title(f'Flow\nDisp: {sample["avg_displacement"]:.2f}')
            axes[i, 1].axis('off')

            # 形变后的二值图
            binary_display = sample['binary']
            if binary_display.ndim == 3 and binary_display.shape[0] == 1:
                binary_display = binary_display[0]
            axes[i, 2].imshow(binary_display, cmap='gray')
            axes[i, 2].set_title(f'Deformed\nPred: {sample["pred"]}')
            axes[i, 2].axis('off')

            # 差异图
            original_display = sample['original']
            if original_display.ndim == 3 and original_display.shape[0] == 1:
                original_display = original_display[0]
            if binary_display.ndim == 3 and binary_display.shape[0] == 1:
                binary_display = binary_display[0]
            diff = np.abs(binary_display - original_display)
            axes[i, 3].imshow(diff, cmap='gray')
            axes[i, 3].set_title(f'Diff: {sample["changed_pixel_ratio"]:.4f}')
            axes[i, 3].axis('off')

        plt.tight_layout()
        vis_path = vis_dir / f'{split}_comparison.png'
        plt.savefig(vis_path)
        plt.close()
        print(f'Visualization saved to {vis_path}')

    # 计算平均指标
    if total_samples_count > 0:
        avg_keep_rate = total_keep_rate / total_samples_count
        avg_displacement = total_avg_displacement / total_samples_count
        avg_changed_ratio = total_changed_pixel_ratio / total_samples_count
        avg_orig_fg = total_orig_fg / total_samples_count
        avg_aug_fg = total_aug_fg / total_samples_count
        avg_fg_diff = total_fg_diff / total_samples_count

    # 打印平均指标
    print('\n' + '=' * 60)
    print(f'Average Metrics for {split} split (deformation augmentation)')
    print('=' * 60)
    print(f"Keep Rate: {avg_keep_rate:.4f}")
    print(f"Average Displacement: {avg_displacement:.4f}")
    print(f"Changed Pixel Ratio: {avg_changed_ratio:.4f}")
    print(f"Original Foreground Ratio: {avg_orig_fg:.4f}")
    print(f"Deformed Foreground Ratio: {avg_aug_fg:.4f}")
    print(f"Foreground Difference: {avg_fg_diff:.4f}")
    print('=' * 60)

    # 提示信息
    if avg_keep_rate < 0.9:
        print('\n⚠️  WARNING: Keep rate is low (< 0.9).')
        print(f'  Consider reducing max_displacement from {config["max_displacement"]}.')

    if avg_changed_ratio < 0.001:
        print('\n⚠️  WARNING: Changed pixel ratio is very low (< 0.001).')
        print(f'  Consider increasing max_displacement from {config["max_displacement"]}.')


if __name__ == '__main__':
    main()