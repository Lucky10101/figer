import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import matplotlib.pyplot as plt
import csv
from datasets.finger_vein_dataset import build_class_balanced_splits
from PIL import Image
import numpy as np

# 保存分割文件列表
def save_split_list(samples, save_path):
    with open(save_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['filename', 'label', 'path'])
        for sample in samples:
            writer.writerow([sample['filename'], sample['label'], str(sample['image_path'])])

# 可视化样本
def visualize_samples(samples, save_path, title, num_samples=20):
    # 选择前 num_samples 个样本
    samples_to_visualize = samples[:num_samples]
    
    # 计算行列数
    num_cols = 5
    num_rows = (len(samples_to_visualize) + num_cols - 1) // num_cols
    
    # 创建图像
    fig, axes = plt.subplots(num_rows, num_cols, figsize=(15, 3 * num_rows))
    fig.suptitle(title, fontsize=16)
    
    # 确保 axes 是二维数组
    if num_rows == 1:
        axes = [axes]
    
    for i, sample in enumerate(samples_to_visualize):
        row = i // num_cols
        col = i % num_cols
        
        # 读取图像
        image = Image.open(sample['image_path']).convert('L')
        
        # 显示图像
        axes[row][col].imshow(image, cmap='gray')
        axes[row][col].set_title(f'Label: {sample["label"]}\n{sample["filename"]}')
        axes[row][col].axis('off')
    
    # 隐藏多余的子图
    for i in range(len(samples_to_visualize), num_rows * num_cols):
        row = i // num_cols
        col = i % num_cols
        axes[row][col].axis('off')
    
    # 调整布局
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    
    # 保存图像
    plt.savefig(save_path)
    plt.close()

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Debug dataset')
    parser.add_argument('--config', type=str, default='../configs/baseline.yaml',
                        help='Path to config file')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=config['mask_dir'],
        images_per_class=config['images_per_class'],
        num_classes=config['num_classes'],
        train_per_class=config['train_per_class'],
        val_per_class=config['val_per_class'],
        test_per_class=config['test_per_class'],
        seed=config['seed']
    )
    
    # 打印基本信息
    print('=== Dataset Debug Info ===')
    print(f'Train samples: {len(train_samples)}')
    print(f'Val samples: {len(val_samples)}')
    print(f'Test samples: {len(test_samples)}')
    
    # 计算每个分割的类别数量
    train_classes = set(sample['label'] for sample in train_samples)
    val_classes = set(sample['label'] for sample in val_samples)
    test_classes = set(sample['label'] for sample in test_samples)
    
    print(f'\nTrain classes: {len(train_classes)}')
    print(f'Val classes: {len(val_classes)}')
    print(f'Test classes: {len(test_classes)}')
    
    # 计算每类样本数
    print('\n=== Per-class Sample Counts ===')
    train_class_counts = {i: 0 for i in range(config['num_classes'])}
    val_class_counts = {i: 0 for i in range(config['num_classes'])}
    test_class_counts = {i: 0 for i in range(config['num_classes'])}
    
    for sample in train_samples:
        train_class_counts[sample['label']] += 1
    
    for sample in val_samples:
        val_class_counts[sample['label']] += 1
    
    for sample in test_samples:
        test_class_counts[sample['label']] += 1
    
    for cls in range(config['num_classes']):
        print(f'Class {cls}: Train={train_class_counts[cls]}, Val={val_class_counts[cls]}, Test={test_class_counts[cls]}')
    
    # 创建输出目录
    output_dir = Path(config['output_dir'])
    output_dir.mkdir(exist_ok=True)
    
    # 保存分割文件列表
    save_split_list(train_samples, output_dir / 'train_split.csv')
    save_split_list(val_samples, output_dir / 'val_split.csv')
    save_split_list(test_samples, output_dir / 'test_split.csv')
    
    print('\n=== Files Saved ===')
    print(f'Train split list: {output_dir / "train_split.csv"}')
    print(f'Val split list: {output_dir / "val_split.csv"}')
    print(f'Test split list: {output_dir / "test_split.csv"}')
    
    # 保存可视化结果
    visualize_samples(train_samples, output_dir / 'debug_train_samples.png', 'Train Samples')
    visualize_samples(val_samples, output_dir / 'debug_val_samples.png', 'Validation Samples')
    visualize_samples(test_samples, output_dir / 'debug_test_samples.png', 'Test Samples')
    
    print('\n=== Visualizations Saved ===')
    print(f'Train samples visualization: {output_dir / "debug_train_samples.png"}')
    print(f'Val samples visualization: {output_dir / "debug_val_samples.png"}')
    print(f'Test samples visualization: {output_dir / "debug_test_samples.png"}')

if __name__ == '__main__':
    main()