import sys
from pathlib import Path

# 将项目根目录（palmvein_adv_aug）添加到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import yaml
import torch
from torch.utils.data import DataLoader
from datasets.finger_vein_dataset import FingerVeinDataset, build_class_balanced_splits
from models.resnet18_binary import create_resnet18_binary
from perturbations.topology_filter import compute_topology_metrics
import numpy as np
import csv

# 主函数
def main():
    parser = argparse.ArgumentParser(description='Evaluate MHOA augmentation')
    parser.add_argument('--config', type=str, default='../configs/mhoa_aug.yaml',
                        help='Path to config file')
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default='train',
                        help='Split to evaluate')
    args = parser.parse_args()
    
    # 读取配置文件
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 读取 baseline 配置
    with open(config['baseline_config'], 'r', encoding='utf-8') as f:
        baseline_config = yaml.safe_load(f)
    
    # 设备选择
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    
    # 构建数据分割
    train_samples, val_samples, test_samples = build_class_balanced_splits(
        image_dir=baseline_config['mask_dir'],
        images_per_class=baseline_config['images_per_class'],
        num_classes=baseline_config['num_classes'],
        train_per_class=baseline_config['train_per_class'],
        val_per_class=baseline_config['val_per_class'],
        test_per_class=baseline_config['test_per_class'],
        seed=baseline_config['seed']
    )
    
    split = args.split
    if split == 'train':
        samples = train_samples
    elif split == 'val':
        samples = val_samples
    else:
        samples = test_samples
    
    print(f'Evaluating {split} split with {len(samples)} samples')
    
    # 检查增强图像目录
    output_dir = Path(config['output_dir'])
    aug_binary_dir = output_dir / split / 'binary'
    
    if not aug_binary_dir.exists():
        raise FileNotFoundError(f"Augmented binary images directory not found: {aug_binary_dir}")
    
    # 加载增强图像
    aug_images = []
    filenames = []
    
    for sample in samples:
        filename = sample['filename']
        aug_path = aug_binary_dir / filename
        
        if aug_path.exists():
            from PIL import Image
            img = Image.open(aug_path).convert('L')
            img = img.resize((baseline_config['image_size'], baseline_config['image_size']))
            img_np = np.array(img, dtype=np.float32) / 255.0
            img_tensor = torch.tensor(img_np).unsqueeze(0).unsqueeze(0)
            aug_images.append(img_tensor)
            filenames.append(filename)
        else:
            print(f'Warning: {filename} not found in augmented directory')
    
    aug_images = torch.cat(aug_images, dim=0)
    
    # 创建原始数据集
    original_dataset = FingerVeinDataset(
        image_dir=baseline_config['mask_dir'],
        samples=samples,
        image_size=baseline_config['image_size'],
        binary_threshold=baseline_config['binary_threshold']
    )
    
    original_loader = DataLoader(
        original_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=0
    )
    
    # 收集原始图像
    original_images = []
    original_labels = []
    
    for _, (img, label, _) in enumerate(original_loader):
        original_images.append(img)
        original_labels.append(label)
    
    original_images = torch.cat(original_images, dim=0)
    original_labels = torch.cat(original_labels, dim=0)
    
    # 创建模型
    model = create_resnet18_binary(
        num_classes=baseline_config['num_classes'],
        dropout=baseline_config.get('dropout', 0.5)
    ).to(device)
    
    # 加载模型权重
    checkpoint_path = Path(config['checkpoint'])
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file {config['checkpoint']} does not exist")
    
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        model.load_state_dict(checkpoint)
    
    model.eval()
    model = model.to(device)
    
    # 评估
    original_images = original_images.to(device)
    aug_images = aug_images.to(device)
    original_labels = original_labels.to(device)
    
    model.eval()
    with torch.no_grad():
        # 原始图像预测
        orig_logits = model(original_images)
        orig_preds = orig_logits.argmax(dim=1)
        orig_acc = (orig_preds == original_labels).float().mean().item()
        
        # 增强图像预测
        aug_logits = model(aug_images)
        aug_preds = aug_logits.argmax(dim=1)
        aug_acc = (aug_preds == original_labels).float().mean().item()
        
        # 保持率
        keep_mask = (orig_preds == original_labels) & (aug_preds == original_labels)
        keep_rate = keep_mask.float().mean().item()
    
    # 计算拓扑指标
    orig_fg_list = []
    aug_fg_list = []
    orig_endpoints_list = []
    aug_endpoints_list = []
    orig_branchpoints_list = []
    aug_branchpoints_list = []
    orig_components_list = []
    aug_components_list = []
    
    for i in range(len(original_images)):
        orig_np = original_images[i].squeeze().cpu().numpy()
        aug_np = aug_images[i].squeeze().cpu().numpy()
        
        orig_metrics = compute_topology_metrics(orig_np)
        aug_metrics = compute_topology_metrics(aug_np)
        
        orig_fg_list.append(orig_metrics['foreground_ratio'])
        aug_fg_list.append(aug_metrics['foreground_ratio'])
        orig_endpoints_list.append(orig_metrics['num_endpoints'])
        aug_endpoints_list.append(aug_metrics['num_endpoints'])
        orig_branchpoints_list.append(orig_metrics['num_branchpoints'])
        aug_branchpoints_list.append(aug_metrics['num_branchpoints'])
        orig_components_list.append(orig_metrics['num_components'])
        aug_components_list.append(aug_metrics['num_components'])
    
    # 计算平均指标
    mean_orig_fg = np.mean(orig_fg_list)
    mean_aug_fg = np.mean(aug_fg_list)
    mean_fg_diff = np.mean(np.abs(np.array(aug_fg_list) - np.array(orig_fg_list)))
    
    mean_orig_endpoints = np.mean(orig_endpoints_list)
    mean_aug_endpoints = np.mean(aug_endpoints_list)
    mean_endpoint_diff = np.mean(np.abs(np.array(aug_endpoints_list) - np.array(orig_endpoints_list)))
    
    mean_orig_branchpoints = np.mean(orig_branchpoints_list)
    mean_aug_branchpoints = np.mean(aug_branchpoints_list)
    mean_branchpoint_diff = np.mean(np.abs(np.array(aug_branchpoints_list) - np.array(orig_branchpoints_list)))
    
    mean_orig_components = np.mean(orig_components_list)
    mean_aug_components = np.mean(aug_components_list)
    mean_component_diff = np.mean(np.abs(np.array(aug_components_list) - np.array(orig_components_list)))
    
    # 变化像素比例
    changed_pixel_ratio = torch.abs(aug_images - original_images).mean().item()
    
    # 打印结果
    print('\n' + '='*60)
    print(f'MHOA-lite Evaluation Summary for {split} split')
    print('='*60)
    print(f"Original Accuracy: {orig_acc:.4f}")
    print(f"Augmented Accuracy: {aug_acc:.4f}")
    print(f"Keep Rate: {keep_rate:.4f}")
    print(f"Changed Pixel Ratio: {changed_pixel_ratio:.4f}")
    print()
    print(f"Original Foreground Ratio: {mean_orig_fg:.4f}")
    print(f"Augmented Foreground Ratio: {mean_aug_fg:.4f}")
    print(f"Foreground Difference: {mean_fg_diff:.4f}")
    print()
    print(f"Original Endpoints: {mean_orig_endpoints:.2f}")
    print(f"Augmented Endpoints: {mean_aug_endpoints:.2f}")
    print(f"Endpoint Difference: {mean_endpoint_diff:.2f}")
    print()
    print(f"Original Branchpoints: {mean_orig_branchpoints:.2f}")
    print(f"Augmented Branchpoints: {mean_aug_branchpoints:.2f}")
    print(f"Branchpoint Difference: {mean_branchpoint_diff:.2f}")
    print()
    print(f"Original Components: {mean_orig_components:.2f}")
    print(f"Augmented Components: {mean_aug_components:.2f}")
    print(f"Component Difference: {mean_component_diff:.2f}")
    print('='*60)
    
    # 保存汇总
    summary = {
        'split': split,
        'num_samples': len(original_images),
        'original_acc': orig_acc,
        'augmented_acc': aug_acc,
        'keep_rate': keep_rate,
        'changed_pixel_ratio': changed_pixel_ratio,
        'orig_fg': mean_orig_fg,
        'aug_fg': mean_aug_fg,
        'fg_diff': mean_fg_diff,
        'orig_endpoints': mean_orig_endpoints,
        'aug_endpoints': mean_aug_endpoints,
        'endpoint_diff': mean_endpoint_diff,
        'orig_branchpoints': mean_orig_branchpoints,
        'aug_branchpoints': mean_aug_branchpoints,
        'branchpoint_diff': mean_branchpoint_diff,
        'orig_components': mean_orig_components,
        'aug_components': mean_aug_components,
        'component_diff': mean_component_diff
    }
    
    summary_path = output_dir / 'evaluation_summary.csv'
    with open(summary_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=summary.keys())
        writer.writeheader()
        writer.writerow(summary)
    print(f'\nSummary saved to {summary_path}')

if __name__ == '__main__':
    main()